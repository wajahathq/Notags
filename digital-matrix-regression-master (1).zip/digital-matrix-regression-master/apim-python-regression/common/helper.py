import requests, json, sys

class Helper:
    def __init__(self, environment: str, api_suffix: str, api_key:str, region_override: str = None):
        self._verify = True
        self._protocol = 'https'
        self.default_headers = {
            'Ocp-Apim-Subscription-Key': api_key,
            'x-kpmg-charge-code': '803000015283'
        }

        if region_override:
            self.default_headers['x-kpmg-region-override'] = region_override

        if (environment.startswith('localhost')):
            api_suffix = 'api'
            self._verify = False
            self._protocol = 'http'
            self.default_headers['x-apim-caller-id'] = 'local_user'
            self.default_headers['x-apim-subscription-key'] = api_key

        self.base_url = f'{self._protocol}://{environment}/{api_suffix}'

    def read_json_config(self, env_name: str):
        import json

        # get deployment ids from json file
        with open("..\\environment-matrix-config.json", "r") as file:
            env_config_json_content = json.load(file)

        # Initialize the deployment_id as None or an empty dictionary
        env_config = None

        # Iterate through the list and pick the right deployment based on the environment name
        for env_config_json in env_config_json_content['include']:
            if env_config_json["github_env_name"] == env_name:
                env_config = env_config_json
                break        # Check if deployment_info is found
        assert env_config is not None, f"Deployment information not found for environment: {env_name}"

        return env_config
        
    def serialize(self, obj: object):
        return json.dumps(obj, indent=4)
        
    def get(self, url: str, log_response: bool = True):
        return self.__request("GET", url, None, log_response)
        
    def post(self, url: str, request_body = None, log_response: bool = True):
        return self.__request("POST", url, request_body, log_response)

    def put(self, url: str, request_body = None, log_response: bool = True):
        return self.__request("PUT", url, request_body, log_response)
        
    def delete(self, url: str, log_response: bool = True):
        return self.__request("DELETE", url, None, log_response)

    def patch(self, url: str, request_body = None, log_response: bool = True):
        return self.__request("PATCH", url, request_body, log_response)
        
    def log(self, message: object, end: str = '\n'):
        try:
            print(message, end=end) # output for local debugging
            sys.__stdout__.write(str(message) + end) # output for pytest
        except UnicodeEncodeError:
            print("[Unicode content - cannot display]", end=end)
            sys.__stdout__.write("[Unicode content - cannot display]" + end)

    def add_headers(self, additional_headers:object):
        self.default_headers.update(additional_headers)

    def get_property_values(self, response_json: object, prop_name: str, exclude_none: bool = True, list_prop_name: str = "value"):
        retVal = list(map(
            lambda obj: (obj or None) and obj[prop_name],
            response_json[list_prop_name]))

        if exclude_none:
            return [x for x in retVal if x is not None]

        return retVal

    def __request(self, verb: str, url: str, request_body = None, log_response: bool = True):
        full_url = f'{self.base_url}{url}'

        if (url.startswith("https:")):
            full_url = url

        self.log(f'Request: {verb} {full_url}')
        # self.log(f'Headers: {self.default_headers}') uncomment to log all headers
        response = requests.request(
            verb,
            full_url,
            headers=self.default_headers,
            json=request_body,
            verify=self._verify)

        self.log(f'Response: {response.status_code}')

        try:
            response.json = response.json()
        except:
            response.json = None

        if log_response:
            self.log(response.json)

        self.log('')

        return response