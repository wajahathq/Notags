## Overview

This framework is intended to assist with ensuring that our APIM APIs are healthy and operational.  By leveraging this framework, we can:
- Test our APIs locally during development to expedite the testing process (vs. using Swagger)
- Test deployments to new environments to ensure no steps were missed
- Run Regression tests to ensure that the environment stays stable after future modifications to the environment
- Serve as a deliverable to end users as code samples/example of how to properly consume the API

## How does it work?

A [GitHub workflow](https://github.com/kpmg-global-technology-and-knowledge/digital-matrix-regression/actions/workflows/reg-wb-apim.yml) has been created that will allow developers, QA, and Dev Enablement to run the entire suite of end to end tests (or subset thereof) written in Python, as necessary for each scenario.  This workflow will allow the end user to:

The workflow will be executed:
- Automatically - Immediately after a deployment to an environment
- Automatically - Nightly in all existing environments
- Manually - On Demand excecution with the ability to:
  - Select against which environment(s) the tests should be run
  - Select which tests to execute (single API, multiple APIs, or all APIs)

The workflow will pull environment variables from GitHub and create a secrets.env file on the runner VM, and then subsequently leverage pytest (and the pytest-notebook plugin) to execute these notebooks in sequence (currently one at a time).

### Contract Compatiblity

These developer tests will be a collection of Python notebooks that execute a set of positive (and negative) test cases to ensure that the acceptance criteria of the feature and associated user stories have been (and remain) met.  For features that require contract compatibility as a part of the acceptance criteria of the API, we have chosen to leverage Python, as the majority of SDKs for the features we are introducing are written in Python (vs the previous PowerShell approach, which does not have any necessary SDKs available at the time of drafting this readme).  As such, we can write test cases that physically use these SDKs to prove that they are indeed contract compatible.

### Configuration

In the apim-python-regression directory, there is a pytest.ini file that contains various configuration options for pytest.  This may useful when you are wanting to run pytest locally (rather than running the notebook in VS code).  You can change the pattern below to match whichever notebook(s) you wish to test, but by default, we will run them all.

```
nb_file_fnmatch = dev-tests/*.ipynb
```

### Maintenance

It should be part of the acceptance criteria going forward that ANY API imported into the solution should have a set of:
- Positive test cases (written by the development team)
- Negative test cases (written by the QA team)

### Folder Structure
- `dev-tests`: Contains a minimal set of tests (owned solely by development) that prove the API is responding appropriately for common usage scenarios
- `qa-tests`: Contians a set of FULL regression scenarios (owned solely by QA) that extensively test multiple permutations of inputs and negative test case scenarios (graceful failure)

For **net new** APIs, a new Python notebook should be created (as a sibling of the existing notebooks - see [apim-python-regression/dev-tests](https://github.com/kpmg-global-technology-and-knowledge/digital-matrix-regression/tree/master/apim-python-regression/dev-tests))

For new operations/endpoints within an existing API (or enhancements to existing operations), simply modify the existing Python notebook for that API by adding your additional test cases, as necessary

### Reference
 - Vendor Docs
   - [pytest](https://docs.pytest.org/en/stable/)
   - [pytest-notebook](https://pytest-notebook.readthedocs.io/en/latest/)
 - GitHub workflows
   - [reg-wb-apim](https://github.com/kpmg-global-technology-and-knowledge/digital-matrix-regression/actions/workflows/reg-wb-apim.yml)
