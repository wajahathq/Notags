param (
    [string]$GithubWorkspaceDirectory,
    [string]$EnvironmentFilter
)

# Load the JSON files
$workflowJson = Get-Content -Path "$GithubWorkspaceDirectory/apim-python-regression/environment-matrix-config.json" | ConvertFrom-Json

# Define the common key
$commonKey = 'github_env_name'

# Perform the inner join
$joinedData = '{include:[]}' | ConvertFrom-Json

# Sort the environments
foreach ($workflowJsonEntry in $workflowJson.include | Sort-Object -Property $commonKey) {
    $joinedItem = @{}

    foreach ($property in $workflowJsonEntry.PSObject.Properties)
    {
        $joinedItem[$property.Name] = $property.Value
    }

    $joinedData.include += $joinedItem
}

# If a filter is provided, filter the joined data
if (-not [string]::IsNullOrEmpty($EnvironmentFilter)) {
    # Wildcard pattern replacement to support SQL-like behavior
    $filteredData = $joinedData.include | Where-Object { $_.github_env_name -like $EnvironmentFilter }
    $joinedData = '{include:[]}' | ConvertFrom-Json
    $joinedData.include += $filteredData
}

# Convert the joined data back to JSON and output it
$mergedJson = $joinedData | ConvertTo-Json -Compress -Depth 5

echo "matrix=$($mergedJson)" >> $env:GITHUB_OUTPUT

echo $mergedJson
