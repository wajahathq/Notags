## Developer Checklist
**Thank you for your contribution! Your attention to detail and diligence is vital to keep our main branch stable.**

Refer to the 
[PRRB Process](https://github.com/kpmg-global-technology-and-knowledge/digital-matrix-app/wiki/Pull-Request-Review-Board-(PRRB)-Process) page for additional information.

Before merging this PR, please ensure that you have completed the following:

### Notes
_Enter any additional notes you want to share about this pull request_

### Code Quality
- [ ] **Syntax Check**: I have ensured that there are no syntax errors in the Python code.
- [ ] **Notebook Cleanliness**: All notebooks have been cleaned up (e.g., all outputs removed, consistent styling).
- [ ] **Contract Compatibility**": I have written all tests using the vendor's Python SDK, rather than using ``helper.py`` (applicable only to Contract Compatible endpoints)

### Testing and Validation
- [ ] **Test Execution**: I have run all regression tests in all non-prod environments, and they pass
- [ ] **Evidence**: I have attached screenshots or links to GitHub workflows as evidence of successful tests and notebook execution.

### Documentation and Code Review
- [ ] **Linked Issue**: I have linked at least one GitHub issue to this PR
- [ ] **Documentation**: I have written/updated  relevant documentation, including:
  - Code Comments
  - External/End User Documentation (KPMG Code Docs)
- [ ] **Readability**: I have reviewed my code for better readability and optimization.
- [ ] **Peer Review**: I have requested a code review from at least one other team member (besides the PRRB).
- [ ] **Copilot Review**: I have added Copilot as a reviewer and addressed any relevant comments/suggestion it has given.
- [ ] **Merge Conflicts**: I have resolved any conflicts with the main branch.

## Evidence of Success
_Attach any images, GIFs, or text that show the successful outcome of the required checks, i.e._
- _[Regression Workflow Run](url_to_build_screenshot)_

## Reviewer Checklist
- [ ] The pull request meets all checklist items above.
- [ ] Code is well-structured and follows best practices.
- [ ] The changes are adequately tested and documented.
