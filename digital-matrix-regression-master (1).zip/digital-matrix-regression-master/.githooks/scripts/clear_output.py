import nbformat
import os
from pathlib import Path

def find_files_with_extension(directory, extension):
    return list(Path(directory).rglob(f'*{extension}'))

def clear_output(notebook_path: str):
    print(f'clear output for: {notebook_path}')

    with open(notebook_path, 'r', encoding='utf-8') as f:
        nb = nbformat.read(f, as_version=4)

    for cell in nb.cells:
        if cell.cell_type == 'code':
            cell.outputs = []
            cell.execution_count = None

    with open(notebook_path, 'w', encoding='utf-8') as f:
        nbformat.write(nb, f)

if __name__ == "__main__":
    current_directory = os.path.dirname(os.path.realpath(__file__))
    notebook_directory = os.path.join(current_directory, '../../apim-python-regression')
    extension = '.ipynb'

    files = find_files_with_extension(notebook_directory, extension)

    for file in files:
        clear_output(file)
