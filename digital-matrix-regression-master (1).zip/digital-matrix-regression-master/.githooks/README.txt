To utilize this hook, run the following command at the root of the repo:

cd C:\Users\%USERNAME%\Source\repos\digital-matrix-infra
git config --local core.hookspath .githooks

to "out out" of this approach, you can run the following:

git config --local --unset core.hooksPath