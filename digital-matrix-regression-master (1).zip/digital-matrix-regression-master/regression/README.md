# Pester regression tests

Tese are powershell tests that run digital matrix to exercise its functuionality


## Installation notes Notes

This requires Powershell core i.e. pwsh.

You need to install pester 5 which can be done with the command `Install-Module pester -Scope CurrentUser -Force`

## Running locally

The paramaters have been greatly simplified so that running locally requires minimal arguments.

To see the full documentation of the command type `Get-Help .\Start-pester.ps1 -Full`

When running locally you almost always want to use  `-WriteOutputImmediately` which is designed to give the most immediate output  to the screen as opposed to outputting in a manner best for the CI/CD pipelines.
When working on an individual test suite you want to pass `-TestFilter` like so `-TestFilter  'power-bi.group.tests.ps1`.
When working with long running tests you want to pass `-IncludeLongRunning`

Example: `.\start-pester.ps1  -TestFilter  'auth-permission.tests.ps1' -WriteOutputImmediately