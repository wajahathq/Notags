[CmdletBinding()]
param(
$EnvironmentData,
[string] $TestPath,
[string] $TestSuiteName,
[string] $ResultFile,
[boolean] $ContiniousIntegration,
[boolean] $IncludeLongRunning
)

if ($ContiniousIntegration) {
    Import-Module -Name "./pester" -Verbose:$false
} else {
    Import-Module Pester -MinimumVersion 5.0.0 -Verbose:$false
}


$configuration = [PesterConfiguration] @{
    Run = @{
        Container = New-PesterContainer `
        -Path $TestPath `
        -Data @{
            CurrentEnvironmentData = $EnvironmentData;
        }
        Exit = $False      # I have no idea what this actually does, but if you set it to true then passthru just returns the output as if we weren't setting it to a variable below
        Throw = $True     # This does not exist in the version of pester we have at the moment. we workaround with exit
        PassThru = $True   # Same as -PassThru, but we cant mix due to paramater sets.
    }
    TestResult = @{
        Enabled = $true
        OutputPath = $ResultFile
    }
    Output = @{
        Verbosity = 'Normal'
        # The default value is automatic, and does correclty set this, but we add it here for illustrative purposes.
        # CIFormat  = 'AzureDevops'
    }
}
if (!$IncludeLongRunning) {
    $configuration.Filter.ExcludeTag = 'long-running'
    Write-Verbose "Excluding long-running tests"
}

$pesterResults = Invoke-Pester -Configuration $Configuration
Write-Verbose "Finished $($TestSuiteName)."
# Until we have a version of pester supports $Configuration.Run.Throw we use this to rely on $Configuration.Run.PassThru
if ($pesterResults.Failed.Count -gt 0) {
    # Throw instead of write error to ensure job failure acorrs multiple pester veresions, etc
    throw "Pester run for $($TestSuiteName) had $($pesterResults.Failed.Count) failed jobs"
}