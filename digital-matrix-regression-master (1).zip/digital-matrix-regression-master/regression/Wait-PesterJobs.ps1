[CmdletBinding()]
param(
  [Parameter(Mandatory, ValueFromPipeline)]
  [ValidateNotNullOrEmpty()]
  [System.Collections.Generic.List[pscustomobject]] $PesterJobs,
  [Parameter(Mandatory)]
  [AllowEmptyCollection()]
  [ValidateNotNull()]
  [System.Collections.Generic.List[pscustomobject]] $FailedJobs,
  [switch] $ErrorIfJobsFailed
)

$StartTime = Get-Date
function Receive-PesterJob {
  [CmdletBinding()]
  param(
    [Parameter(Mandatory, ValueFromPipeline)]
    [ValidateNotNullOrEmpty()]
    [pscustomobject] $CompletedJob,
    [switch] $Wait
  )

  try {
    $CompletedJob | Receive-Job -Wait:$Wait
  }
  catch {
    Write-Warning "Error happened while receiving completed job $($CompletedJob.Name)"
    Write-Warning $_

  }
  Write-Verbose "Job `"$($CompletedJob.Name)`" completed with state  $($CompletedJob.State)."
  if ($CompletedJob.State -ne 'Completed') {
    $FailedJobs.Add($CompletedJob)
    Write-Warning "Pester job $($CompletedJob.Name) completed with failures."
  }
  $CompletedJob |
    Select-Object Name, PSBeginTime,	PSEndTime, JobRunTime, State |
    Export-Csv -Append -NoTypeInformation -Path JobSummary.csv

  $JobRemovalSuccess = $PesterJobs.Remove($CompletedJob)
  if (-not $JobRemovalSuccess) {
    Write-Warning "Could not remove $($CompletedJob.Name) from the list of pester jobs."
  }
}

while ($PesterJobs.Count -gt 0) {

  Write-Verbose "Currently running $($PesterJobs.Count) pester jobs. . . ."

  if ($PesterJobs.Count -eq 1) {
    Write-Verbose "Waiting for the final job $($PesterJobs[0].CompletedJob.Name)"
    $CompletedJob = $PesterJobs[0] | Receive-PesterJob -Wait
    continue
  }

  $PesterJobs | Format-Table Id, Name, State, JobRunTime

  $CompletedJob = $PesterJobs | Where-Object HasMoreData | Wait-Job -Timeout 30 -Any
  if ($null -eq $CompletedJob) {
    Write-Verbose "No new Jobs have completed as of $((Get-Date).ToString('s'))"
    Continue
  }
  else {
    $CompletedJob | Receive-PesterJob
    Write-Verbose "$($CompletedJob.Name) finished with state $($CompletedJob.State) in $($CompletedJob.JobRunTime)."
  }

  if (((Get-Date) - ($StartTime)).TotalMinutes -gt 15) {
    $StartTime = Get-Date
    $PesterJobs | ForEach-Object {
      Write-Host "===== Begin partial Output for $($_.Name) ====="
      $_ | Receive-Job
      Write-Host "===== End partial Output for $($_.Name) ====="
    }
  }

}

Write-Verbose "Failed jobs count: $($FailedJobs.Count)"

if ($ErrorIfJobsFailed -and ($FailedJobs.Count -gt 0)) {
  Write-Error 'Not all pester jobs were successful'
}