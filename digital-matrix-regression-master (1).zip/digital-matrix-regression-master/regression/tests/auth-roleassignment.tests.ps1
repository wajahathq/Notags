﻿<#param(

    [Parameter(Mandatory)]
    [ValidateNotNullOrEmpty()]
    $CurrentEnvironmentData

)
$script:RoleNameContext = (New-Guid).Guid
$Script:Role = "AutomationRole$($RoleNameContext)"
$script:Scope = "Root"
$script:ScopeResourceKey = "root"
Describe "Auth" -Tag "RoleAssignment" { 
    BeforeAll {

        Write-Host "Preparing testcases to create Auth Role Scenario tests..."
        
        Write-Host "Creating Role..."

        $requestParams = @{
            Method = 'POST'
            Uri    = "/auth/api/v1/role"                       
            Body   = @{
                "roleName"       = "$($Role)"
                "description"    = "$($Role) Description"
                "permissionKeys" = @('app-role-assignment.read')
            } | ConvertTo-Json              
        }
        $createResponse = $null
        $createResponse = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true
        
        # printing value of role and api response
        Write-host "create role methods return ----  $($Role)"
        Write-host "create role methods return ----  $($createResponse)"


        #Create user in ad and added in Auth
        $memberUserIdContext = (New-Guid).Guid

        # Create a user that will be added to the group
        
        $memberUserResult = Create-User $CurrentEnvironmentData $memberUserIdContext

        Write-Host "The Response of.... $($memberUserResult) "

        FailEarly 'Validate Ad User created.' {
            $memberUserResult.status | Should -Be "Completed"
        }

        $script:memberUserId = $memberUserResult.taskOutput.userId
        
        $RITMnumber = $memberUserResult.taskOutput.snowRequestNumber
        
        # Create a User in Auth with the same ADD user 
        Write-Host "****Create user in Auth******"


        $requestParams = @{
            Method = 'POST'
            Uri    = "/auth/api/v1/user"                       
            Body   = @{
                "userId" = "$($memberUserId)"
            } | ConvertTo-Json              
        }
        $AuthUserresponse = @{}
        $AuthUserresponse = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true

        $script:memberUserName = $AuthUserresponse.taskOutput.userId
            
        Write-Host "****Verify Role from the Get Method******"
           
        $requestParams = @{
            Method = 'GET'
            Uri    = "/auth/api/v1/role/$($Role)"                
        }

        $response = @{}
        $response = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true
            
        Write-Host "Assigning Role to the User..."

        $requestParams = @{
            Method = 'POST'
            Uri    = "/auth/api/v1/roleassignment"                       
            Body   = @{
                "userId"           = "$($memberUserId)"
                "roleName"         = "$($Role)"
                "scopeType"        = "$($Scope)"
                "scopeResourceKey" = "$($ScopeResourceKey)"
            } | ConvertTo-Json              
        }

        $addRoletoUserResponse = $null
        $addRoletoUserResponse = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true $true 5
 
    }
    It "should return the expected status creating new Role" {
        $createResponse | Should -Not -BeNullOrEmpty
      
    }

    It "should return the expected Result when adding Role to User" {
        $addRoletoUserResponse | should -be ""
    }

    It "Should not return null for role Creation" {                               
        $response | Should -not -BeNullOrEmpty
    }
    It "Should return exact match for role Creation" {                               
        $response[0].name | should -be $($Role)
    }     
    
    #Verify Role Assignment from Get Method
    Context "DM_Auth_API_10_01| Verify Assignment of created roleName $($Role)" {
        BeforeAll {

            $requestParams = @{
                Method = 'GET'
                Uri    = "/auth/api/v1/roleassignment/role/$($Role)"                
            }

            $response = @{}
            $response = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true
        }

        It "Should not return null" {                               
            $response | Should -not -BeNullOrEmpty
        }
        It "Should return exact match" {                               
            $response[0].roleName | should -be $($Role)
        }                 

    }

    #Negative Scenario    
    #To verify the duplicasy
    Context "DM_Auth_API_10_01| Verify create Role with same name exist" {
        BeforeAll {

            Write-Host "Checking duplicated Role..."

            $requestParams = @{
                Method = 'POST'
                Uri    = "/auth/api/v1/role"                       
                Body   = @{
                    "roleName"       = "$($Role)"
                    "description"    = "$($Role) Description"
                    "permissionKeys" = @('app-role-assignment.read')
                } | ConvertTo-Json              
            }
            $response = @{}
            $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true
        }

        It "Should return code other than 200" {                               
            $response.ExceptionResponse.StatusCode.value__ | should -be 400
        }
        It "Should return valid message" {                               
            $response.ErrorDetails.Message | should -be "Role name '$($Role)' already existed."
        }                 
               

    }
    Context "DM_Auth_API_10_01| Verify already created Role assingments with same request Body  $($Role)" {
        BeforeAll {
            Write-Host "Assigning Duplicate Role to the User..."

            $requestParams = @{
                Method = 'POST'
                Uri    = "/auth/api/v1/roleassignment"                       
                Body   = @{
                    "userId"           = "$($memberUserId)"
                    "roleName"         = "$($Role)"
                    "scopeType"        = $($Scope)
                    "scopeResourceKey" = "$($ScopeResourceKey)"
                } | ConvertTo-Json              
            }
    
            $response = @{}
            $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true
        }
        It "Should not return null" {                               
            $response.ExceptionResponse.StatusCode.value__ | should -be 409
        }
        It "Should return exact match" {                               
            $response.ErrorDetails.Message | should -be "This role assignment already exists at this scope!"
        }                 

    }
    #the below endpoint should always return at least one record, and every record returned should be for the root scope 
    Context "DM_Auth_API_11_01-DM_Auth_API_11_45| Verify Assignment of created roleName $($Role) via Scopetype" {
        BeforeAll {

            $requestParams = @{
                Method = 'GET'
                Uri    = "/auth/api/v1/roleassignment/scope/$($Scope)?scopeResourceKey=$($ScopeResourceKey)"                
            }

            $response = @{}
            $response = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true
        }

        It "Should not return null" {                               
            $response | Should -not -BeNullOrEmpty
        }
        It "Should return exact Role name Match - " { 
            
            $response.roleName | should -contain $($Role)
                                        
            
        }                 

    } 

    Context "GET /api/v1/roleassignment/role/{roleName}" {
        #Testcases to check roleAssignment  for Invalid Role Name
        Context "DM_Auth_API_06_00| non-existing roleName" {
            BeforeAll {
              
                $requestParams = @{
                    Method = 'GET'
                    Uri    = "/auth/api/v1/permission/1234"                
                }

                $response = @{}
                
                # we know this will return something other than a 200 response, so we're using the special error handler method
                $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true
                                
            }
            It "Should return NotFound" {                               
                $response.ExceptionResponse.StatusCode.value__ | Should -be 404 
            }
            It "Should return user friendly message" { 
                $response.ErrorDetails.Message | should -be "Permission with key does not exist: Unknown"  
            } 
        }

        Context "DM_Auth_API_10_01| GET Role Assignment by existing RoleNames" {
            
            #Will take out the list of Roles from API (/auth/api/v1/role)
            $requestParams = @{
                Method = 'GET'
                Uri    = "/auth/api/v1/role"                   
            }

            $RoleresponseList = @{}
            $RoleresponseList = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true
            
            foreach ($item in $RoleresponseList) {
                    
                $requestParams = @{
                    Method = 'GET'
                    Uri    = "/auth/api/v1/roleassignment/role/$($item.name)"                
                }
                $response = @{}
                $response = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true
            
                    
                It "Should not return null" {                               
                    $RoleresponseList.count | Should -not -BeNullOrEmpty
                }       
        
                It "Should return All the assigned Roles for $($item.name) " {
                    foreach ($item in $RoleresponseList) {
                        $response.roleName | Should -contain $($item.name)
                    }
                }
            }
        }
             
    }

    Context "DM_Auth_API_22 | Verify 409 when Create User with Existing User ID " {
        BeforeAll {
            Write-Host "****Recreate user in Auth with same id $($memberUserId)******"
            $requestParams = @{
                Method = 'POST'
                Uri    = "/auth/api/v1/user"                       
                Body   = @{
                    "userId" = "$($memberUserId)"
                } | ConvertTo-Json              
            }

            $response = @{}
            $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true
        }
        It "Should not return null" {                               
            $response.ExceptionResponse.StatusCode.value__ | should -be 409
        }
        It "Should return exact match" {                               
            $response.ErrorDetails.Message | should -be "User already exists with ID: $($memberUserId)"
        } 
    }

  
   

    AfterAll {
       
        Write-Host "Cleaning up Role Assignment..."            
 
        Write-Host "***** memebrr id is $($memberUserId) ..."
        Write-Host "***** ROLE is $($Role) ."
        
        $requestParams = @{
            Method = 'DELETE'
            Uri    = "/auth/api/v1/roleassignment"                       
            Body   = @{
                "userId"           = "$($memberUserId)"
                "roleName"         = "$($Role)"
                "scopeType"        = "$($Scope)"
                "scopeResourceKey" = "$($ScopeResourceKey)"
            } | ConvertTo-Json             
        }
        $response = $null
        $response = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true $true 5
        Write-Host "Assignment Deleted $($Role) ..."
     
        #Deleting Role
        Write-Host "Deleting user $($contextId)..."
    
        #delete Role
        $requestParams = @{
            Method = 'DELETE'
            Uri    = "/auth/api/v1/role/$($Role)"               
        }

        $response = $null
        $response = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true $true 5

        Write-Host "Role Deleted $($Role) ..."

        #delete User
        $requestParams = @{
            Method = 'DELETE'
            Uri    = "/auth/api/v1/user/$($memberUserId)"               
        }

        $response = $null
        $response = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true $true 5

        Write-Host " Auth User Deleted $($memberUserId) ..."
     
    }
}

#Scenario to test GET deleted Role and Role assignment method
Describe "Deleted user case" {

    Context "GET /api/v1/roleassignment/role/{roleName}" {
        BeforeAll {
            Write-Host "THIS IS THE ANOTHER DESCRIBE BLOCK FOR TEST deletion of deleted assignment $($Role) ..."
            $requestParams = @{
                Method = 'DELETE'
                Uri    = "/auth/api/v1/roleassignment"                       
                Body   = @{
                    "userId"           = "$($memberUserId)"
                    "roleName"         = "$($Role)"
                    "scopeType"        = "$($Scope)"
                    "scopeResourceKey" = "$($ScopeResourceKey)"
                } | ConvertTo-Json                      
            }
            $response = @{}
            $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true
            Write-Host "Assignment to Delete for deleted $($Role) ..."

            #delete user
            $requestParams = @{
                Method = 'DELETE'
                Uri    = "/auth/api/v1/role/$($Role)"               
            }

            $responserole = $null
            $responserole = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true

            Write-Host "Role not found $($Role) ..."
        }

        It "Should not return null for Role Assignment" {                               
            $response | Should -not -BeNullOrEmpty
        }
        It "Should return message for Role Assignment deletion" {                               
            $response.ErrorDetails.Message | should -be "Role with name does not exist: $($Role)"
        } 
        It "Should not return null for Role deletion" {                               
            $responserole | Should -not -BeNullOrEmpty
        }
        It "Should return exact match for Role Deletion" {                               
            $responserole.ErrorDetails.Message | should -be "Role with name does not exist: $($Role)"
        } 
    }   
} 

#>