﻿param(

  [Parameter(Mandatory)]
  [ValidateNotNullOrEmpty()]
  $CurrentEnvironmentData

)

Describe "AAD Group Membership" {

    BeforeAll {
        # We don't want to rely on objects already existing, so let's create what we need.
        # This leaves us open to lots of duplicate code, but let's worry about optimatization later.
        # We can refactor AFTER we get to a green state with the basic test.  As we get more comfortable, we can combine these steps.
        # This is based on the "Red,Green,Refactor" approach - https://www.codecademy.com/article/tdd-red-green-refactor
        # TODO: Refactor potential duplciate logic into helper methods.  Examples are Create-Group and Create-User

        Write-Host "Preparing group membership tests..."

        $service = "ad"
        $groupIdContext = (New-Guid).Guid
        $nestedGroupIdContext = (New-Guid).Guid
        $memberUserIdContext = (New-Guid).Guid
        $ownerUserIdContext = (New-Guid).Guid

        # Create the group that will have its group membership modified
        $groupCreateResult = Create-Group $CurrentEnvironmentData $groupIdContext -IgnoreBackgroundStatus

        # Create the group that will be added as a member to the newly created group
        $nestedGroupCreateResult = Create-Group $CurrentEnvironmentData $nestedGroupIdContext -IgnoreBackgroundStatus

        # Create a user that will be added to the group
        $memberUserCreateResult = Create-User $CurrentEnvironmentData $memberUserIdContext -IgnoreBackgroundStatus

        # Create a user that will be the owner of the group
        $ownerUserCreateResult = Create-User $CurrentEnvironmentData $ownerUserIdContext -IgnoreBackgroundStatus

        # Parallel wait for all tasks
        $groupResult = $null
        $groupResult = Get-BackgroundStatus $CurrentEnvironmentData $groupCreateResult.taskId "$($service)"

        $nestedGroupResult = $null
        $nestedGroupResult = Get-BackgroundStatus $CurrentEnvironmentData $nestedGroupCreateResult.taskId "$($service)"

        $memberUserResult = $null
        $memberUserResult = Get-BackgroundStatus $CurrentEnvironmentData $memberUserCreateResult.taskId "$($service)"

        $ownerUserResult = $null
        $ownerUserResult = Get-BackgroundStatus $CurrentEnvironmentData $ownerUserCreateResult.taskId "$($service)"

        $groupId = $groupResult.taskOutput.groupId
        $nestedGroupId = $nestedGroupResult.taskOutput.groupId
        $memberUserId = $memberUserResult.taskOutput.userId
        $ownerUserId = $ownerUserResult.taskOutput.userId

        FailEarly 'Validate First Group created.' {
            $groupResult.status | Should -Be "Completed"
        }

        FailEarly 'Validate Nested Group created.' {
            $nestedGroupResult.status | Should -Be "Completed"
        }

        FailEarly 'Validate Member User created.' {
            $memberUserResult.status | Should -Be "Completed"
        }

        FailEarly 'Validate Owner User created.' {
            $ownerUserResult.status | Should -Be "Completed"
        }

        # Now we have a brand new groups and brand new users that are guaranteed to exist in a known state.
        # Let's run the commands for what we want to test

        Write-Host "Adding user to group..."

        $requestParams = @{
            Method = 'POST'
            Uri    = "/$($service)/api/v1/groupmembership/members"
            Body   = @{
                "memberId"   = "$($memberUserId)"
                "groupId"    = "$($groupid)"
                "memberType" = "user"
            } | ConvertTo-Json
        }

        $addUserMemberResponse = $null
        $addUserMemberResponse = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true $true 5

        Write-Host "Adding nested group to group..."

        $requestParams = @{
            Method = 'POST'
            Uri    = "/$($service)/api/v1/groupmembership/members"
            Body   = @{
                "memberId"   = "$($nestedGroupId)"
                "groupId"    = "$($groupid)"
                "memberType" = "group"
            } | ConvertTo-Json
        }

        $addGroupMemberResponse = $null
        $addGropuMemberResponse = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true $true 5

        Write-Host "Adding owner to group..."

        $requestParams = @{
            Method = 'POST'
            Uri    = "/$($service)/api/v1/groupmembership/owners"
            Body   = @{
                "ownerId"   = "$($ownerUserId)"
                "groupId"    = "$($groupid)"
                "ownerType" = "user"
            } | ConvertTo-Json
        }

        $addGroupOwnerResponse = $null
        $addGropuOwnerResponse = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true $true 5

        # Parallel wait for all tasks to complete
        $addUserMemberTaskResult = $null
        $addUserMemberTaskResult = Get-BackgroundStatus $CurrentEnvironmentData $addUserMemberResponse.taskId "$($service)"

        $addGroupMemberTaskResult = $null
        $addGroupMemberTaskResult = Get-BackgroundStatus $CurrentEnvironmentData $addGropuMemberResponse.taskId "$($service)"

        $addGroupOwnerTaskResult = $null
        $addGroupOwnerTaskResult = Get-BackgroundStatus $CurrentEnvironmentData $addGropuOwnerResponse.taskId "$($service)"
    }

    #addUserMemberTaskResult steps
    It "should return the expected status when adding user member to group" {
        $addUserMemberTaskResult.status | Should -Be "Completed"
    }
    It "should return the expected activity type when adding user member to group" {
        $addUserMemberTaskResult.taskOutput.activityType | Should -Be "AddGroupMember"
    }
    It "should return a reference to a RITM when adding user member to group" {
        $addUserMemberTaskResult.taskOutput.snowRequestNumber | Should -not -BeNullOrEmpty
    }
    It "should add user type group member in less than 60 seconds" {
        ([timespan]($addUserMemberTaskResult.duration)).TotalMinutes | Should -BeLessOrEqual 10
    }

    #addGroupOwnerTaskResult steps
    It 'Validate Owner User added as owner to First Group.' {
        $addGroupOwnerTaskResult.status | Should -Be "Completed"
    }
    It "should return the expected activity type when adding group owner" {
        $addGroupOwnerTaskResult.taskOutput.activityType | Should -Be "AddGroupOwner"
    }
    It "should return a reference to a RITM when adding user member to group" {
        $addGroupOwnerTaskResult.taskOutput.snowRequestNumber | Should -not -BeNullOrEmpty
    }
    It "should add group owner in less than 60 seconds" {
        ([timespan]($addGroupOwnerTaskResult.duration)).TotalMinutes | Should -BeLessOrEqual 10
    }

    #addGroupMemberTaskResult
    It 'Validate Nester Group added as member to First Group.' {
        $addGroupMemberTaskResult.status | Should -Be "Completed"
    }
    It "should return the expected activity type when adding group member to group" {
        $addGroupMemberTaskResult.taskOutput.activityType | Should -Be "AddGroupMember"
    }
    It "should return a reference to a RITM when adding user member to group" {
        $addGroupMemberTaskResult.taskOutput.snowRequestNumber | Should -not -BeNullOrEmpty
    }
    It "should add group type group member in less than 60 seconds" {
        ([timespan]($addGroupMemberTaskResult.duration)).TotalMinutes | Should -BeLessOrEqual 10
    }

    Context "GET /api/v1/groupmembership/group/{groupId}/memberof" {

        Context "DM_AD_API_13_01 | Get members of Existing groupId" {
            BeforeAll {
                $requestParams = @{
                    Method = 'GET'
                    Uri = "/$($service)/api/v1/groupmembership/group/$($nestedGroupId)/memberof"
                }

                $response = @{}
                $response = Retry-Request $CurrentEnvironmentData $requestParams 5 $groupid
            }

            It "Should not return null" {

                $response | Should -not -BeNullOrEmpty
            }

            It "Should return the parent group id" {
                $response.id | Should -be "$($groupid)"
            }
        }
    }

    Context "GET/api/v1/groupmembership/group/{groupId}/members" {

        Context "DM_AD_API_14_01 | Get members in Existing groupId" {

            BeforeAll {
                $requestParams = @{
                    Method = 'GET'
                    Uri = "/$($service)/api/v1/groupmembership/group/$($groupId)/members"
                }

                $response = @{}
                $response = Retry-Request $CurrentEnvironmentData $requestParams 5 $nestedGroupId
            }

            It "Should not return null" {

                $response | Should -not -BeNullOrEmpty
            }

            It "Should contain the user member" {

                $response.id | Should -Contain "$memberUserId"
            }

            It "Should contain the group member" {

                $response.id | Should -Contain "$nestedGroupId"
            }
        }
    }

    Context "GET/api/v1/groupmembership/user/{userId}/memberof" {

        Context "DM_AD_API_16_01 | Search for existing user with known group membership" {
            BeforeAll {
                $requestParams = @{
                    Method = 'GET'
                    Uri = "/$($service)/api/v1/groupmembership/user/$($memberUserId)/memberof"
                }

                $response = @{}
                $response = Retry-Request $CurrentEnvironmentData $requestParams 5 $groupid
            }

            It "Should not return null" {

                $response | Should -Not -BeNullOrEmpty
            }

            It "Should return the parent group id" {
                $response.id | Should -Contain "$($groupid)"
            }
        }
    }

    Context "GET/api/v1/groupmembership/group/{groupId}/owners" {

        Context "DM_AD_API_15_01 | Retrieve owners for existing group" {

            BeforeAll {
                $requestParams = @{
                    Method = 'GET'
                    Uri = "/$($service)/api/v1/groupmembership/group/$($groupId)/owners"
                }

                $response = @{}
                $response = Retry-Request $CurrentEnvironmentData $requestParams 5 $($ownerUserId)
            }

            It "Should not return null" {

                $response | Should -Not -BeNullOrEmpty
            }

            It "Should return the known owner user id" {
                $response.id | Should -Contain "$($ownerUserId)"
            }
        }
    }

        #Transtive Memebers Usecases
    Context " GET /api/v1/groupmembership/group/{groupId}/transitivemembers" {
        Context "DM_AD_API_16_05 | Search Transtive Members of a Valid group id" {
            BeforeAll {

                $requestParams = @{
                    Method  = 'GET'
                    Uri     = "/$($service)/api/v1/groupmembership/group/$($groupId)/transitivemembers"
                }

                $response = @{}
                $response = Retry-Request $CurrentEnvironmentData $requestParams 5 $nestedGroupId
            }
             It "Should not return null" {
                $response | Should -not -BeNullOrEmpty
            }

        }

    }
    #PUT MEthods of Group Edit
    Context "PUT  ad/api/v1/group/{groupId}" {

        Context "DM_AD_API_08_01- 08_02  | PUT Edit Details for Created Group" {
            BeforeAll{
                $requestParams = @{
                    Method = 'PUT'
                    Uri = "/$($service)api/v1/group/$($groupId)"
                    Body   = @{
                        "displayName"  = "Updated$($groupName)"
                        "description"  = "Updated$($description)"
                        "mailNickname" = "Updated$($groupName)"
                    } | ConvertTo-Json
                }

                $updateGroupResponse = $null
                $updateGroupResponse = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true $true 5

                $updateGroupTaskResult = $null
                $updateGroupTaskResult = Get-BackgroundStatus $CurrentEnvironmentData $updateGroupResponse.taskId "$($service)"
            }

            It "Should not return null" {
                $updateGroupTaskResult | Should -not -BeNullOrEmpty
            }

            It "should return the expected activity type when Updating group details" {
                $updateGroupTaskResult.taskOutput.activityType | Should -Be "UpdateGroup"
            }
            It "should return the expected status when adding user member to group" {
                $updateGroupTaskResult.status | Should -Be "Completed"
            }
        }
    }

    AfterAll {
        Write-Host "Cleaning up after group membership tests"

        # delete group with members
        Delete-Group $CurrentEnvironmentData $groupId -FireAndForget

        # delete nested group
        Delete-Group $CurrentEnvironmentData $nestedGroupId -FireAndForget

        #delete member user
        Delete-User $CurrentEnvironmentData $memberUserId -FireAndForget

        #delete owner user
        Delete-User $CurrentEnvironmentData $ownerUserId -FireAndForget
    }
}
#Negative scenarios
Describe "AAD Group Memebership_Negative Scenarios"-Tag "GroupMembership" {

    Context "GET /api/v1/groupmembership/group/{groupId}/memberof" {
        Context "DM_AD_API_16_02 | Search members with Invalid group id" {
            BeforeAll {
                $service = "ad"
                $InvalidgroupId = "c296eed1-44c3-4a9d-b3b4-6e0aea76780f"

                $requestParams = @{
                    Method  = 'GET'
                    Uri     = "/$($service)/api/v1/groupmembership/group/$($InvalidgroupId)/memberof"
                }

                $response = @{}
                $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true
            }


            It "Should return 404 code" {
                 $response.ExceptionResponse.StatusCode.value__ | Should -be 404
            }

             It "Should return user friendly message" {
                $response.ErrorDetails.Message | should -be "Invalid Group Id: $($InvalidgroupId)."
            }
        }
    }

    Context "GET /api/v1/groupmembership/group/{groupId}/owners" {
        Context "DM_AD_API_16_04 | Search owner of invalid group id" {
            BeforeAll {
                $service = "ad"
                $InvalidgroupId = "c296eed1-44c3-4a9d-b3b4-6e0aea76780f"

                $requestParams = @{
                    Method  = 'GET'
                    Uri     = "/$($service)/api/v1/groupmembership/group/$($InvalidgroupId)/owners"
                }

                $response = @{}
                $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true
            }

            It "Should return 404 code" {
                 $response.ExceptionResponse.StatusCode.value__ | Should -be 404
            }
             It "Should return user friendly message" {
                $response.ErrorDetails.Message | should -be "Invalid Group Id '$($InvalidgroupId)'."
            }
        }
    }

    #Negative Usecase of TranstiveMember
        Context "DM_AD_API_16_07 | Search Transtive Members of a Invalid group id" {
            BeforeAll {
                $service = "ad"
                $InvalidgroupId = "c296eed1-44c3-4a9d-b3b4-6e0aea76780f"

                $requestParams = @{
                    Method  = 'GET'
                    Uri     = "/$($service)/api/v1/groupmembership/group/$($InvalidgroupId)/transitivemembers"
                }

                $response = @{}
                $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true
            }

            It "Search By groupId that exist should return 404 code" {
                 $response.ExceptionResponse.StatusCode.value__ | Should -be 404
            }
             It "Search By engagement code that doesn't exist should return user friendly message" {
                $response.ErrorDetails.Message | should -be "Invalid Group Id: '$($InvalidgroupId)'."
            }
        }

    Context "/api/v1/groupmembership/user/{userId}/memberof" {
        Context "DM_AD_API_16_09 | Invalid user id" {
            BeforeAll {
                $service = "ad"
                $InvaliduserId = "c456d5d4-000e-4ec6-b106-0bd835f2d3b3"

                $requestParams = @{
                    Method  = 'GET'
                    Uri     = "/$($service)/api/v1/groupmembership/user/$(($InvaliduserId))/memberof"
                }

                $response = @{}
                $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true
            }

            It "Search By userId that exist should return 404 code" {
                 $response.ExceptionResponse.StatusCode.value__ | Should -be 404
            }
             It "Search By userId that doesn't exist should return user friendly message" {
                $response.ErrorDetails.Message | should -be "User with ID was not found: $($InvaliduserId)"
            }
        }
     }
}