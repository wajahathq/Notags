 <#param(

    [Parameter(Mandatory)]
    [ValidateNotNullOrEmpty()]
    $CurrentEnvironmentData

)

$Script:CapabilityList = @("Unknown", "Text", "TextStreaming", "Chat", "ChatStreaming", "Embeddings")
$Script:ModelNameList = @()

Describe "Get the list of models and parameters" {

    Context "TC_266506: To verify list of All Models for Generative AI" {

        #List of model without selecting any provider and capability from dropdown 
        BeforeAll {
            $ModelCount = 0
            $requestParams = @{
                Method = 'GET'
                Uri    = "/workspace/api/v1/generativeai/model"
            }
            $modelList = @{}
            $modelList = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true
        }
        
        It "Should have 200 response with valid data for model list" {
            $modelList.count | Should -Not -BeNullOrEmpty
        }

        It "Should have valid provider name in response for model list" {
            foreach ($eachitem in $modelList) {
                $ModelCount ++
                $ModelNameList += $eachitem.modelName
                $eachitem.provider -in ("GoogleVertexAI", "Anthropic", "AzureOpenAI") | Should -BeTrue
            }
            Write-Host "Model Name list is : $($ModelNameList)"
            Write-Host "Total number of models are : $($ModelCount)"
        }

    }

    Context "TC_266507: To verify list of All Models on basis of  provider = AzureOpenAI for Generative AI" {
        
        It "Should return valid response for AzureOpenAI provider" {
            $count = 0
            $requestParams = @{
                Method = 'GET'
                Uri    = "/workspace/api/v1/generativeai/model?providers=AzureOpenAI"
            }
        
            $AzureOpenAImodelList = @{}
            $AzureOpenAImodelList = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true
    
            foreach ($model in $AzureOpenAImodelList) {
                $count ++
                $model.provider | Should -eq "AzureOpenAI"
                
            }
            Write-Host "The total number of model for AzureOpenAI provider is : $($count)" 
        }   
        
    }

    Context "TC_266508: To verify list of All Models on basisc of provider = Google Vertex for Generative AI" {

        It "Should return valid response for GoogleVertexAI provider" {
            $count = 0
            $requestParams = @{
                Method = 'GET'
                Uri    = "/workspace/api/v1/generativeai/model?providers=GoogleVertexAI"
            }
        
            $GoogleVertexAImodelList = @{}
            $GoogleVertexAImodelList = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true
    
            foreach ($model in $GoogleVertexAImodelList) {
                $count ++
                $model.provider | Should -eq "GoogleVertexAI"
            }
            Write-Host "The total number of model for GoogleVertexAI provider is : $($count)" 
        }    
    }

    Context "TC_266509: To verify list of All Models where provider = AzureOpenAI and Capabilities is anyone from list" {
        It "Should return correct capabilities for AzureOpenAI provider" {
            foreach ($capability in $CapabilityList) {
                Write-Host "Capability for provider AzureOpenAI is : $($capability)"
                $requestParams = @{
                    Method = 'GET'
                    Uri    = "/workspace/api/v1/generativeai/model?providers=AzureOpenAI&capabilities=$($capability)"
                }
            
                $AzureOpenAIWithCapabilityResponse = @{}
                $AzureOpenAIWithCapabilityResponse = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true
    
                if ($capability -eq "Unknown") {
                    $AzureOpenAIWithCapabilityResponse.count | Should -BeGreaterOrEqual 0
                }
                elseif ($capability -eq "Text") {
                    foreach ($item in $AzureOpenAIWithCapabilityResponse) {
                        $item.provider | Should -eq "AzureOpenAI"
                        $item.capabilities | Should -Contain "Text"
                    }
                }
                elseif ($capability -eq "TextStreaming") {
                    foreach ($item in $AzureOpenAIWithCapabilityResponse) {
                        $item.provider | Should -eq "AzureOpenAI"
                        $item.capabilities | Should -Contain "TextStreaming"
                    }
                }
                elseif ($capability -eq "Chat") {
                    foreach ($item in $AzureOpenAIWithCapabilityResponse) {
                        $item.provider | Should -eq "AzureOpenAI"
                        $item.capabilities | Should -Contain "Chat"
                    }
                }
                elseif ($capability -eq "ChatStreaming") {
                    foreach ($item in $AzureOpenAIWithCapabilityResponse) {
                        $item.provider | Should -eq "AzureOpenAI"
                        $item.capabilities | Should -Contain "ChatStreaming"
                    }
                }
                elseif ($capability -eq "Embeddings") {
                    foreach ($item in $AzureOpenAIWithCapabilityResponse) {
                        $item.provider | Should -eq "AzureOpenAI"
                        $item.capabilities | Should -Contain "Embeddings"
                    }
                }
            }
        }
    }

    Context "TC_266510: To verify list of All Models where provider = GoogleVertexAI and Capabilities is anyone from list" {
        It "Should return correct capabilities for GoogleVertexAI provider" {
            foreach ($capability in $CapabilityList) {
                Write-Host "Capability for provider GoogleVertexAI is : $($capability)"
                $requestParams = @{
                    Method = 'GET'
                    Uri    = "/workspace/api/v1/generativeai/model?providers=GoogleVertexAI&capabilities=$($capability)"
                }
            
                $GoogleVertexAIWithCapabilityResponse = @{}
                $GoogleVertexAIWithCapabilityResponse = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true
                
                if ($capability -eq "Unknown") {
                    $GoogleVertexAIWithCapabilityResponse.count | Should -BeGreaterOrEqual 0
                }
                elseif ($capability -eq "Text") {
                    foreach ($item in $GoogleVertexAIWithCapabilityResponse) {
                        $item.provider | Should -eq "GoogleVertexAI"
                        $item.capabilities | Should -Contain "Text"
                    }
                }
                elseif ($capability -eq "TextStreaming") {
                    foreach ($item in $GoogleVertexAIWithCapabilityResponse) {
                        $item.provider | Should -eq "GoogleVertexAI"
                        $item.capabilities | Should -Contain "TextStreaming"
                    }
                }
                elseif ($capability -eq "Chat") {
                    foreach ($item in $GoogleVertexAIWithCapabilityResponse) {
                        $item.provider | Should -eq "GoogleVertexAI"
                        $item.capabilities | Should -Contain "Chat"
                    }
                }
                elseif ($capability -eq "ChatStreaming") {
                    foreach ($item in $GoogleVertexAIWithCapabilityResponse) {
                        $item.provider | Should -eq "GoogleVertexAI"
                        $item.capabilities | Should -Contain "ChatStreaming"
                    }
                }
                elseif ($capability -eq "Embeddings") {
                    $GoogleVertexAIWithCapabilityResponse.count | Should -BeGreaterOrEqual 0
                }
            }
        }
    }

    Context "TC_273080 - TC_273085: To verify list of All Models where provider = Anthropic and Capabilities is anyone from list" {
        It "Should return correct capabilities for Anthropic provider" {
            foreach ($capability in $CapabilityList) {
                Write-Host "Capability for provider Anthropic is : $($capability)"
                $requestParams = @{
                    Method = 'GET'
                    Uri    = "/workspace/api/v1/generativeai/model?providers=Anthropic&capabilities=$($capability)"
                }
            
                $AnthropicWithCapabilityResponse = @{}
                $AnthropicWithCapabilityResponse = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true
                
                if ($capability -eq "Unknown") {
                    $AnthropicWithCapabilityResponse.count | Should -BeGreaterOrEqual 0
                }
                elseif ($capability -eq "Text") {
                    foreach ($item in $AnthropicWithCapabilityResponse) {
                        $item.provider | Should -eq "Anthropic"
                        $item.capabilities | Should -Contain "Text"
                    }
                }
                elseif ($capability -eq "TextStreaming") {
                    foreach ($item in $AnthropicWithCapabilityResponse) {
                        $item.provider | Should -eq "Anthropic"
                        $item.capabilities | Should -Contain "TextStreaming"
                    }
                }
                elseif ($capability -eq "Chat") {
                    foreach ($item in $AnthropicWithCapabilityResponse) {
                        $item.provider | Should -eq "Anthropic"
                        $item.capabilities | Should -Contain "Chat"
                    }
                }
                elseif ($capability -eq "ChatStreaming") {
                    foreach ($item in $AnthropicWithCapabilityResponse) {
                        $item.provider | Should -eq "Anthropic"
                        $item.capabilities | Should -Contain "ChatStreaming"
                    }
                }
                elseif ($capability -eq "Embeddings") {
                    $AnthropicWithCapabilityResponse.count | Should -BeGreaterOrEqual 0
                }
            }
        }
    }

    Context "TC_266511: To verify list of All Models only on basis of capabilities where Provider = Not Selected and fetching parameter details" {
        It "Should return correct value for selected capabilty where provider is not selected" {
            foreach ($capability in $CapabilityList) {
                Write-Host "Selected Capability is : $($capability)"
                $requestParams = @{
                    Method = 'GET'
                    Uri    = "/workspace/api/v1/generativeai/model?capabilities=$($capability)"
                }
            
                $CapabilityResponse = @{}
                $CapabilityResponse = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true
                
                if ($capability -eq "Unknown") {
                    $CapabilityResponse.count | Should -BeGreaterOrEqual 0
                }
                elseif ($capability -eq "Text") {
                    foreach ($item in $CapabilityResponse) {
                        $item.capabilities | Should -Contain "Text"
                        $ModelNameForParameterWithText = $($item.modelName)
                        
                        #List of parameter on basis of model name and capability as Text
                        $requestParams = @{
                            Method = 'GET'
                            Uri    = "/workspace/api/v1/generativeai/model/$($ModelNameForParameterWithText)/$($capability)/parameter"
                        }
                        $ParameterResponseForText = @{}
                        $ParameterResponseForText = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true

                        Write-Host "This parameter list contains all details of Text capability for model : $($ModelNameForParameterWithText)"

                        $ParameterResponseForText.count | Should -Not -BeNullOrEmpty
                    }
                }
                elseif ($capability -eq "TextStreaming") {
                    foreach ($item in $CapabilityResponse) {
                        $item.capabilities | Should -Contain "TextStreaming"
                        $ModelNameForParameterWithTextStreaming = $($item.modelName)
                        
                        #List of parameter on basis of model name and capability as TextStreaming
                        $requestParams = @{
                            Method = 'GET'
                            Uri    = "/workspace/api/v1/generativeai/model/$($ModelNameForParameterWithTextStreaming)/$($capability)/parameter"
                        }
                        $ParameterResponseForTextStreaming = @{}
                        $ParameterResponseForTextStreaming = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true

                        Write-Host "This parameter list contains all details of TextStreaming capability for model : $($ModelNameForParameterWithTextStreaming)"

                        $ParameterResponseForTextStreaming.count | Should -Not -BeNullOrEmpty
                    }
                }
                elseif ($capability -eq "Chat") {
                    foreach ($item in $CapabilityResponse) {
                        $item.capabilities | Should -Contain "Chat"
                        $ModelNameForParameterWithChat = $($item.modelName)
                        
                        #List of parameter on basis of model name and capability as Chat
                        $requestParams = @{
                            Method = 'GET'
                            Uri    = "/workspace/api/v1/generativeai/model/$($ModelNameForParameterWithChat)/$($capability)/parameter"
                        }
                        $ParameterResponseForChat = @{}
                        $ParameterResponseForChat = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true

                        Write-Host "This parameter list contains all details of Chat capability for model : $($ModelNameForParameterWithChat)"

                        $ParameterResponseForChat.count | Should -Not -BeNullOrEmpty
                    }
                }
                elseif ($capability -eq "ChatStreaming") {
                    foreach ($item in $CapabilityResponse) {
                        $item.capabilities | Should -Contain "ChatStreaming"
                        $ModelNameForParameterWithChatStreaming = $($item.modelName)
                        
                        #List of parameter on basis of model name and capability as ChatStreaming
                        $requestParams = @{
                            Method = 'GET'
                            Uri    = "/workspace/api/v1/generativeai/model/$($ModelNameForParameterWithChatStreaming)/$($capability)/parameter"
                        }
                        $ParameterResponseForChatStreaming = @{}
                        $ParameterResponseForChatStreaming = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true

                        Write-Host "This parameter list contains all details of ChatStreaming capability for model : $($ModelNameForParameterWithChatStreaming)"

                        $ParameterResponseForChatStreaming.count | Should -Not -BeNullOrEmpty
                    }
                }
                elseif ($capability -eq "Embeddings") {
                    foreach ($item in $CapabilityResponse) {
                        $item.capabilities | Should -Contain "Embeddings"
                        $ModelNameForParameterWithEmbeddings = $($item.modelName)
                        
                        #List of parameter on basis of model name and capability as Embeddings
                        $requestParams = @{
                            Method = 'GET'
                            Uri    = "/workspace/api/v1/generativeai/model/$($ModelNameForParameterWithEmbeddings)/$($capability)/parameter"
                        }
                        $ParameterResponseForEmbeddings = @{}
                        $ParameterResponseForEmbeddings = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true

                        Write-Host "This parameter list contains all details of Embeddings capability for model : $($ModelNameForParameterWithEmbeddings)"

                        $ParameterResponseForEmbeddings.count | Should -Not -BeNullOrEmpty
                    }
                }
            }
        }
    }

    Context "Get the list of models when no provider and capability is selected - Negative TC"{
        BeforeAll {
            $requestParams = @{
                Method = 'GET'
                Uri    = "/workspace/api/v1/generativeai/model?providers=&capabilities="
            }
        
            $response = @{}
            $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true
        }

        It "Should return 400 error for blank provider and capability" {
            $response.ExceptionResponse.StatusCode.value__ | Should -be 400
        }
        It "Should return user friendly message for blank provider and capability" {
            $response.ErrorDetails.errors.Providers | should -eq "The value '' is invalid."
            $response.ErrorDetails.errors.Capabilities | should -eq "The value '' is invalid."
        }
        
    }

    Context "Get the list of parameter with invalid capability for the model name - Negative TC"{
        BeforeAll {
            $requestParams = @{
                Method = 'GET'
                Uri    = "/workspace/api/v1/generativeai/model/GPT%204/Text/parameter"
            }
        
            $response = @{}
            $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true
        }

        It "Should return 404 error for invalid capability for the model name" {
            $response.ExceptionResponse.StatusCode.value__ | Should -be 404
        }
        It "Should return user friendly message for invalid capability for the model name" {
            $response.ErrorDetails.message | should -eq "Could not find the capability 'Text' for model 'GPT 4'"
        }
        
    }

    Context "Get the list of parameter with invalid model name - Negative TC"{
        BeforeAll {
            $requestParams = @{
                Method = 'GET'
                Uri    = "/workspace/api/v1/generativeai/model/GPT%203/Unknown/parameter"
            }
        
            $response = @{}
            $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true
        }

        It "Should return 404 error for invalid model name" {
            $response.ExceptionResponse.StatusCode.value__ | Should -be 404
        }
        It "Should return user friendly message for invalid model name" {
            $response.ErrorDetails.message | should -eq "Could not find an AI Model called 'GPT 3'"
        }
        
    }
}  #>

