param(
    [Parameter(Mandatory)]
    [ValidateNotNullOrEmpty()]
    $CurrentEnvironmentData
)
$script:engagementCode = "803000012512"
BeforeDiscovery {
    Write-Host "Fetching GEOLOCATION feature state"
    $requestParams = @{
        Method = 'GET'
        Uri    = "/workspace/api/v1/feature/Workspace | GenerativeAI | EnableUserGeoLocation"
    }
    $response = $null
    $response = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true
    Write-Host "Response from get feature $response"
    # Setting SkipGenAIFeature to False initially
    $global:SkipGenAIFeature = $false
    if ($response -eq $true) {
        $global:SkipGenAIFeature = $true
        Write-Host "GeoLocation Flag is Enable in $($CurrentEnvironmentData.Environment) Skiping all the Testcases "
    }
    else {
        Write-Host "GeoLocation Flag is Disable in $($CurrentEnvironmentData.Environment) Proceeding with Gen AI Testcases in commercial Cloud"
    }
}
Describe "Workspace API - Gen AI Vision Model" -Skip:($SkipGenAIFeature) {
    Describe "Execution for vision model testcases"{
        Context "Get the list of all Gen AI Models" {
            Write-Host "Flag is false, hence inside describe"
            
                $requestParams = @{
                    Method = 'GET'
                    Uri    = "/workspace/api/v1/generativeai/model?pageIndex=0&pageSize=100"
                }
                $ModelList = @{}
                $ModelList = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true
                $ModelWithACVtestCases = New-Object System.Collections.Generic.List[Hashtable]
                $ModelWithoutACVtestCases = New-Object System.Collections.Generic.List[Hashtable]
                foreach ($model in $ModelList) {
                    if ($model.modelName -notmatch ".*Dummy.*"){
                        foreach ($parameter in $model.parameters) {
                            $parameterName = $parameter.parameterName
                            if ($parameterName -in @("enable_computer_vision", "enable_grounding", "enable_ocr")) {
                                $ModelWithACVtestCases.Add(@{
                                    'Model' = $($model.modelName)
                                })
                                break;
                            } elseif ($model.capabilities -contains "Vision") {
                                $ModelWithoutACVtestCases.Add(@{
                                    'Model' = $($model.modelName)
                                })
                                break;
                            }
                        }
                    } else {
                        Write-Host "$($model.modelName) is a dummy model"
                    }
                }
                Write-Host "No of testcases for with ACV model: $($ModelWithACVtestCases.Count)"
                Write-Host "No of testcases for without ACV model: $($ModelWithoutACVtestCases.Count)"
        
            It "Verify the response for CHAT when computer vision is set to true & ocr and grounding are not provided(Positive TC)" -TestCases $ModelWithACVtestCases {
                Write-Host "CHAT: Models is $Model and only computer vision capability is given as true"
                $imageUrlsArray = @("https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRMF8MXTtEebgU9dDog4s4T3lB9m01EzEeazodnlYWsxQ&s")
                $requestParams = @{
                    Method = 'POST'
                    Uri    = "/workspace/api/v1/generativeai/chat"
                    Body   = @{
                        "modelName" = $Model
                        "messages"       = @( @{
                            "role"    = "System"
                            "content" = "I will be providing brief information about the given image"
                            }, @{
                            "role"    = "User"
                            "content" = "Hi! Please describe this image"
                            "imageUrls" = $imageUrlsArray
                        })
                        "engagementCode" = $engagementCode
                        "parameters"     = @{
                            "enable_computer_vision" = $true
                        }
                    } | ConvertTo-Json -Depth 10
                }
                $response1 = @{}
                $response1 = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true
                $response1.choices.message | Should -Not -BeNullOrEmpty
                ($response1.choices.finishReason | Should -Not -BeNullOrEmpty) -and ($response1.choices.finishReason | Should -Not -Be "error")
                ($response.modelParams.PSObject.Properties.Name -contains "image_detail") -and ($response.modelParams.image_detail | Should -eq 'Auto')
                
            }
            It "Verify the response for CHAT when computer vision, ocr and grounding all vision capabilty parameters are set to true along with all other parameters(Positive TC)" -TestCases $ModelWithACVtestCases{
                Write-Host "CHAT: Models is $Model and all vision capabilities are set to true with other parameters"
                $imageUrlsArray = @("https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQmdRDRDssXg4TL3lgIgyriPdpLCkkQlTR4uHt0hyZBLw&s")
                $requestParams = @{
                    Method = 'POST'
                    Uri    = "/workspace/api/v1/generativeai/chat"
                    Body   = @{
                        "modelName" = $Model
                        "messages"       = @( @{
                            "role"    = "User"
                            "content" = "Can you identify any objects or landmarks in this image?"
                            "imageUrls" = $imageUrlsArray
                        })
                        "engagementCode" = $engagementCode
                        "parameters"     = @{
                            "max_tokens" = 10
                            "temperature" = 1
                            "frequency_penalty" = 0
                            "presence_penalty" = 0
                            "top_p" = 1
                            "enable_computer_vision"= $true
                            "enable_ocr"= $true
                            "enable_grounding" = $true
                            "image_detail" = "High"
                         }
                    } | ConvertTo-Json -Depth 10
                }
                $response2 = @{}
                $response2 = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true
                $response2.choices.message | Should -Not -BeNullOrEmpty
                ($response2.choices.finishReason | Should -Not -BeNullOrEmpty) -and ($response2.choices.finishReason | Should -Not -Be "error")
                ($response.modelParams.PSObject.Properties.Name -contains "image_detail") -and ($response.modelParams.image_detail | Should -eq 'High')
            }
            It "Verify the response for CHAT when computer vision and grounding parameters are true and ocr is false (Positive TC)" -TestCases $ModelWithACVtestCases{
                Write-Host "CHAT: Models is $Model, computer vision and grounding are set to true & ocr is false"
                $imageUrlsArray = @("https://www.shutterstock.com/image-vector/set-universal-hand-drawn-paint-260nw-1091983259.jpg")
                $requestParams = @{
                    Method = 'POST'
                    Uri    = "/workspace/api/v1/generativeai/chat"
                    Body   = @{
                        "modelName" = $Model
                        "messages"       = @( @{
                            "role"    = "User"
                            "content" = "Identify the texts written in the image"
                            "imageUrls" = $imageUrlsArray
                        })
                        "engagementCode" = $engagementCode
                        "parameters"     = @{
                            "max_tokens" = 10
                            "temperature" = 1
                            "frequency_penalty" = 0
                            "presence_penalty" = 0
                            "top_p" = 1
                            "enable_computer_vision"= $true
                            "enable_ocr"= $false
                            "enable_grounding" = $true
                            "image_detail" = "Low"
                        }
                    } | ConvertTo-Json -Depth 10
                }
                $response3 = @{}
                $response3 = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true
                $response3.choices.message | Should -Not -BeNullOrEmpty
                ($response3.choices.finishReason | Should -Not -BeNullOrEmpty) -and ($response3.choices.finishReason | Should -Not -Be "error")
                ($response.modelParams.PSObject.Properties.Name -contains "image_detail") -and ($response.modelParams.image_detail | Should -eq 'Low')
            }
            It "Verify the response for CHAT when computer vision, ocr and grounding all vision capability parameters are set to false (Positive TC)" -TestCases $ModelWithACVtestCases{
                Write-Host "CHAT: Models is $Model and all the vision capabilities are set to false"
                $imageUrlsArray = @("https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSMpopvsUpVtmLZHdNuaZ6MxbkL7ut-9pVX0Jw-l2JF6g&s")
                $requestParams = @{
                    Method = 'POST'
                    Uri    = "/workspace/api/v1/generativeai/chat"
                    Body   = @{
                        "modelName" = $Model
                        "messages"       = @( @{
                            "role"    = "User"
                            "content" = "Can you speculate on the meaning or message behind this image?"
                            "imageUrls" = $imageUrlsArray
                        })
                        "engagementCode" = $engagementCode
                        "parameters"     = @{
                            "max_tokens" = 10
                            "enable_computer_vision" = $false
                            "enable_ocr" = $false
                            "enable_grounding" = $false
                            "image_detail" = "Auto"
                        }
                    } | ConvertTo-Json -Depth 10
                }
                $response4 = @{}
                $response4 = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true
                $response4.choices.message | Should -Not -BeNullOrEmpty
                ($response4.choices.finishReason | Should -Not -BeNullOrEmpty) -and ($response4.choices.finishReason | Should -Not -Be "error")
                ($response.modelParams.PSObject.Properties.Name -contains "image_detail") -and ($response.modelParams.image_detail | Should -eq 'Auto')
            }
            It "Verify the response for CHAT when computer vision is true, ocr is false and grounding is not provided(Positive TC)" -TestCases $ModelWithACVtestCases{
                Write-Host "CHAT: Models is $Model and computer vision is true & ocr is false"
                $imageUrlsArray = @("https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQLcCXpsJ5boLRZJ_rYe4qa4QbwhtRQ8m1ZfWL2HSqTXg&s")
                $requestParams = @{
                    Method = 'POST'
                    Uri    = "/workspace/api/v1/generativeai/chat"
                    Body   = @{
                        "modelName" = $Model
                        "messages"       = @( @{
                            "role"    = "User"
                            "content" = "Describe the texts written in this image"
                            "imageUrls" = $imageUrlsArray
                        })
                        "engagementCode" = $engagementCode
                        "parameters"     = @{
                            "max_tokens" = 10
                            "enable_computer_vision" = $true
                            "enable_ocr" = $false
                            "image_detail" = "High"
                        }
                    } | ConvertTo-Json -Depth 10
                }
                $response5 = @{}
                $response5 = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true
                $response5.choices.message | Should -Not -BeNullOrEmpty
                ($response5.choices.finishReason | Should -Not -BeNullOrEmpty) -and ($response5.choices.finishReason | Should -Not -Be "error")
                ($response.modelParams.PSObject.Properties.Name -contains "image_detail") -and ($response.modelParams.image_detail | Should -eq 'High')
            }
            It "Verify the response for CHAT when model name with ACV is given and vision capabilities are not given(Positive TC)" -TestCases $ModelWithACVtestCases{
                Write-Host "CHAT: Models is $Model is given and vision capabilities are not given"
                $imageUrlsArray = @("https://www.homedecorcompany.in/cdn/shop/files/IMG_0753.jpg?v=1706204456")
                $requestParams = @{
                    Method = 'POST'
                    Uri    = "/workspace/api/v1/generativeai/chat"
                    Body   = @{
                        "modelName" = $Model
                        "messages"       = @( @{
                            "role"    = "User"
                            "content" = "Identify the different object in this image"
                            "imageUrls" = $imageUrlsArray
                        })
                        "engagementCode" = $engagementCode
                        "parameters"     = @{
                            "max_tokens" = 10
                            "temperature" = 1
                            "frequency_penalty" = 0
                            "presence_penalty" = 0
                            "top_p" = 1
                            "stop" = @("xyz")
                            "image_detail" = "Low"
                        }
                    } | ConvertTo-Json -Depth 10
                }
                $response6 = @{}
                $response6 = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true
                $response6.choices.message | Should -Not -BeNullOrEmpty
                ($response6.choices.finishReason | Should -Not -BeNullOrEmpty) -and ($response6.choices.finishReason | Should -Not -Be "error")
                ($response.modelParams.PSObject.Properties.Name -contains "image_detail") -and ($response.modelParams.image_detail | Should -eq 'Low')
            }
            It "Verify the response for CHAT when multiple imageurls are provided in a single role(Positive TC)" -TestCases $ModelWithACVtestCases{
                Write-Host "CHAT: Models is $Model and multiple urls are given in single role"
                $imageUrlsArray = @("https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQp1LMPVI39UP9aHKii79IXIi_3ORxgvRL6ZO_9fT3oMg&s", "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQB6VM7aas6m2tyV9Oy5sJMs3WjxUKdYukKQyQtvSCD3g&s")
                $requestParams = @{
                    Method = 'POST'
                    Uri    = "/workspace/api/v1/generativeai/chat"
                    Body   = @{
                        "modelName" = $Model
                        "messages"       = @( @{
                            "role"    = "User"
                            "content" = "Describe the two images"
                            "imageUrls" = $imageUrlsArray
                        })
                        "engagementCode" = $engagementCode
                        "parameters"     = @{
                            "max_tokens" = 10
                            "enable_computer_vision" = $true
                            "enable_ocr" = $true
                            "enable_grounding" = $true
                        }
                    } | ConvertTo-Json -Depth 10
                }
                $response7 = @{}
                $response7 = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true
                $response7.choices.message | Should -Not -BeNullOrEmpty
                ($response7.choices.finishReason | Should -Not -BeNullOrEmpty) -and ($response7.choices.finishReason | Should -Not -Be "error")
                ($response.modelParams.PSObject.Properties.Name -contains "image_detail") -and ($response.modelParams.image_detail | Should -eq 'Auto')
            }
            It "Verify the response for CHAT when ocr is set to true & grounding and computer vision parameters are not provided(Negative TC)" -TestCases $ModelWithACVtestCases{
                Write-Host "CHAT: Models is $Model and ocr is true"
                $imageUrlsArray = @("https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRMF8MXTtEebgU9dDog4s4T3lB9m01EzEeazodnlYWsxQ&s")
                $requestParams = @{
                    Method = 'POST'
                    Uri    = "/workspace/api/v1/generativeai/chat"
                    Body   = @{
                        "modelName" = $Model
                        "messages"       = @( @{
                            "role"    = "User"
                            "content" = "Hi! Please describe this image"
                            "imageUrls" = $imageUrlsArray
                        })
                        "engagementCode" = $engagementCode
                        "parameters"     = @{
                            "enable_ocr" = $true
                            "image_detail" = "High"
                        }
                    } | ConvertTo-Json -Depth 10
                }
                $response = @{}
                $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true
                $response.ExceptionResponse.StatusCode.value__ | Should -be 400
            }
            It "Verify the response for CHAT when grounding is set to true & ocr and computer vision parameters are not provided(Negative TC)" -TestCases $ModelWithACVtestCases{
                Write-Host "CHAT: Models is $Model and grounding is true"
                $imageUrlsArray = @("https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRMF8MXTtEebgU9dDog4s4T3lB9m01EzEeazodnlYWsxQ&s")
                $requestParams = @{
                    Method = 'POST'
                    Uri    = "/workspace/api/v1/generativeai/chat"
                    Body   = @{
                        "modelName" = $Model
                        "messages"       = @( @{
                            "role"    = "User"
                            "content" = "Hi! Please describe this image"
                            "imageUrls" = $imageUrlsArray
                        })
                        "engagementCode" = $engagementCode
                        "parameters"     = @{
                            "enable_grounding" = $true
                            "image_detail" = "Low"
                        }
                    } | ConvertTo-Json -Depth 10
                }
                $response = @{}
                $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true
                $response.ExceptionResponse.StatusCode.value__ | Should -be 400
            }
            It "Verify the response for CHAT when computer vision is false & ocr and grounding parameters are set to true(Negative TC)" -TestCases $ModelWithACVtestCases{
                Write-Host "CHAT: Models is $Model, computer vision is false & grounding and ocr are true"
                $imageUrlsArray = @("https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSMpopvsUpVtmLZHdNuaZ6MxbkL7ut-9pVX0Jw-l2JF6g&s")
                $requestParams = @{
                    Method = 'POST'
                    Uri    = "/workspace/api/v1/generativeai/chat"
                    Body   = @{
                        "modelName" = $Model
                        "messages"       = @( @{
                            "role"    = "User"
                            "content" = "Can you speculate on the meaning or message behind this image?"
                            "imageUrls" = $imageUrlsArray
                        })
                        "engagementCode" = $engagementCode
                        "parameters"     = @{
                            "max_tokens" = 10
                            "enable_computer_vision" = $false
                            "enable_ocr" = $true
                            "enable_grounding" = $true
                            "image_detail" = "Auto"
                        }
                    } | ConvertTo-Json -Depth 10
                }
                $response = @{}
                $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true
                $response.ExceptionResponse.StatusCode.value__ | Should -be 400
            }
            It "Verify the response for CHAT when imageurl is only accepted by models supporting vision capability(Neative TC)"{
                Write-Host "CHAT: Models is GPT 4 which does not support image url"
                $imageUrlsArray = @("https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTBj9BknrIvH-1dUyTZfDlcPX04yoGIqqmcAVBJujKacA&s")
                $requestParams = @{
                    Method = 'POST'
                    Uri    = "/workspace/api/v1/generativeai/chat"
                    Body   = @{
                        "modelName" = "GPT 4"
                        "messages"       = @( @{
                            "role"    = "User"
                            "content" = "Identify the different colours"
                            "imageUrls" = $imageUrlsArray
                        })
                        "engagementCode" = $engagementCode
                        "parameters"     = @{
                            "max_tokens" = 10
                            "image_detail" = "Low"
                        }
                    } | ConvertTo-Json -Depth 10
                }
                $response = @{}
                $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true
                $response.ExceptionResponse.StatusCode.value__ | Should -be 400
            }
            It "Verify the response for CHATSTREAM for model with ACV and unsupported vision capabilities are provided(Negative TC)"-TestCases $ModelWithACVtestCases{
                Write-Host "CHATSTREAM: Models is $Model and vision capabities paramaters are given"
                $imageUrlsArray = @("https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTXMQHDCgFgfrBo9b9mn5DVDVN3Lojv6CWRyFNgvbUNLg&s")
                $requestParams = @{
                    Method = 'POST'
                    Uri    = "/workspace/api/v1/generativeai/chat/stream"
                    Body   = @{
                        "modelName" = $Model
                        "messages"       = @( @{
                            "role"    = "User"
                            "content" = "Hi! Please describe this image"
                            "imageUrls" = $imageUrlsArray
                        })
                        "engagementCode" = $engagementCode
                        "parameters"     = @{
                            "max_tokens" = 10
                            "enable_computer_vision" = $true
                            "enable_ocr" = $true
                            "enable_grounding" = $true
                        }
                    } | ConvertTo-Json -Depth 10
                }
                $response = @{}
                $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true
                $response.ExceptionResponse.StatusCode.value__ | Should -be 400
            }

            #without ACV testcases
            It "Verify the response for CHAT when model name without ACV with normal parameters are given(Positive TC)" -TestCases $ModelWithoutACVtestCases{
                Write-Host "CHAT: Models is $Model and normal parameters are given"
                $imageUrlsArray = @("https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRQtruiXEjhlw6HsqTT3VbIP0m5CvG8_QrqPqVrSr29lA&s")
                $requestParams = @{
                    Method = 'POST'
                    Uri    = "/workspace/api/v1/generativeai/chat"
                    Body   = @{
                        "modelName" = $Model
                        "messages"       = @( @{
                            "role"    = "User"
                            "content" = "Count the total number of objects"
                            "imageUrls" = $imageUrlsArray
                        })
                        "engagementCode" = $engagementCode
                        "parameters"     = @{
                            "max_tokens" = 10
                            "temperature" = 1
                            "frequency_penalty" = 0
                            "presence_penalty" = 0
                            "top_p" = 1
                            "stop" = @("xyz")
                        }
                    } | ConvertTo-Json -Depth 10
                }
                $response = @{}
                $response = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true
                $response.choices.message | Should -Not -BeNullOrEmpty
                ($response.choices.finishReason | Should -Not -BeNullOrEmpty) -and ($response.choices.finishReason | Should -Not -Be "error")
            }
            It "Verify the response for CHAT when the role is Assistant and imageurl is provided(Negative TC)" -TestCases $ModelWithoutACVtestCases{
                Write-Host "CHAT: Models is $Model and role is assistant"
                $imageUrlsArray = @("https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR11xy-ebzew9m5ZWRsguhedqSZQ5n-HuT_hdZXrKv8fA&s")
                $requestParams = @{
                    Method = 'POST'
                    Uri    = "/workspace/api/v1/generativeai/chat"
                    Body   = @{
                        "modelName" = $Model
                        "messages"       = @( @{
                            "role"    = "Assistant"
                            "content" = "Describe the image"
                            "imageUrls" = $imageUrlsArray
                        })
                        "engagementCode" = $engagementCode
                        "parameters"     = @{
                            "max_tokens" = 10
                            "image_detail" = "Auto"
                        }
                    } | ConvertTo-Json -Depth 10
                }
                $response = @{}
                $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true
                $response.ExceptionResponse.StatusCode.value__ | Should -be 400
            }            
            It "Verify the response for CHAT when unsupported file extension is provided in imageurl(Neative TC)" -TestCases $ModelWithoutACVtestCases{
                Write-Host "CHAT: Models is $Model and unsupported file is given in imageurl"
                $imageUrlsArray = @("https://encrypted-tbn0.gstatic.com/images?q=tbn.pdf")
                $requestParams = @{
                    Method = 'POST'
                    Uri    = "/workspace/api/v1/generativeai/chat"
                    Body   = @{
                        "modelName" = $Model
                        "messages"  = @( @{
                            "role"    = "User"
                            "content" = "Describe the picture"
                            "imageUrls" = $imageUrlsArray
                        })
                        "engagementCode" = $engagementCode
                        "parameters"     = @{
                            "max_tokens" = 10
                            "image_detail" = "Auto"
                        }
                    } | ConvertTo-Json -Depth 10
                }
                $response = @{}
                $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true
                $response.ExceptionResponse.StatusCode.value__ | Should -be 400
            }
            It "Verify the response for CHAT when model name without ACV and parameters supporting vision capability are given(Neative TC)"-TestCases $ModelWithoutACVtestCases{
                Write-Host "CHAT: Models is $Model and unsupported parameters are given"
                $imageUrlsArray = @("https://img.freepik.com/premium-psd/natural-text-with-beautiful-flowers_23-2150121964.jpg")
                $requestParams = @{
                    Method = 'POST'
                    Uri    = "/workspace/api/v1/generativeai/chat"
                    Body   = @{
                        "modelName" = $Model
                        "messages"       = @( @{
                            "role"    = "User"
                            "content" = "Identify the text written"
                            "imageUrls" = $imageUrlsArray
                        })
                        "engagementCode" = $engagementCode
                        "parameters"     = @{
                            "max_tokens" = 10
                            "enable_computer_vision" = $true
                            "enable_ocr" = $true
                            "enable_grounding" = $true
                            "image_detail" = "High"
                        }
                    } | ConvertTo-Json -Depth 10
                }
                $response = @{}
                $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true
                $response.ExceptionResponse.StatusCode.value__ | Should -be 400
            }
            It "Verify the response for CHATSTREAM GPT 4 Turbo Vision model with normal parameters(Positive TC)"-TestCases $ModelWithoutACVtestCases{
                Write-Host "CHATSTREAM: Models is $Model and normal parameters are given"
                $imageUrlsArray = @("https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQEs-xfSeo4zb1Rbjzd6HF3rWKhKS9fL__PbQxCWOpqJQ&s")
                $requestParams = @{
                    Method = 'POST'
                    Uri    = "/workspace/api/v1/generativeai/chat/stream"
                    Body   = @{
                        "modelName" = $Model
                        "messages"       = @( @{
                            "role"    = "User"
                            "content" = "Verify the position of objects in this image"
                            "imageUrls" = $imageUrlsArray
                        })
                        "engagementCode" = $engagementCode
                        "parameters"     = @{
                            "max_tokens" = 10
                            "temperature" = 1
                            "frequency_penalty" = 0
                            "presence_penalty" = 0
                            "top_p" = 1
                            "stop" = @("xyz")
                        }
                    } | ConvertTo-Json -Depth 10
                }
                $response = @{}
                $response = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true
                $response | Should -Not -BeNullOrEmpty
            }
            It "Verify the response for CHATSTREAM for GPT 4 Turbo Vision model when multiple url is given(Positive TC)"-TestCases $ModelWithoutACVtestCases{
                Write-Host "CHATSTREAM: Models is $Model and multiple urls are given"
                $imageUrl1 = @("https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR11xy-ebzew9m5ZWRsguhedqSZQ5n-HuT_hdZXrKv8fA&s")
                $imageUrl2 = @("https://images.unsplash.com/photo-1604005387021-78472965cd6e?q=80&w=1000&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8YmlyZCUyMGluJTIwc2t5fGVufDB8fDB8fHww")
                $requestParams = @{
                    Method = 'POST'
                    Uri    = "/workspace/api/v1/generativeai/chat/stream"
                    Body   = @{
                        "modelName" = $Model
                        "messages"       = @( @{
                            "role"    = "User"
                            "content" = "Describe the image"
                            "imageUrls" = $imageUrl1
                        }, @{
                            "role"    = "Assistant"
                            "content" = "I am an helpful assistant"
                        }, @{
                            "role"    = "User"
                            "content" = "Verify difference between these 2 pictures"
                            "imageUrls" = $imageUrl2
                        })
                        "engagementCode" = $engagementCode
                        "parameters"     = @{
                            "max_tokens" = 10
                            "temperature" = 1
                            "frequency_penalty" = 0
                            "presence_penalty" = 0
                            "top_p" = 1
                            "stop" = @("xyz")
                        }
                    } | ConvertTo-Json -Depth 10
                }
                $response = @{}
                $response = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true
                $response | Should -Not -BeNullOrEmpty
            }
            It "Verify the response for CHATSTREAM for model without ACV and unsupported vision capabilities are provided(Negative TC)"-TestCases $ModelWithoutACVtestCases{
                Write-Host "CHATSTREAM: Models is $Model and vision capabities paramaters are given"
                $imageUrlsArray = @("https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTXMQHDCgFgfrBo9b9mn5DVDVN3Lojv6CWRyFNgvbUNLg&s")
                $requestParams = @{
                    Method = 'POST'
                    Uri    = "/workspace/api/v1/generativeai/chat/stream"
                    Body   = @{
                        "modelName" = $Model
                        "messages"       = @( @{
                            "role"    = "User"
                            "content" = "Hi! Please describe this image"
                            "imageUrls" = $imageUrlsArray
                        })
                        "engagementCode" = $engagementCode
                        "parameters"     = @{
                            "max_tokens" = 10
                            "enable_computer_vision" = $true
                            "enable_ocr" = $true
                            "enable_grounding" = $true
                        }
                    } | ConvertTo-Json -Depth 10
                }
                $response = @{}
                $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true
                $response.ExceptionResponse.StatusCode.value__ | Should -be 400
            }
        }
    }
}
