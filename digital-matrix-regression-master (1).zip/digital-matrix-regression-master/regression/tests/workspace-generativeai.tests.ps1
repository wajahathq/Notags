param(

    [Parameter(Mandatory)]
    [ValidateNotNullOrEmpty()]
    $CurrentEnvironmentData

)

$script:engagementCode = "803000012512"
$SkipEnvironmentList = @('UAT', 'Production')
BeforeDiscovery {
    Write-Host "Fetching GEOLOCATION Feature state"

    $requestParams = @{
        Method = 'GET'
        Uri    = "/workspace/api/v1/feature/Workspace | GenerativeAI | EnableUserGeoLocation"

    }

    $response = $null
    $response = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true
    Write-Host "Response from get feature $response"
    $global:SkipGenAIFeature = $false
    if ($response -eq $true) {
        $global:SkipGenAIFeature = $true
        Write-Host "GeoLocation Flag is Enable in $($CurrentEnvironmentData.Environment) Skiping all the Testcases "
    }
    else {
        Write-Host "GeoLocation Flag is Disable in $($CurrentEnvironmentData.Environment)  Proceeding with Gen AI Testcases in commercial Cloud"
    }


}
Describe "Generative AI Testcases for Commercial Cloud - Geolocation is Disable" -Skip:($SkipGenAIFeature) {

    Describe "Generative AI APIs for Capability --AzureOpenAI  Chat" {
        Context "To Verify APIs related to Capability - AzureOpenAI CHAT" {
            BeforeDiscovery {
                Write-Host "Selected Capability is :Azure Open AI CHAT"
                $requestParams = @{
                    Method = 'GET'
                    Uri    = "/workspace/api/v1/generativeai/model?providers=AzureOpenAI&capabilities=Chat&enabledCapabilitiesOnly=true"
                }

                $ChatCapabilityResponse = @{}
                $ChatCapabilityResponse = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true

                $ChattestCases = New-Object System.Collections.Generic.List[Hashtable]
                Write-Host "Fetch the list of only enabled Models"

                foreach ($Item in $ChatCapabilityResponse) {
                    If ($Item.modelName -notmatch ".*Dummy.*") {
                        if($Item.modelName -match ".*o3-mini.*" -or $Item.modelName -match ".*o1.*") {
                            $ChattestCases.Add(@{
                                'Model' = $($Item.modelName)
                                'Tokens' = "max_completion_tokens"
                            })
                         } else {
                            $ChattestCases.Add(@{
                                'Model' = $($Item.modelName)
                                'Tokens' = "max_tokens"
                            })
                         }
                        
                    }
                }

                Write-Host " No of testcases : $($ChattestCases.Count)"

            }

            It "Test Case 270723: ST_TC_DM_259473: To Verify Completion  in all Models where Capabilty  = CHAT with only Mandatory parameters" -TestCases $ChattestCases {
                Write-Host "CHAT - Model with Mandatory Parameters ----  " + $_.Model
                $response = Create-GenAI-ChatResponse -Model $Model

                $response | Should -Not -BeNullOrEmpty

            }
            It "Test Case 270724: ST_TC_DM_259473: To Verify Completion  in all Models where Capabilty  = CHAT with all optional Parametes Min Value" -TestCases $ChattestCases[0] {
                Write-Host "CHAT - Hardcoded Model with Min Values Parameters ----  " + $_.Model
                $requestParams = @{
                    Method = 'POST'
                    Uri    = "/workspace/api/v1/generativeai/chat"
                    Body   = @{
                        "modelName"      = $Model
                        "engagementCode" = $engagementCode
                        "messages"       = @( @{
                                "role"    = "User"
                                "content" = "Who won the Cricket World Cup in 1983"
                            }, @{
                                "role"    = "Assistant"
                                "content" = "India won WC 1983 by defeating defending champions (team I performed asked for originally) West Indies."
                            }, @{
                                "role"    = "User"
                                "content" = "Who won was the MAN of the MATCH"
                            })
                        "parameters"     = @{
                            "temperature"       = 0
                            $_.Tokens           = 1
                            "top_p"             = 0
                            "frequency_penalty" = -2
                            "presence_penalty"  = -2


                        }
                    } | ConvertTo-Json
                }
                $response = $null
                $response = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true
                Write-Host "Response with Min Values is  ---  $response"

                $response | Should -Not -BeNullOrEmpty

            }
            It "Test Case 270725: ST_TC_DM_259473: To Verify Completion  in all Models where Capabilty  = CHAT with all optional Parametes Max Value" -TestCases $ChattestCases[0] {
                Write-Host "CHAT - Model with Max Values Parameters -Running with Hardcoded Model --" + $_.Model
                $requestParams = @{
                    Method = 'POST'
                    Uri    = "/workspace/api/v1/generativeai/chat"
                    Body   = @{
                        "modelName"      = $Model
                        "engagementCode" = $engagementCode
                        "messages"       = @( @{
                                "role"    = "User"
                                "content" = "Who won the Cricket World Cup in 1983"
                            }, @{
                                "role"    = "Assistant"
                                "content" = "India won WC 1983 by defeating defending champions (team I performed asked for originally) West Indies."
                            }, @{
                                "role"    = "User"
                                "content" = "Who won was the MAN of the MATCH"
                            })
                        "parameters"     = @{
                            "temperature"       = 2
                            $_.Tokens           = 1
                            "top_p"             = 1
                            "frequency_penalty" = 2
                            "presence_penalty"  = 2


                        }
                    } | ConvertTo-Json
                }
                $ChatGenAIResponse = $null
                $ChatGenAIResponse = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true
                Write-Host "Response for all fields is ---  $ChatGenAIResponse"
                $ChatGenAIResponse | Should -Not -BeNullOrEmpty
            }
            It "Test Case 270726: ST_TC_DM_259473:  Negative TC To Verify Error in Completion  in all Models where Capabilty  = CHAT with Invalid Parameters Values" -TestCases $ChattestCases[0] {
                Write-Host "CHAT - Model with Max Values Parameters -Running only one 1st Model----  " + $_.Model
                $requestParams = @{
                    Method = 'POST'
                    Uri    = "/workspace/api/v1/generativeai/chat"
                    Body   = @{
                        "modelName"      = $Model
                        "engagementCode" = $engagementCode
                        "messages"       = @( @{
                                "role"    = "User"
                                "content" = "Who won the Cricket World Cup in 1983"
                            }, @{
                                "role"    = "Assistant"
                                "content" = "India won WC 1983 by defeating defending champions (team I performed asked for originally) West Indies."
                            }, @{
                                "role"    = "User"
                                "content" = "Who won was the MAN of the MATCH"
                            })
                        "parameters"     = @{
                            "temperature"       = Get-Random -Minimum 13 -Maximum 22
                            "max_tokens"        = Get-Random -Minimum 987654 -Maximum 2345676
                            "top_p"             = Get-Random -Minimum 1 -Maximum 4
                            "frequency_penalty" = Get-Random -Minimum -12 -Maximum 12
                            "presence_penalty"  = Get-Random -Minimum -12 -Maximum 12

                        }
                    } | ConvertTo-Json
                }
                $response = @{}
                $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true
                Write-Host "Response ---  $($response.ErrorDetails.message)"
                $response.ExceptionResponse.StatusCode.value__ | Should -be 400

            }

        }
    }

    Describe "Generative AI APIs for Capability-- AzureOpenAI Text" {
        Context "To Verify APIs related to Capability - Text" {
            BeforeDiscovery {
                Write-Host "Selected Capability is : TEXT"
                $requestParams = @{
                    Method = 'GET'
                    Uri    = "/workspace/api/v1/generativeai/model?providers=AzureOpenAI&capabilities=text&enabledCapabilitiesOnly=true"
                }

                $TextCapabilityResponse = @{}
                $TextCapabilityResponse = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true

                $TexttestCases = New-Object System.Collections.Generic.List[Hashtable]
                Write-Host "Fetch the list of only enabled Models"

                foreach ($Item in $TextCapabilityResponse) {

                    If ($Item.modelName -notmatch ".*Dummy.*") {
                        $TexttestCases.Add(@{
                                'Model' = $($Item.modelName)
                            })
                    }
                }

                Write-Host " No of testcases : $($TexttestCases.Count)"
            }
            It "Test Case 270727: ST_TC_DM_259473: To Verify Completion  in all Models where Capabilty  = TEXT with only Mandatory parameters" -TestCases $TexttestCases {
                Write-Host "TEXT - Model with Mandatory Parameters ----  " + $_.Model
                $response = Create-GenAI-TextResponse -Model $Model
                $response | Should -Not -BeNullOrEmpty

            }
            It "Test Case 270728: ST_TC_DM_259473: To Verify Completion  in all Models where Capabilty  = TEXT with all optional Parametes Min Value " -TestCases $TexttestCases[0] {
                Write-Host "TEXT - Model with Min Values Parameters -Running for Model--- " + $_.Model
                $requestParams = @{
                    Method = 'POST'
                    Uri    = "/workspace/api/v1/generativeai/text"
                    Body   = @{
                        "modelName"      = $Model
                        "engagementCode" = $engagementCode
                        "prompt"         = "Who won the Cricket World Cup in 2011"
                        "parameters"     = @{
                            "temperature"       = 0
                            "max_tokens"        = 1  #Marking as 1 to reduce consumtion of tokens
                            "frequency_penalty" = -2
                            "presence_penalty"  = -2
                            #"n"                 = 1

                        }
                    } | ConvertTo-Json
                }
                $TextGenAIResponse = $null
                $TextGenAIResponse = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true
                $TextGenAIResponse | Should -Not -BeNullOrEmpty
            }
            It "Test Case 270729: ST_TC_DM_259473: To Verify Completion  in all Models where Capabilty  = TEXT with all optional Parametes Max Value" -TestCases $TexttestCases[0] {
                Write-Host "TEXT - Model with Max Values Parameters for 1st Model is ---  " + $_.Model
                $requestParams = @{
                    Method = 'POST'
                    Uri    = "/workspace/api/v1/generativeai/text"
                    Body   = @{
                        "modelName"      = $Model
                        "engagementCode" = $engagementCode
                        "prompt"         = "Who won the Cricket World Cup in 1983"
                        "parameters"     = @{
                            "temperature"       = 2
                            "max_tokens"        = 1  #Marking as 1 to reduce consumtion of tokens
                            "frequency_penalty" = 2
                            "presence_penalty"  = 2
                            #"n"                 = 100

                        }
                    } | ConvertTo-Json
                }
                $TextGenAIResponse3 = $null
                $TextGenAIResponse3 = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true
                $TextGenAIResponse3 | Should -Not -BeNullOrEmpty

            }
            It "Test Case 270730: ST_TC_DM_259473:  Negative TC To Verify Completion  in all Models where Capabilty  = TEXT with Invalid Parameters Values" -TestCases $TexttestCases[0] {
                Write-Host "TEXT - Model with Invalid Values Parameters - Running only one 1st Model----  " + $_.Model

                $requestParams = @{
                    Method = 'POST'
                    Uri    = "/workspace/api/v1/generativeai/text"
                    Body   = @{
                        "modelName"      = $Model
                        "engagementCode" = $engagementCode
                        "prompt"         = "can you tell me a joke?"
                        "parameters"     = @{
                            "temperature"       = Get-Random -Minimum 99 -Maximum 229
                            "max_tokens"        = Get-Random -Minimum -20 -Maximum -10
                            "frequency_penalty" = Get-Random -Minimum -129 -Maximum 129
                            "presence_penalty"  = Get-Random -Minimum -129 -Maximum 129
                            #"n"                 = Get-Random -Minimum 12 -Maximum 1001

                        }
                    } | ConvertTo-Json
                }
                $response = @{}
                $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true
                Write-Host "Response ---  $($response.ErrorDetails.message)"
                $response.ExceptionResponse.StatusCode.value__ | Should -be 400
            }

        }
    }

    Describe "Generative AI APIs for Capability --AzureOpenAI Chat Streaming " {
        Context "To Verify APIs related to Capability - Chat Streaming" {
            BeforeDiscovery {
                Write-Host "Selected Capability is : ChatStreaming"
                $requestParams = @{
                    Method = 'GET'
                    Uri    = "/workspace/api/v1/generativeai/model?providers=AzureOpenAI&capabilities=ChatStreaming&enabledCapabilitiesOnly=true"
                }

                $ChatStreamingCapabilityResponse = @{}
                $ChatStreamingCapabilityResponse = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true

                $ChatStreamingTestCases = New-Object System.Collections.Generic.List[Hashtable]

                foreach ($Item in $ChatStreamingCapabilityResponse) {
                    If ($Item.modelName -notmatch ".*Dummy.*") {
                        $ChatStreamingTestCases.Add(@{
                                'Model' = $($Item.modelName)
                            })
                    }
                }

                Write-Host " No of testcases : $($ChatStreamingTestCases.Count)"
            }


            It "Test Case 270735: ST_TC_DM_259473: To Verify Completion  in all Models where Capabilty  = CHAT STREAMING with only Mandatory parameters" -TestCases $ChatStreamingTestCases {
                Write-Host "ChatStreaming - Model with Mandatory Parameters ---- " + $_.Model
                $response = Create-GenAI-ChatStreamResponse -Model $Model

                $response | Should -Not -BeNullOrEmpty

            }

            It "Test Case 270736: ST_TC_DM_259473: To Verify Completion  in all Models where Capabilty  = CHAT STREAMING with all optional Parametes Min Value" -TestCases $ChatStreamingTestCases[0] {
                Write-Host "ChatStreaming - Model with Min Values Parameters - Running for----- " + $_.Model
                $requestParams = @{
                    Method = 'POST'
                    Uri    = "/workspace/api/v1/generativeai/chat/stream"
                    Body   = @{
                        "modelName"      = $Model
                        "engagementCode" = $engagementCode
                        "messages"       = @( @{
                                "role"    = "User"
                                "content" = "Who won the Cricket World Cup in 1983"
                            }, @{
                                "role"    = "Assistant"
                                "content" = "India won WC 1983 by defeating defending champions (team I performed asked for originally) West Indies."
                            }, @{
                                "role"    = "User"
                                "content" = "Who won was the MAN of the MATCH"
                            })
                        "parameters"     = @{
                            "temperature"       = 0
                            "max_tokens"        = 1
                            "top_p"             = 0
                            "frequency_penalty" = -2
                            "presence_penalty"  = -2
                            #"n"                 = 1

                        }
                    } | ConvertTo-Json
                }
                $response = $null
                $response = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true
                Write-Host "Response with Min Values is  ---  $response"

                $response | Should -Not -BeNullOrEmpty


            }

            It "Test Case 270737: ST_TC_DM_259473: To Verify Completion  in all Models where Capabilty  = CHAT STREAMING with all optional Parametes Max Value" -TestCases $ChatStreamingTestCases[0] {
                Write-Host "ChatStreaming - Model with Max Values Parameters - Running only 1st model -- " + $_.Model
                $requestParams = @{
                    Method = 'POST'
                    Uri    = "/workspace/api/v1/generativeai/chat/stream"
                    Body   = @{
                        "modelName"      = $Model
                        "engagementCode" = $engagementCode
                        "messages"       = @( @{
                                "role"    = "User"
                                "content" = "Who won the Cricket World Cup in 1983"
                            }, @{
                                "role"    = "Assistant"
                                "content" = "India won WC 1983 by defeating defending champions (team I performed asked for originally) West Indies."
                            }, @{
                                "role"    = "User"
                                "content" = "Who won was the MAN of the MATCH"
                            })
                        "parameters"     = @{
                            "temperature"       = 2
                            "max_tokens"        = 1
                            "top_p"             = 1
                            "frequency_penalty" = 2
                            "presence_penalty"  = 2
                            #"n"                 = 100

                        }
                    } | ConvertTo-Json
                }
                $ChatSGenAIResponse = $null
                $ChatSGenAIResponse = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true
                Write-Host "Response for all fields is ---  $ChatSGenAIResponse"

                $ChatSGenAIResponse | Should -Not -BeNullOrEmpty

            }

            It "Test Case 270738: ST_TC_DM_259473:  Negative TC To Verify Completion  in all Models where Capabilty  = CHAT STREAMING with Invalid Parameters Values" -TestCases $ChatStreamingTestCases[0] {
                Write-Host "ChatStreaming - Model with Invalid Values Parameters - Running only first model ---- "  + $_.Model
                $requestParams = @{
                    Method = 'POST'
                    Uri    = "/workspace/api/v1/generativeai/chat/stream"
                    Body   = @{
                        "modelName"      = $Model
                        "engagementCode" = $engagementCode
                        "messages"       = @( @{
                                "role"    = "User"
                                "content" = "Who won the Cricket World Cup in 1983"
                            }, @{
                                "role"    = "Assistant"
                                "content" = "India won WC 1983 by defeating defending champions (team I performed asked for originally) West Indies."
                            }, @{
                                "role"    = "User"
                                "content" = "Who won was the MAN of the MATCH"
                            })
                        "parameters"     = @{
                            "temperature"       = Get-Random -Minimum 99 -Maximum 888
                            "max_tokens"        = Get-Random -Minimum 1987654 -Maximum 2345676
                            "top_p"             = Get-Random -Minimum 15 -Maximum 24
                            "frequency_penalty" = Get-Random -Minimum -12 -Maximum 12
                            "presence_penalty"  = Get-Random -Minimum -12 -Maximum 12
                            #"n"                 = Get-Random -Minimum 12 -Maximum 1001

                        }
                    } | ConvertTo-Json
                }
                $response = @{}
                $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true
                Write-Host "Response ---  $($response.ErrorDetails.message)"
                $response.ExceptionResponse.StatusCode.value__ | Should -be 400
            }

        }
    }

    Describe "Generative AI APIs for Capability AzureOpenAI TextStreaming" {
        Context "To Verify APIs related to Capability - TextStreaming" {
            BeforeDiscovery {
                Write-Host "Selected Capability is : TextStreaming"
                $requestParams = @{
                    Method = 'GET'
                    Uri    = "/workspace/api/v1/generativeai/model?providers=AzureOpenAI&capabilities=textStreaming&enabledCapabilitiesOnly=true"
                }

                $TextStreamingCapabilityResponse = @{}
                $TextStreamingCapabilityResponse = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true

                $TextStreamingTestCases = New-Object System.Collections.Generic.List[Hashtable]

                foreach ($Model in $TextStreamingCapabilityResponse.modelName) {
                    If ($Model -notmatch ".*Dummy.*") {
                        $TextStreamingTestCases.Add(@{
                                'Model' = $Model
                            })
                        $TextStreamingModelList += $($Model)
                    }
                }
                Write-Host "Models available for TextStreaming are $($TextStreamingModelList)"

            }

            It "Test Case 270723: ST_TC_DM_259473: To Verify Completion in all Models where Capabilty = TextStreaming with only Mandatory parameters" -TestCases $TextStreamingTestCases {
                Write-Host "TextStreaming - Model with Mandatory Parameters ---- " + $_.Model
                $response = Create-GenAI-TextStreamResponse -Model $Model

                $response | Should -Not -BeNullOrEmpty

            }

            It "Test Case 270724: ST_TC_DM_259473: To Verify Completion in all Models where Capabilty = TextStreaming with all optional Parametes Min Value" -TestCases $TextStreamingTestCases[0] {
                Write-Host "TextStreaming - Model with Min Values Parameters - Running for ---- " + $_.Model
                $requestParams = @{
                    Method = 'POST'
                    Uri    = "/workspace/api/v1/generativeai/text/stream"
                    Body   = @{
                        "modelName"      = $Model
                        "engagementCode" = $engagementCode
                        "prompt"         = "Who won the Cricket World Cup in 1983"
                        "parameters"     = @{
                            "temperature"       = 0.0
                            "max_tokens"        = 1
                            "frequency_penalty" = -2
                            "presence_penalty"  = -2
                            #"n"                 = 1

                        }
                    } | ConvertTo-Json
                }
                $TextSGenAIResponse = $null
                $TextSGenAIResponse = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true
                Write-Host "Response for all fields is ---  $TextSGenAIResponse"

                $TextSGenAIResponse | Should -Not -BeNullOrEmpty

            }

            It "Test Case 270724: ST_TC_DM_259473: To Verify Completion in all Models where Capabilty = TextStreaming with all optional Parametes Max Value" -TestCases $TextStreamingTestCases[0] {
                Write-Host "TextStreaming - Model with Max Values Parameters - Running for " + $_.Model
                $requestParams = @{
                    Method = 'POST'
                    Uri    = "/workspace/api/v1/generativeai/text/stream"
                    Body   = @{
                        "modelName"      = $Model
                        "engagementCode" = $engagementCode
                        "prompt"         = "Who won the Cricket World Cup in 1983"
                        "parameters"     = @{
                            "temperature"       = 2
                            "max_tokens"        = 1 #Making default one to Reduce Consumtion of Tokens
                            "frequency_penalty" = 2
                            "presence_penalty"  = 2
                            #"n"                 = 100

                        }
                    } | ConvertTo-Json
                }
                $TextSGenAIResponse = $null
                $TextSGenAIResponse = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true
                $TextSGenAIResponse | Should -Not -BeNullOrEmpty

            }

            It "Test Case 270726: ST_TC_DM_259473: Negative TC To Verify Error in Completion in all Models where Capabilty = TextStreaming with Invalid Parameters Values" -TestCases $TextStreamingTestCases[0] {
                Write-Host "TextStreaming - Model with Invalid Values Parameters - Running only first model ---- " + $_.Model
                $requestParams = @{
                    Method = 'POST'
                    Uri    = "/workspace/api/v1/generativeai/text/stream"
                    Body   = @{
                        "modelName"      = $Model
                        "engagementCode" = $engagementCode
                        "prompt"         = "Who won the Cricket World Cup in 1983"
                        "parameters"     = @{
                            "temperature"       = Get-Random -Minimum -13 -Maximum -10
                            "max_tokens"        = Get-Random -Minimum -20 -Maximum -10
                            "frequency_penalty" = Get-Random -Minimum -1211 -Maximum 2121
                            "presence_penalty"  = Get-Random -Minimum -1211 -Maximum 2121
                            #"n"                 = Get-Random -Minimum 12 -Maximum 1001

                        }
                    } | ConvertTo-Json
                }
                $response = @{}
                $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true
                Write-Host "Response ---  $($response.ErrorDetails.message)"
                $response.ExceptionResponse.StatusCode.value__ | Should -be 400
            }

        }
    }

    Describe "Generative AI APIs for Capability AzureOpenAI Embeddings" {
        Context "To Verify APIs related to Capability - Embeddings" {
            BeforeDiscovery {
                Write-Host "Selected Capability is: EMBEDDINGS"
                $requestParams = @{
                    Method = 'GET'
                    Uri    = "/workspace/api/v1/generativeai/model?providers=AzureOpenAI&capabilities=embeddings&enabledCapabilitiesOnly=true"
                }

                $EmbeddingsCapabilityResponse = @{}
                $EmbeddingsCapabilityResponse = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true

                $EmbeddingsTestCases = New-Object System.Collections.Generic.List[Hashtable]

                foreach ($Item in $EmbeddingsCapabilityResponse) {

                    If ($Item.modelName -notmatch ".*Dummy.*") {
                        $EmbeddingsTestCases.Add(@{
                                'Model' = $($Item.modelName)
                            })
                    }
                }

                Write-Host " No of testcases : $($ChatStreamingTestCases.Count)"
            }
            It "Test Case 270723: ST_TC_DM_259473: To Verify Completion in all Models where Capability = embeddings with only Mandatory parameters" -TestCases $EmbeddingsTestCases {
                Write-Host "Embeddings - Model with Mandatory Parameters ---- " + $_.Model
                $response = Create-GenAI-EmbeddingsResponse -Model $Model

                $response | Should -Not -BeNullOrEmpty

            }


            It "Test Case 270726: ST_TC_DM_259473: Negative TC To Verify Error in Completion in all Models where Capability = embeddings with Invalid Parameters Values"  -TestCases $EmbeddingsTestCases[0] {
                Write-Host "Embeddings - Model with Invalid Parameters - Running only first model ---- " + $_.Model
                $requestParams = @{
                    Method = 'POST'
                    Uri    = "/workspace/api/v1/generativeai/Embeddings"
                    Body   = @{
                        "modelName"      = $Model
                        "engagementCode" = "Invalid9876567874"
                        "input"          = "Who won the Cricket World Cup in 1983"
                    } | ConvertTo-Json
                }
                $response = @{}
                $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true
                Write-Host "Response ---  $($response.ErrorDetails.message)"
                $response.ExceptionResponse.StatusCode.value__ | Should -be 404
            }

        }
    }

    Describe "Generative AI APIs for Cohere with Chat capability" {
        Context "To Verify APIs related to Cohere with Chat capability" {
            BeforeDiscovery {
                Write-Host "Selected Capability is : Cohere - Chat"
                $requestParams = @{
                    Method = 'GET'
                    Uri    = "/workspace/api/v1/generativeai/model?providers=Cohere&capabilities=Chat"
                }

                $CohereChatResponse = @{}
                $CohereChatResponse = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true

                $CohereChattestCases = New-Object System.Collections.Generic.List[Hashtable]
                Write-Host "Fetch the list of only enabled Models for Chat"

                foreach ($Item in $CohereChatResponse) {
                    If ($Item.modelName -notmatch ".*Dummy.*") {
                        $CohereChattestCases.Add(@{
                                'Model' = $($Item.modelName)
                            })
                    }
                }
                Write-Host "No of models available for Chat: $($CohereChattestCases.Count)"
            }
            It "Verify Completion in all Models where Capabilty = Chat with only Mandatory fields" -TestCases $CohereChattestCases {
                Write-Host "Cohere with Chat with all Mandatory fields for model---- " + $_.Model
                $response = Create-GenAI-ChatResponse -Model $Model

                $response | Should -Not -BeNullOrEmpty
            }

            It "Verify Completion for Command Model where Capabilty  = Chat including all optional Parametes with default values" -TestCases $CohereChattestCases[0] {
                Write-Host "Cohere with Chat with all available fields"
                $requestParams = @{
                    Method = 'POST'
                    Uri    = "/workspace/api/v1/generativeai/chat"
                    Body   = @{
                        "modelName"      = $Model
                        "engagementCode" = $engagementCode
                        "messages"       = @( @{
                                "role"    = "User"
                                "content" = "What is Global Warming?"
                            })
                        "parameters"     = @{
                            "citation_quality"    = "accurate"
                            "prompt_truncation"   = "AUTO"
                            "search_queries_only" = $false
                            "temperature"         = 0.3
                            #"connectors"          = @(@{"id" = "web-search" })
                            "preamble_override"   = 0.3
                        }
                    } | ConvertTo-Json
                }

                $response = @{}
                $response = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true
                Write-Host "Response with all available field for Chat of Cohere is  ---  $response"

                $response | Should -Not -BeNullOrEmpty
            }

            It "Verify Completion in Command Models where Capabilty  = Chat with missing mandatory field" -TestCases $CohereChattestCases[0] {
                Write-Host "Cohere with Chat where mandatory field is missing"
                $requestParams = @{
                    Method = 'POST'
                    Uri    = "/workspace/api/v1/generativeai/chat"
                    Body   = @{
                        "modelName" = $Model
                        "messages"  = @( @{
                                "role"    = "User"
                                "content" = "What is Global Warming?"
                            })
                    } | ConvertTo-Json
                }
                Write-Host "Model name for missing mandatory fields here is - $Model"
                $response = @{}
                $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true
                Write-Host "Response for missing mandatory fields for Chat of Cohere is ---  $($response.ErrorDetails.errors.EngagementCode)"
                $response.ExceptionResponse.StatusCode.value__ | Should -be 400

            }

        }
    }

    Describe "Generative AI APIs for Cohere with ChatStreaming capability" {
        Context "To Verify APIs related to Cohere with ChatStreaming capability" {
            BeforeDiscovery {
                Write-Host "Selected Capability is : Cohere - ChatStreaming"
                $requestParams = @{
                    Method = 'GET'
                    Uri    = "/workspace/api/v1/generativeai/model?providers=Cohere&capabilities=ChatStreaming"
                }

                $CohereChatStreamingResponse = @{}
                $CohereChatStreamingResponse = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true

                $CohereChatStreamingTestCases = New-Object System.Collections.Generic.List[Hashtable]
                Write-Host "Fetch the list of only enabled Models for ChatStreaming"

                foreach ($Item in $CohereChatStreamingResponse) {
                    If ($Item.modelName -notmatch ".*Dummy.*") {
                        $CohereChatStreamingTestCases.Add(@{
                                'Model' = $($Item.modelName)
                            })
                    }
                }
                Write-Host "No of models available for ChatStreaming : $($CohereChatStreamingTestCases.Count)"
            }

            It "Verify Completion in all Models where Capabilty = ChatStreaming with only Mandatory fields" -TestCases $CohereChatStreamingTestCases {
                Write-Host "Cohere with ChatStreaming with all Mandatory fields ----  " + $_.Model
                $response = Create-GenAI-ChatStreamResponse -Model $Model

                $response | Should -Not -BeNullOrEmpty

            }
            It "Verify Completion for Command Model where Capabilty  = ChatStreaming including all optional Parametes with default values" -TestCases $CohereChatStreamingTestCases[0] {
                Write-Host "Cohere with ChatStreaming with all available fields" + $_.Model
                $requestParams = @{
                    Method = 'POST'
                    Uri    = "/workspace/api/v1/generativeai/chat/stream"
                    Body   = @{
                        "modelName"      = $Model
                        "engagementCode" = $engagementCode
                        "messages"       = @( @{
                                "role"    = "User"
                                "content" = "What is Global Warming?"
                            })
                        "parameters"     = @{
                            "citation_quality"    = "accurate"
                            "prompt_truncation"   = "AUTO"
                            "search_queries_only" = $false
                            "temperature"         = 0.3
                            #"connectors"          = @(@{"id" = "web-search" })
                            "preamble_override"   = 0.3
                        }
                    } | ConvertTo-Json
                }

                $response = $null
                $response = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true
                Write-Host "Response with all available field for ChatStreaming of Cohere is  ---  $response"

                $response | Should -Not -BeNullOrEmpty

            }
            It "Verify Completion in Command Models where Capabilty  = ChatStreaming with missing mandatory field" -TestCases $CohereChatStreamingTestCases[0] {
                Write-Host "Cohere with ChatStreaming where mandatory field is missing" + $_.Model
                $requestParams = @{
                    Method = 'POST'
                    Uri    = "/workspace/api/v1/generativeai/chat/stream"
                    Body   = @{
                        "modelName" = $Model
                        "messages"  = @( @{
                                "role"    = "User"
                                "content" = "What is Global Warming?"
                            })
                    } | ConvertTo-Json
                }
                $response = @{}
                $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true
                Write-Host "Response for missing mandatory fields for ChatStreaming of Cohere is ---  $($response.ErrorDetails.errors.EngagementCode)"
                $response.ExceptionResponse.StatusCode.value__ | Should -be 400

            }
            <# It "Verify Completion in Command Models where Capabilty  = ChatStreaming with invalid parameter value" -TestCases $CohereChatStreamingTestCases[0] {
                Write-Host "Cohere with ChatStreaming where parameter value is incorrect"
                $requestParams = @{
                    Method = 'POST'
                    Uri    = "/workspace/api/v1/generativeai/chat/stream"
                    Body   = @{
                        "modelName"      = $Model
                        "engagementCode" = $engagementCode
                        "messages"       = @( @{
                                "role"    = "User"
                                "content" = "Who won the Cricket World Cup in 1983"
                            })
                        "parameters"     = @{
                            "citation_quality" = "12345abcde"
                        }
                    } | ConvertTo-Json
                }
                $response = @{}
                $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true
                Write-Host "Response for invalid parameter for ChatStreaming of Cohere is ---  $($response.ErrorDetails.message)"
                $response.ExceptionResponse.StatusCode.value__ | Should -be 400

            }#>

        }
    }

    Describe "Generative AI APIs for Cohere with Text capability" {
        Context "To Verify APIs related to Cohere with Text capability" {
            BeforeDiscovery {
                Write-Host "Selected Capability is : Cohere - Text"
                $requestParams = @{
                    Method = 'GET'
                    Uri    = "/workspace/api/v1/generativeai/model?providers=Cohere&capabilities=Text"
                }

                $CohereTextResponse = @{}
                $CohereTextResponse = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true

                $CohereTexttestCases = New-Object System.Collections.Generic.List[Hashtable]
                Write-Host "Fetch the list of only enabled Models for Text"

                foreach ($Item in $CohereTextResponse) {
                    If ($Item.modelName -notmatch ".*Dummy.*") {
                        $CohereTexttestCases.Add(@{
                                'Model' = $($Item.modelName)
                            })
                    }
                }
                Write-Host "No of models available for Text : $($CohereTexttestCases.Count)"
            }

            It "Verify Completion in all Models where Capabilty = Text with only Mandatory fields" -TestCases $CohereTexttestCases {
                Write-Host "Cohere with Text with all Mandatory fields ----  " + $_.Model
                $response = Create-GenAI-TextResponse -Model $Model

                $response | Should -Not -BeNullOrEmpty

            }
            It "Verify Completion for Command Model where Capabilty  = Text including all optional Parametes with default values" -TestCases $CohereTexttestCases[0] {
                Write-Host "Cohere with Text with all available fields"
                $requestParams = @{
                    Method = 'POST'
                    Uri    = "/workspace/api/v1/generativeai/text"
                    Body   = @{
                        "modelName"      = $Model
                        "engagementCode" = $engagementCode
                        "prompt"         = "Who is Bill Gates?"
                        "parameters"     = @{
                            "end_sequences"     = @("abc")
                            "frequency_penalty" = 1
                            "k"                 = 0
                            "max_tokens"        = 1
                            "p"                 = 0
                            "presence_penalty"  = 0
                            "stop_sequences"    = @("abc")
                            "temperature"       = 0.75
                            "truncate"          = "END"
                        }
                    } | ConvertTo-Json
                }

                $response = $null
                $response = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true
                Write-Host "Response with all available field for Text of Cohere is  ---  $response"

                $response | Should -Not -BeNullOrEmpty

            }
            It "Verify Completion in Command Models where Capabilty  = Text with missing mandatory field" -TestCases $CohereTexttestCases[0] {
                Write-Host "Cohere with Text where mandatory field is missing"
                $requestParams = @{
                    Method = 'POST'
                    Uri    = "/workspace/api/v1/generativeai/text"
                    Body   = @{
                        "modelName"      = $Model
                        "engagementCode" = $engagementCode
                    } | ConvertTo-Json
                }
                $response = @{}
                $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true
                Write-Host "Response for missing mandatory fields for Text of Cohere is ---  $($response.ErrorDetails.errors.Prompt)"
                $response.ExceptionResponse.StatusCode.value__ | Should -be 400

            }
            <#It "Verify Completion in Command Models where Capabilty  = Text with invalid parameter value" -TestCases $CohereTexttestCases[0] {
                Write-Host "Cohere with Text where parameter value is incorrect"
                $requestParams = @{
                    Method = 'POST'
                    Uri    = "/workspace/api/v1/generativeai/text"
                    Body   = @{
                        "modelName"      = $Model
                        "engagementCode" = $engagementCode
                        "prompt"         = "Who won the Cricket World Cup in 2023"
                        "parameters"     = @{
                            "truncate" = "12345abcde"
                        }
                    } | ConvertTo-Json
                }
                $response = @{}
                $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true
                Write-Host "Response for invalid parameter for Text of Cohere is ---  $($response.ErrorDetails.message)"
                $response.ExceptionResponse.StatusCode.value__ | Should -be 400

            }#>

        }
    }

    Describe "Generative AI APIs for Cohere with TextStreaming capability" {
        Context "To Verify APIs related to Cohere with TextStreaming capability" {
            BeforeDiscovery {
                Write-Host "Selected Capability is : Cohere - TextStreaming"
                $requestParams = @{
                    Method = 'GET'
                    Uri    = "/workspace/api/v1/generativeai/model?providers=Cohere&capabilities=TextStreaming"
                }

                $CohereTextStreamingResponse = @{}
                $CohereTextStreamingResponse = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true

                $CohereTextStreamingtestCases = New-Object System.Collections.Generic.List[Hashtable]
                Write-Host "Fetch the list of only enabled Models for TextStreaming"

                foreach ($Item in $CohereTextStreamingResponse) {
                    If ($Item.modelName -notmatch ".*Dummy.*") {
                        $CohereTextStreamingtestCases.Add(@{
                                'Model' = $($Item.modelName)
                            })
                    }
                }
                Write-Host "No of models available for TextStreaming : $($CohereTextStreamingtestCases.Count)"
            }

            It "Verify Completion in all Models where Capabilty = TextStreaming with only Mandatory fields" -TestCases $CohereTextStreamingtestCases {
                Write-Host "Cohere with TextStreaming with all Mandatory fields ----  " + $_.Model
                $response = Create-GenAI-TextStreamResponse -Model $Model

                $response | Should -Not -BeNullOrEmpty

            }
            It "Verify Completion for Command Model where Capabilty  = TextStreaming including all optional Parametes with default values" -TestCases $CohereTextStreamingtestCases[0] {
                Write-Host "Cohere with TextStreaming with all available fields --- " + $_.Model
                $requestParams = @{
                    Method = 'POST'
                    Uri    = "/workspace/api/v1/generativeai/text/stream"
                    Body   = @{
                        "modelName"      = $Model
                        "engagementCode" = $engagementCode
                        "prompt"         = "Who is Bill Gates?"
                        "parameters"     = @{
                            "end_sequences"     = @("abc")
                            "frequency_penalty" = 1
                            "k"                 = 0
                            "max_tokens"        = 1
                            "p"                 = 0
                            "presence_penalty"  = 0
                            "stop_sequences"    = @("abc")
                            "temperature"       = 0.75
                            "truncate"          = "END"
                        }
                    } | ConvertTo-Json
                }

                $response = $null
                $response = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true
                Write-Host "Response with all available field for TextStreaming of Cohere is  ---  $response"

                $response | Should -Not -BeNullOrEmpty

            }
            It "Verify Completion in Command Models where Capabilty  = TextStreaming with missing mandatory field" -TestCases $CohereTextStreamingtestCases[0] {
                Write-Host "Cohere with TextStreaming where mandatory field is missing" + $_.Model
                $requestParams = @{
                    Method = 'POST'
                    Uri    = "/workspace/api/v1/generativeai/text/stream"
                    Body   = @{
                        "engagementCode" = $engagementCode
                        "prompt"         = "Who won the Cricket World Cup in 2023"
                    } | ConvertTo-Json
                }
                $response = @{}
                $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true
                Write-Host "Response for missing mandatory fields for TextStreaming of Cohere is ---  $($response.ErrorDetails.errors.ModelName)"
                $response.ExceptionResponse.StatusCode.value__ | Should -be 400

            }
           <# It "Verify Completion in Command Models where Capabilty  = TextStreaming with invalid parameter value" -TestCases $CohereTextStreamingtestCases[0] {
                Write-Host "Cohere with TextStreaming where parameter value is incorrect"
                $requestParams = @{
                    Method = 'POST'
                    Uri    = "/workspace/api/v1/generativeai/text/stream"
                    Body   = @{
                        "modelName"      = $Model
                        "engagementCode" = $engagementCode
                        "prompt"         = "Who won the Cricket World Cup in 2023"
                        "parameters"     = @{
                            "temperature" = 6
                        }
                    } | ConvertTo-Json
                }
                $response = @{}
                $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true
                Write-Host "Response for invalid parameter for TextStreaming of Cohere is ---  $($response.ErrorDetails.message)"
                $response.ExceptionResponse.StatusCode.value__ | Should -be 400

            } #>

        }
    }

    Describe "Generative AI APIs for Cohere with Embeddings capability" {
        Context "To Verify APIs related to Cohere with Embeddings capability" {
            BeforeDiscovery {
                Write-Host "Selected Capability is : Cohere - Embeddings"
                $requestParams = @{
                    Method = 'GET'
                    Uri    = "/workspace/api/v1/generativeai/model?providers=Cohere&capabilities=Embeddings"
                }

                $CohereEmbeddingsResponse = @{}
                $CohereEmbeddingsResponse = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true

                $CohereEmbeddingstestCases = New-Object System.Collections.Generic.List[Hashtable]
                Write-Host "Fetch the list of only enabled Models for Embeddings"

                foreach ($Item in $CohereEmbeddingsResponse) {
                    If ($Item.modelName -notmatch ".*Dummy.*") {
                        $CohereEmbeddingstestCases.Add(@{
                                'Model' = $($Item.modelName)
                            })
                    }
                }
                Write-Host "No of models available for Embeddings : $($CohereEmbeddingstestCases.Count)"
            }

            It "Verify Completion in all Models where Capabilty = Embeddings with only Mandatory fields" -TestCases $CohereEmbeddingstestCases {
                Write-Host "Cohere with Embeddings with all Mandatory fields ----  " + $_.Model
                $response = Create-GenAI-EmbeddingsResponse -Model $Model

                $response | Should -Not -BeNullOrEmpty

            }
            It "Verify Completion for Command Model where Capabilty  = Embeddings including all optional Parametes with default values" -TestCases $CohereEmbeddingstestCases[0] {
                Write-Host "Cohere with Embeddings with all available fields"
                $requestParams = @{
                    Method = 'POST'
                    Uri    = "/workspace/api/v1/generativeai/embedding"
                    Body   = @{
                        "modelName"      = $Model
                        "engagementCode" = $engagementCode
                        "input"          = "Who is Bill Gates?"
                        "parameters"     = @{
                            "input_type" = "classification"
                            "truncate"   = "END"
                        }
                    } | ConvertTo-Json
                }

                $response = $null
                $response = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true
                Write-Host "Response with all available field for Embeddings of Cohere is  ---  $response"

                $response | Should -Not -BeNullOrEmpty

            }
            It "Verify Completion in Command Models where Capabilty  = Embeddings with missing mandatory field" -TestCases $CohereEmbeddingstestCases[0] {
                Write-Host "Cohere with Embeddings where mandatory field is missing"
                $requestParams = @{
                    Method = 'POST'
                    Uri    = "/workspace/api/v1/generativeai/embedding"
                    Body   = @{
                        "modelName"      = $Model
                        "engagementCode" = $engagementCode
                    } | ConvertTo-Json
                }
                $response = @{}
                $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true
                Write-Host "Response for missing mandatory fields for Embeddings of Cohere is ---  $($response.ErrorDetails.errors.Input)"
                $response.ExceptionResponse.StatusCode.value__ | Should -be 400

            }
            <# It "Verify Completion in Command Models where Capabilty  = Embeddings with invalid parameter value" -TestCases $CohereEmbeddingstestCases[0] {
                Write-Host "Cohere with Embeddings where parameter value is incorrect"
                $requestParams = @{
                    Method = 'POST'
                    Uri    = "/workspace/api/v1/generativeai/embedding"
                    Body   = @{
                        "modelName"      = $Model
                        "engagementCode" = $engagementCode
                        "input"          = "Who won the Cricket World Cup in 2023"
                        "parameters"     = @{
                            "input_type" = "2132131"
                        }
                    } | ConvertTo-Json
                }
                $response = @{}
                $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true
                Write-Host "Response for invalid parameter for Embeddings of Cohere is ---  $($response.ErrorDetails.message)"
                $response.ExceptionResponse.StatusCode.value__ | Should -be 400

            } #>

        }
    }
#The Models has been harcoded for checking the status of the model and modifying it later. this has to be disucssed and fixed for regresssion.
   <# Describe "Generative AI PUT Method >> Update IsEnabled flag for capability." -Skip:($SkipEnvironmentList.Contains($CurrentEnvironmentData.Environment)) {
        It "Enabling and disabling of model and capability" {

            $script:modelname = "GPT 3.5 Turbo"
            Write-Host "Considering only $modelname to check whether it is enabled or disabled before proceeding with PUT Methods"
            #Selected Capability is : CHAT
            $requestParams = @{
                Method = 'GET'
                Uri    = "/workspace/api/v1/generativeai/model/$($modelname)/Chat/parameter"
            }

            $response = @{}
            $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true
            $responseMessage = $($response.ErrorDetails.message)

            if ($responseMessage -eq "Could not find the capability 'Chat' for model 'GPT 3.5 Turbo'") {
                Write-Host "Executing this if block as chat capability is disabled"
                Write-Host "Chat is disabled now so we will enable it first"
                $requestParams = @{
                    Method = 'PUT'
                    Uri    = "/workspace/api/v1/generativeai/model/$($modelname)/capability/Chat"
                    Body   = @{
                        "isEnabled" = $true

                    } | ConvertTo-Json
                }
                $putResponseFAfterEnablingChat = @{}
                $putResponseFAfterEnablingChat = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true

                Write-Host "Checking whether after enabling the chat capability, parameter list is populating"
                $requestParams = @{
                    Method = 'GET'
                    Uri    = "/workspace/api/v1/generativeai/model/$($modelname)/Chat/parameter"
                }

                $getResponseAfterEnablingChat = @{}
                $getResponseAfterEnablingChat = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true

                It "Should return correct response for enabled chat capability" {
                    $getResponseAfterEnablingChat | Should -Not -BeNullOrEmpty
                }

            }
            elseif ($responseMessage -eq "Could not find an AI Model called 'GPT 3.5 Turbo'") {
                Write-Host "Executing this elseif block as model $modelname is disabled"
                Write-Host "As model is disabled so we will enable the model here"
                $requestParams = @{
                    Method = 'PUT'
                    Uri    = "/workspace/api/v1/generativeai/model/$($modelname)"
                    Body   = @{
                        "isEnabled" = $true

                    } | ConvertTo-Json
                }

                $enabledModelResponse = @{}
                $enabledModelResponse = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true

                It "Should return correct response for enabled model" {
                    $enabledModelResponse | Should -Not -BeNullOrEmpty
                }

            }
            else {
                Write-Host "Executing this else block as both model and chat capability are enabled"
            }

        }
        Context "Test Case 279270: ST_TC_DM_272835: To verify if ModelName is valid but not available for other capability it should throw error while enabling it." {
            BeforeAll {
                Write-Host "ModelName Text Similarity Ada 001 is valid but not available for Chat capability"
                $modelname = "Text Embedding 3 Large" #Using Embedding Model in Chat capablity
                $requestParams = @{
                    Method = 'PUT'
                    Uri    = "/workspace/api/v1/generativeai/model/$modelname/capability/Chat"
                    Body   = @{
                        "isEnabled" = $true

                    } | ConvertTo-Json
                }

                $response = @{}
                $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true
                Write-Host "Message from negative scenario is - $($response.ErrorDetails.message) and  status code $($response.ExceptionResponse.StatusCode.value__) "
            }
            It "Should throw a error Message " {
                $($response.ErrorDetails.message) | Should -be "Could not find an capability 'Chat' for Model called 'Text Similarity Ada 001'"
            }
            It "Should throw a status code as 409 " {
                $($response.ExceptionResponse.StatusCode.value__) | Should -be 404
            }
        }
        Context "Test Case 279269: ST_TC_DM_272835: To verify enabling / disabling a Generative AI Model with incorrect payload syntax" {
            BeforeAll {
                Write-Host "Generative AI Model $modelname with incorrect payload syntax"

                $requestParams = @{
                    Method = 'PUT'
                    Uri    = "/workspace/api/v1/generativeai/model/$modelname/capability/Chat"
                    Body   = @{
                        "TestStatus" = $true #here the parameter value is invalid

                    } | ConvertTo-Json
                }

                $response = @{}
                $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true
                Write-Host "Message from negative scenario status code $($response.ExceptionResponse.StatusCode.value__) "
            }

            It "Should throw a status code as 400 " {
                $($response.ExceptionResponse.StatusCode.value__) | Should -be 400
            }
        }
        Context "Test Case 279268: ST_TC_US_268554: To verify that setting IsEnabled property for a non-existent model capability returns appropriate error message." {
            BeforeAll {
                Write-Host "Generative AI Model $modelname with incorrect payload syntax"
                $modelname = "InvalidModel"
                $requestParams = @{
                    Method = 'PUT'
                    Uri    = "/workspace/api/v1/generativeai/model/$modelname/capability/Chat"
                    Body   = @{
                        "isEnabled" = $true

                    } | ConvertTo-Json
                }

                $response = @{}
                $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true
                Write-Host " Message and Status code if Model Name is Invalid $($response.ErrorDetails.message) and  $($response.ExceptionResponse.StatusCode.value__) "
            }

            It "Should throw a status code as 404 " {
                $($response.ExceptionResponse.StatusCode.value__) | Should -be 404
            }
            It "Should throw a error Message " {
                $($response.ErrorDetails.message) | Should -be "Could not find an AI Model called 'InvalidModel'"
            }
        }
    } #>

    <# Describe "PALM MODELS --- User Story 284507: Enable additional PaLM models Provider = GoogleVertexAI" {

        Context "To Verify APIs related to Capability - GoogleVertexAI CHAT" {
            BeforeDiscovery {
                Write-Host "Selected Capability is : GoogleVertexAI CHAT"
                $requestParams = @{
                    Method = 'GET'
                    Uri    = "/workspace/api/v1/generativeai/model?providers=GoogleVertexAI&capabilities=Chat&enabledModelsOnly=true&enabledCapabilitiesOnly=true"
                }
                $GChatCapabilityResponse = @{}
                $GChatCapabilityResponse = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true
                $PalmChattestCases = New-Object System.Collections.Generic.List[Hashtable]
                Write-Host "Fetch the list of only enabled Models from enable model list"

                foreach ($Item in $GChatCapabilityResponse) {
                    If ($Item.modelName -notmatch ".*Dummy.*") {
                        $PalmChattestCases.Add(@{
                                'Model' = $($Item.modelName)
                            })
                    }
                }

                Write-Host " No of testcases : $($PalmChattestCases.Count)"
            }

            It "Test Case 270723: ST_TC_DM_259473: To Verify Completion  in all Models where Capabilty  = CHAT with only Mandatory parameters" -TestCases $PalmChattestCases {
                Write-Host "CHAT - Model with Mandatory Parameters ----  " + $_.Model
                $response = @{}
                $response = Create-GenAI-GoogleVertexChatResponse -Model $Model
                $response | Should -Not -BeNullOrEmpty
            }

        }


        Context "To Verify APIs related to Capability - GoogleVertexAI TEXT" {
            BeforeDiscovery {
                Write-Host "Selected Capability is : GoogleVertexAI TEXT "

                $requestParams = @{
                    Method = 'GET'
                    Uri    = "/workspace/api/v1/generativeai/model?providers=GoogleVertexAI&capabilities=Text"
                }

                $PalmTextCapabilityResponse = @{}
                $PalmTextCapabilityResponse = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true

                $PalmTexttestCases = New-Object System.Collections.Generic.List[Hashtable]
                Write-Host "Fetch the list of only enabled Models"

                foreach ($Item in $PalmTextCapabilityResponse) {
                    If ($Item.modelName -notmatch ".*Dummy.*") {
                        $PalmTexttestCases.Add(@{
                                'Model' = $($Item.modelName)
                            })
                    }
                }

                Write-Host " No of testcases : $($PalmTexttestCases.Count)"
            }


            It "Test Case 286773: ST_TC_DM_284507: To Verify Completion in Text for all Models where Provider = GoogleVertexAI with only Mandatory parameters" -TestCases $PalmTexttestCases {
                Write-Host "GoogleVertexAI_TEXT - Model with Mandatory Parameters ----  " + $_.Model

                $response = Create-GenAI-GoogleVertexTextResponse -Model $Model

                $response | Should -Not -BeNullOrEmpty

            }
            It "Test Case 286776: ST_TC_DM_259473: Negative TC To validate Response for Capability Key = TEXT and Model Name is = Its models from GET List only with with Exceed Parameters Values" -TestCases $PalmTexttestCases[0] {
                Write-Host "GoogleVertexAI_TEXT - Model with Invalid Values Parameters -Running only one 1st Model----  " + $_.Model

                $requestParams = @{
                    Method = 'POST'
                    Uri    = "/workspace/api/v1/generativeai/text"
                    Body   = @{
                        "modelName"      = "$Model"
                        "engagementCode" = $engagementCode
                        "prompt"         = "Who won the Cricket World Cup in 1983"
                        "parameters"     = @{
                            "temperature"     = Get-Random -Minimum 99 -Maximum 100
                            "maxOutputTokens" = Get-Random -Minimum -20 -Maximum -10
                            "stopSequences"   = @("stop")

                        }
                    } | ConvertTo-Json
                }
                $response = @{}
                $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true
                Write-Host "Response ---  $($response.ErrorDetails.message)"
                $response.ExceptionResponse.StatusCode.value__ | Should -be 400
            }
            <# Write-Host "Commenting Other testcase due to DEFECT # Defect 286664: ST_DEFECT_DM_284507_Incorrect Parameter Validations for PALM Models listed below "
        It "Test Case 286774: ST_TC_DM_284507: To Verify Completion in Text fofor all Models where Provider = GoogleVertexAI with all optional Parametes Min Value " {
            Write-Host "TEXT - Model with Min Values Parameters -Running for hardcoded Model --- Code Text Bison ---- "
            $requestParams = @{
                Method = 'POST'
                Uri    = "/workspace/api/v1/generativeai/text"
                Body   = @{
                    "modelName"      = "Code Text Bison"
                    "engagementCode" = $engagementCode
                    "prompt"         = "Who won the Cricket World Cup in 1983"
                    "parameters"     = @{
                        "temperature"     = 0.2
                        "maxOutputTokens" = 1
                        "stopSequences"   = @("end on last line")

                    }
                } | ConvertTo-Json
            }
            $PALMTextGenAIResponse = $null
            $PALMTextGenAIResponse = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true
            $PALMTextGenAIResponse | Should -Not -BeNullOrEmpty
        }
        It "Test Case 270729: ST_TC_DM_259473: To Verify Completion  in all Models where Capabilty  = TEXT with all optional Parametes Max Value" {
            Write-Host "TEXT - Model with Max Values Parameters -Hardcoded Model is Text Ada 001 ---  "
            $requestParams = @{
                Method = 'POST'
                Uri    = "/workspace/api/v1/generativeai/text"
                Body   = @{
                    "modelName"      = "Code Text Bison"
                    "engagementCode" = $engagementCode
                    "prompt"         = "Who won the Cricket World Cup in 1983"
                    "parameters"     = @{
                        "temperature"     = 1
                        "maxOutputTokens" = 1  # to reduces Token Consumtion
                        "stopSequences"   = @("end on last line")

                    }
                } | ConvertTo-Json

            }
            $TextGenAIResponse3 = $null
            $TextGenAIResponse3 = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true
            $TextGenAIResponse3 | Should -Not -BeNullOrEmpty

        }
        Write-Host "Commenting Other testcase due to DEFECT # Defect 286664: ST_DEFECT_DM_284507_Incorrect Parameter Validations for PALM Models listed below "

        }
    } #>

    Describe "User Story 282333: Return disabled models and capabilities from the generative AI endpoints" {
        Context "List of enabled and disabled models and capabilities" {
            It "Should return 200 response for all True values of model and capability" {
                $count = 0
                $requestParams = @{
                    Method = 'GET'
                    Uri    = "/workspace/api/v1/generativeai/model?enabledModelsOnly=true&enabledCapabilitiesOnly=true"
                }
                $enabledmodelAndCapabilityResponse = @{}
                $enabledmodelAndCapabilityResponse = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true

                foreach ($item in $enabledmodelAndCapabilityResponse) {
                    $item.isEnabled | Should -be $true
                    $count ++
                }
                Write-Host "Total number of enabled models are - $count"
            }

            It "Should return 200 response for all False values of model and capability" {
                $trueCount = 0
                $falseCount = 0
                $requestParams = @{
                    Method = 'GET'
                    Uri    = "/workspace/api/v1/generativeai/model?enabledModelsOnly=false&enabledCapabilitiesOnly=false"
                }
                $disabledmodelAndCapabilityResponse = @{}
                $disabledmodelAndCapabilityResponse = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true

                foreach ($item in $disabledmodelAndCapabilityResponse) {
                    $item.isEnabled -in ($true, $false) | Should -BeTrue
                    if ($item.isEnabled -eq $true) {
                        $trueCount ++
                    }
                    else {
                        $falseCount ++
                    }
                }
                Write-Host "Number of enabled models are - $trueCount"
                Write-Host "Number of disabled models are - $falseCount"
            }
        }
        Context "List for model for unknown provider value" {
            BeforeAll {
                $requestParams = @{
                    Method = 'GET'
                    Uri    = "/workspace/api/v1/generativeai/model?providers=Unknown"
                }
                $response = @{}
                $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true
            }

            It "Should return 400 response with proper error message for unknown provider" {
                $response.ExceptionResponse.StatusCode.value__ | Should -be 400
                $response.ErrorDetails.message | Should -eq "'Unknown' is not a valid provider. Please select valid provider/s."
            }
        }

        Context "List for model for unknown capability value" {
            BeforeAll {
                $requestParams = @{
                    Method = 'GET'
                    Uri    = "/workspace/api/v1/generativeai/model?capabilities=Unknown"
                }
                $response = @{}
                $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true
            }

            It "Should return 400 response with proper error message for unknown capability" {
                $response.ExceptionResponse.StatusCode.value__ | Should -be 400
                $response.ErrorDetails.message | Should -eq "'Unknown' is not a valid capability. Please select valid capability/ies."
            }
        }

        Context "List for model for unknown provider and capability value" {
            BeforeAll {
                $requestParams = @{
                    Method = 'GET'
                    Uri    = "/workspace/api/v1/generativeai/model?providers=Unknown&capabilities=Unknown"
                }
                $response = @{}
                $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true
            }

            It "Should return 400 response with proper error message for unknown provider and capability" {
                $response.ExceptionResponse.StatusCode.value__ | Should -be 400
                $response.ErrorDetails.message | Should -eq "'Unknown' is not a valid provider. Please select valid provider/s."
            }
        }



    }

    #Code to calculate Token count for capabilities Text,Text Streaming,Chat,Chat Streaming and Embdedding
    Describe "Generative AI APIs for each model with Capabilities for Token count " {
        Context "To Verify APIs related to Capability - Text and Text Streaming" {
            BeforeDiscovery {
                Write-Host "Selected Capability - Text and Text Streaming"
                $requestParams = @{
                    Method = 'GET'
                    Uri    = "/workspace/api/v1/generativeai/model?capabilities=Text&capabilities=TextStreaming&enabledModelsOnly=true&enabledCapabilitiesOnly=true"
                }

                $TextCapabilityResponse = @{}
                $TextCapabilityResponse = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true

                $Script:Text_TokenCountTestcases = New-Object System.Collections.Generic.List[Hashtable]
                Write-Host "Fetch the list of only enabled Models $TextCapabilityResponse"

                foreach ($Item in $TextCapabilityResponse) {
                    Write-Host "Inside foreach loop for $Item"
                    if ($Item.capabilities -contains "TokenCount" -and $Item.modelName -notmatch ".*Dummy.*") {
                        Write-Host "Inside if condition for capabilities $($Item.capabilities)"

                        $Text_TokenCountTestcases.Add(@{

                                'Model' = $($Item.modelName)
                            })
                        Write-Host " models avaliable $($Item.modelName)"
                    }
                    else {
                        Write-Host "Token Count is not enabled for  $($Item.modelName)"
                    }

                }
                Write-Host " No of testcases : $($Text_TokenCountTestcases.Count)"
            }
            It " Verify Generative AI models to calculate token count for TEXT and TEXT Streaming Capabilities" -TestCases $Text_TokenCountTestcases {
                Write-Host "To calculate token count for TEXT and TEXT Streaming Capabilities ----  " + $_.Model

                $TextCapabilityResponse = Create-GenAI-TokencountOfTextResponse -Model $Model


                $TextCapabilityResponse | Should -Not -BeNullOrEmpty
            }
            It "Verify Completion in Command Models where Capabilty  = Tokencount of Text with missing mandatory field" -TestCases $Text_TokenCountTestcases[0] {
                Write-Host "Tokencount of Text where mandatory field is missing"
                $requestParams = @{
                    Method = 'POST'
                    Uri    = "/workspace/api/v1/generativeai/text/tokencount"
                    Body   = @{
                        "modelName" = $Model
                    } | ConvertTo-Json
                }
                $response = @{}
                $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true
                Write-Host "Response for missing mandatory fields for Tokencount of Text---  $($response.ErrorDetails.errors.Prompt)"
                $response.ExceptionResponse.StatusCode.value__ | Should -be 400

            }
            It "Verify Completion in Command Models where Capabilty  = Tokencount of Text with unsupported modelName" -TestCases $Text_TokenCountTestcases[0] {
                Write-Host "Tokencount for Text where unsupported model name is provided"
                $requestParams = @{
                    Method = 'POST'
                    Uri    = "/workspace/api/v1/generativeai/text/tokencount"
                    Body   = @{
                        "modelName" = "GPT 4"
                        "prompt"    = "Who is Bill Gates"
                    } | ConvertTo-Json
                }
                $response = @{}
                $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true
                Write-Host "Response for unsupported modelName for Tokencount of Text---  $($response.ErrorDetails.message)"
                $response.ExceptionResponse.StatusCode.value__ | Should -be 400

            }
        }

        Context "To Verify APIs related to Capability - Chat and Chat Streaming" {
            BeforeDiscovery {
                Write-Host "Selected Capability - Chat and Chat Streaming"
                $requestParams = @{
                    Method = 'GET'
                    Uri    = "/workspace/api/v1/generativeai/model?capabilities=Chat&capabilities=ChatStreaming&enabledModelsOnly=true&enabledCapabilitiesOnly=true"
                }

                $ChatCapabilityResponse = @{}
                $ChatCapabilityResponse = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true

                $Script:Chat_TokenCountTestcases = New-Object System.Collections.Generic.List[Hashtable]
                Write-Host "Fetch the list of only enabled Models $ChatCapabilityResponse"

                foreach ($Item in $ChatCapabilityResponse) {
                    Write-Host "Inside foreach loop for $Item"
                    if ($Item.capabilities -contains "TokenCount" -and  $Item.modelName -notmatch ".*Dummy.*") {
                        Write-Host "Inside if condition for capabilities $($Item.capabilities)"

                        $Chat_TokenCountTestcases.Add(@{
                                'Model' = $($Item.modelName)
                            })
                        Write-Host " models avaliable $($Item.modelName)"
                    }
                    else {
                        Write-Host "Token Count is not enabled for  $($Item.modelName)"
                    }

                }
                Write-Host " No of testcases : $($Chat_TokenCountTestcases.Count)"
            }
            It " Verify Generative AI models to calculate token count for  Chat and Chat Streaming Capabilities" -TestCases $Chat_TokenCountTestcases {
                Write-Host " To calculate token count for Chat and Chat Streaming Capabilities ----  " + $_.Model

                $ChatCapabilityResponse = Create-GenAI-TokencountOfChatResponse -Model $Model

                $ChatCapabilityResponse | Should -Not -BeNullOrEmpty
            }
            It "Verify Completion in Command Models where Capabilty  = Tokencount of Chat with missing mandatory field" -TestCases $Chat_TokenCountTestcases[0] {
                Write-Host "Tokencount of Chat where mandatory field is missing"
                $requestParams = @{
                    Method = 'POST'
                    Uri    = "/workspace/api/v1/generativeai/chat/tokencount"
                    Body   = @{
                        "modelName" = $Model
                    } | ConvertTo-Json
                }
                $response = @{}
                $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true
                Write-Host "Response for missing mandatory fields for Tokencount of Chat---  $($response.ErrorDetails.errors.Messages)"
                $response.ExceptionResponse.StatusCode.value__ | Should -be 400

            }
            It "Verify Completion in Command Models where Capabilty  = Tokencount of Chat with unsupported modelName" -TestCases $Chat_TokenCountTestcases[0] {
                Write-Host "Tokencount of Chat where unsupported model name is provided"
                $requestParams = @{
                    Method = 'POST'
                    Uri    = "/workspace/api/v1/generativeai/chat/tokencount"
                    Body   = @{
                        "modelName" = "InvalidModel"
                        "messages"  = @(
                            @{
                                "role"    = "User"
                                "content" = "Who won the Cricket World Cup in 2023"
                            })
                    } | ConvertTo-Json
                }
                $response = @{}
                $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true
                Write-Host "Response for unsupported modelName for Tokencount of Chat ---  $($response.ErrorDetails.message)"
                $response.ExceptionResponse.StatusCode.value__ | Should -be 404

            }
        }

        Context "To Verify APIs related to Capability - Embeddings" {
            BeforeDiscovery {
                Write-Host "Selected Capability - Embeddings"
                $requestParams = @{
                    Method = 'GET'
                    Uri    = "/workspace/api/v1/generativeai/model?capabilities=Embeddings&enabledModelsOnly=true&enabledCapabilitiesOnly=true"
                }

                $EmbeddingsCapabilityResponse = @{}
                $EmbeddingsCapabilityResponse = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true

                $Script:Embeddings_TokenCountTestcases = New-Object System.Collections.Generic.List[Hashtable]
                Write-Host "Fetch the list of only enabled Models $EmbeddingsCapabilityResponse"

                foreach ($Item in $EmbeddingsCapabilityResponse) {
                    Write-Host "Inside foreach loop for $Item"
                    if ($Item.capabilities -contains "TokenCount" -and $Item.modelName -notmatch ".*Dummy.*") {
                        Write-Host "Inside if condition for capabilities $($Item.capabilities)"

                        $Embeddings_TokenCountTestcases.Add(@{
                                'Model' = $($Item.modelName)
                            })
                        Write-Host " models avaliable $($Item.modelName)"
                    }
                    else {
                        Write-Host "Token Count is not enabled for  $($Item.modelName)"
                    }

                }
                Write-Host " No of testcases : $($Embeddings_TokenCountTestcases.Count)"
            }
            It " Verify Generative AI models to calculate token count for  Embeddings Capabilities" -TestCases $Embeddings_TokenCountTestcases {
                Write-Host " To calculate token count for Embeddings Capabilities ----  " + $_.Model

                $EmbeddingsCapabilityResponse = Create-GenAI-TokencountOfEmbeddingsResponse -Model $Model

                $EmbeddingsCapabilityResponse | Should -Not -BeNullOrEmpty
            }
            It "Verify Completion in Command Models where Capabilty  = Tokencount of Embeddings with missing mandatory field" -TestCases $Embeddings_TokenCountTestcases[0] {
                Write-Host "Tokencount of Embeddings where mandatory field is missing"
                $requestParams = @{
                    Method = 'POST'
                    Uri    = "/workspace/api/v1/generativeai/embedding/tokencount"
                    Body   = @{
                        "modelName" = $Model
                    } | ConvertTo-Json
                }
                $response = @{}
                $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true
                Write-Host "Response for missing mandatory fields for Tokencount of Embeddings ---  $($response.ErrorDetails.errors.Input)"
                $response.ExceptionResponse.StatusCode.value__ | Should -be 400

            }

            It "Verify Completion in Command Models where Capabilty  = Tokencount of Embeddings with unsupported modelName" -TestCases $Embeddings_TokenCountTestcases[0] {
                Write-Host "Tokencount of Embeddings where unsupported model name is provided"
                $requestParams = @{
                    Method = 'POST'
                    Uri    = "/workspace/api/v1/generativeai/embedding/tokencount"
                    Body   = @{
                        "modelName" = "GPT 4"
                        "input"     = "Who is Bill Gates"
                    } | ConvertTo-Json
                }
                $response = @{}
                $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true
                Write-Host "Response for unsupported modelName for Tokencount of Embeddings ---  $($response.ErrorDetails.message)"
                $response.ExceptionResponse.StatusCode.value__ | Should -be 400

            }
        }
    }



#this is no more in Scope bing models are not scope of Gen ai, Keeping this for future use.
    <#Describe "User Story 255787: AGPT - Bing Plugin Where Model name is - GPT 3.5 Turbo 16k With Bing >> Only Negative Testcases " {
    BeforeAll {
        Write-Host "Running Function to check if Model is Enable"
        $script:BingModelName = "GPT 3.5 Turbo 16k With Bing"
        $script:capability = "Chat"
        $isEnabledModel = Check-ModelEnabled $BingModelName $capability
        Write-Host "Status of $BingModelName  is ----- $isEnabledModel"
        Write-Host "*******Testcases Specific to Bing Model*************"
    }


    It "Test Case 283764: ST_TC_DM_255787: To verify Error Message for Model 'GPT 3.5 Turbo 16k With Bing' should not response completion with Invalid Parameter values."-Skip:($isEnabledModel -eq $false) {
        Write-Host "CHAT Bing - To verify Error Message for Model 'GPT 3.5 Turbo 16k With Bing' should not response completion with Invalid Parameter values. $BingModelName "
        $requestParams = @{
            Method = 'POST'
            Uri    = "/workspace/api/v1/generativeai/$capability"
            Body   = @{
                "modelName"      = $BingModelName
                "engagementCode" = $engagementCode
                "messages"       = @( @{
                        "role"    = "User"
                        "content" = "Which Country sent satelite to moon"
                    }, @{
                        "role"    = "Assistant"
                        "content" = "India"
                    }, @{
                        "role"    = "User"
                        "content" = "When and where the Satellite launch to Moon"
                    })
                "parameters"     = @{
                    "temperature"       = Get-Random -Minimum 3 -Maximum 22
                    "max_tokens"        = Get-Random -Minimum 987654 -Maximum 2345676
                    "top_p"             = Get-Random -Minimum 1 -Maximum 4
                    "frequency_penalty" = Get-Random -Minimum -12 -Maximum 12
                    "presence_penalty"  = Get-Random -Minimum -12 -Maximum 12

                }
            } | ConvertTo-Json
        }
        Write-Host "Request Body for Invalid paramter  is - $($requestParams | ConvertTo-Json) "
        $response = @{}
        $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true
        Write-Host "Response ---  $($response.ErrorDetails.message)"

        $response.ExceptionResponse.StatusCode.value__ | Should -be 400

    }
    It "Test Case 283765: ST_TC_DM_255787: To verify not getting completion for Model 'GPT 3.5 Turbo 16k With Bing' in Other capability except Chat."-Skip:($isEnabledModel -eq $false) {
        Write-Host "CHAT Bing To verify not getting completion for Model 'GPT 3.5 Turbo 16k With Bing' in Other capability (TextStreaming) except Chat. $BingModelName"
        $requestParams = @{
            Method = 'POST'
            Uri    = "/workspace/api/v1/generativeai/text/stream"
            Body   = @{
                "modelName"      = $BingModelName
                "engagementCode" = $engagementCode
                "prompt"         = "which country sent Satellite on moon in 2023 and when"
            } | ConvertTo-Json
        }
        Write-Host "Request Body for streaming  is - $($requestParams | ConvertTo-Json) "
        $response = @{}
        $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true
        Write-Host "Response ---  $($response.ErrorDetails.message)"
        $response.ExceptionResponse.StatusCode.value__ | Should -be 400


    }
    It "Test Case 283765: ST_TC_DM_255787: To verify not getting completion for Model 'GPT 3.5 Turbo 16k With Bing' in Other capability except Chat."-Skip:($isEnabledModel -eq $false) {
        Write-Host "CHAT Bing - To verify not getting completion for Model 'GPT 3.5 Turbo 16k With Bing' in Other capability (Embedding) except Chat. $BingModelName"
        $requestParams = @{
            Method = 'POST'
            Uri    = "/workspace/api/v1/generativeai/embedding"
            Body   = @{
                "modelName"      = $BingModelName
                "engagementCode" = $engagementCode
                "input"          = "which country sent Satellite on moon in 2023 and when"
            } | ConvertTo-Json
        }
        Write-Host "Request Body for Embedding is - $($requestParams | ConvertTo-Json) "
        $response = @{}
        $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true
        Write-Host "Response ---  $($response.ErrorDetails.message)"

        $response.ExceptionResponse.StatusCode.value__ | Should -be 400
        #$response.ErrorDetails.message | Should -eq "Model 'GPT 3.5 Turbo 16k With Bing' does not support the 'Embeddings' capability"

    }
    It "Test Case 283766: ST_TC_DM_255787: (Negative TC )To verify Error in Completion Max Token Quota reached for Model 'GPT 3.5 Turbo 16k With Bing' in Chat Capability"-Skip:($isEnabledModel -eq $false) {
        Write-Host "CHAT Bing - To verify Error in Completion Max Token Quota reached for Model 'GPT 3.5 Turbo 16k With Bing' in Chat Capability----  "
        $requestParams = @{
            Method = 'POST'
            Uri    = "/workspace/api/v1/generativeai/$capability"
            Body   = @{
                "modelName"      = $BingModelName
                "engagementCode" = $engagementCode
                "messages"       = @( @{
                        "role"    = "User"
                        "content" = "Which Country sent satelite to moon"
                    }, @{
                        "role"    = "Assistant"
                        "content" = "India"
                    }, @{
                        "role"    = "User"
                        "content" = "When and where the Satellite launch to Moon"
                    })
                "parameters"     = @{
                    "max_tokens" = 12345678

                }
            } | ConvertTo-Json
        }
        Write-Host "Request Body for Chat maxtoken limit is - $($requestParams | ConvertTo-Json) "
        $response = @{}
        $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true
        Write-Host "Response ---  $($response.ErrorDetails.message)"
        $response.ExceptionResponse.StatusCode.value__ | Should -be 400
        #$response.ErrorDetails.message | Should -eq "The following params were passed with an invalid value, ['max_tokens', Value must be smaller or equal to 16384]"
    }
}
#>

    Describe "User Story 266325: QA - Verify Implementation of Anthropic Claude (Text, TextStreaming, Chat and ChatStreaming)" {
        Context "Test Case 273082: ST_TC_DM_266325: To verify list of All Models where provider = Anthropic and Capabilities = Text" {
            BeforeDiscovery {
                Write-Host "Selected Provider - Anthropic and  Capability - TEXT"
                $requestParams = @{
                    Method = 'GET'
                    Uri    = "/workspace/api/v1/generativeai/model?providers=Anthropic&capabilities=text&enabledCapabilitiesOnly=true"
                }

                $AnthropicTextResponse = @{}
                $AnthropicTextResponse = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true

                $AnthropicTexttestCases = New-Object System.Collections.Generic.List[Hashtable]
                Write-Host "Fetch the list of only enabled Models"

                foreach ($Item in $AnthropicTextResponse) {
                    If ($Item.modelName -notmatch ".*Dummy.*") {

                        $AnthropicTexttestCases.Add(@{
                                'Model' = $($Item.modelName)
                            })
                    }
                }
            }

            Write-Host " No of testcases : $($AnthropicTexttestCases.Count)"

            It "Test Case 273082: ST_TC_DM_266325: To verify list of All Models where provider = Anthropic and Capabilities = Text with only Mandatory parameters" -TestCases $AnthropicTexttestCases {
                Write-Host "TEXT - Model with Mandatory Parameters ----  " + $_.Model
                $response = Create-GenAI-TextResponse -Model $Model
                $response | Should -Not -BeNullOrEmpty

            }
            It "Test Case 273082: ST_TC_DM_266325: To verify list of All Models where provider = Anthropic and Capabilities = Textwith all optional Parametes Min Value " -TestCases $AnthropicTexttestCases[0] {
                Write-Host "Anthropic TEXT - Model with Min Values Parameters--- " + $_.Model
                $requestParams = @{
                    Method = 'POST'
                    Uri    = "/workspace/api/v1/generativeai/text"
                    Body   = @{
                        "modelName"      = $Model
                        "engagementCode" = $engagementCode
                        "prompt"         = "Who won the Cricket World Cup in 1983"
                        "parameters"     = @{
                            "temperature" = 0
                            "max_tokens"  = 1  #Marking as 1 to reduce consumtion of tokens
                            "top_k"       = 0
                            "top_p"       = 0
                            #"n"                 = 1

                        }
                    } | ConvertTo-Json
                }
                $TextGenAIResponse = $null
                $TextGenAIResponse = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true
                $TextGenAIResponse | Should -Not -BeNullOrEmpty
            }
            It "Test Case 273082: ST_TC_DM_266325: To verify list of All Models where provider = Anthropic and Capabilities = Text with all optional Parametes Max Value" -TestCases $AnthropicTexttestCases[0] {
                Write-Host "Anthropic TEXT - Model with Max Values Parameters ---  " + $_.Model
                $requestParams = @{
                    Method = 'POST'
                    Uri    = "/workspace/api/v1/generativeai/text"
                    Body   = @{
                        "modelName"      = $Model
                        "engagementCode" = $engagementCode
                        "prompt"         = "Who won the Cricket World Cup in 1983"
                        "parameters"     = @{
                            "temperature" = 1
                            "max_tokens"  = 1  #Marking as 1 to reduce consumtion of tokens
                            "top_k"       = 1
                            "top_p"       = 1
                            #"n"                 = 100

                        }
                    } | ConvertTo-Json
                }
                $TextGenAIResponse3 = $null
                $TextGenAIResponse3 = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true
                $TextGenAIResponse3 | Should -Not -BeNullOrEmpty

            }
            It "Test Case 273082: ST_TC_DM_266325: To verify list of All Models where provider = Anthropic and Capabilities = Text with Invalid Parameters Values" -TestCases $AnthropicTexttestCases[0] {
                Write-Host "TEXT - Model with Invalid Values Parameters -Running only one 1st Model----  "

                $requestParams = @{
                    Method = 'POST'
                    Uri    = "/workspace/api/v1/generativeai/text"
                    Body   = @{
                        "modelName"      = $Model
                        "engagementCode" = $engagementCode
                        "prompt"         = "can you tell me a joke?"
                        "parameters"     = @{
                            "temperature" = Get-Random -Minimum 99 -Maximum 229
                            "max_tokens"  = Get-Random -Minimum -20 -Maximum -10
                            "top_k"       = Get-Random -Minimum -129 -Maximum 129
                            "top_p"       = Get-Random -Minimum -129 -Maximum 129


                        }
                    } | ConvertTo-Json
                }
                $response = @{}
                $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true
                Write-Host "Response ---  $($response.ErrorDetails.message)"
                $response.ExceptionResponse.StatusCode.value__ | Should -be 400
            }

        }
        Context "Test Case 273084: ST_TC_DM_266325: To verify list of All Models where provider = Anthropic and Capabilities = Chat" {
            BeforeDiscovery {
                Write-Host "Selected Provider - Anthropic and Capability - CHAT"
                $requestParams = @{
                    Method = 'GET'
                    Uri    = "/workspace/api/v1/generativeai/model?providers=Anthropic&capabilities=Chat&enabledModelsOnly=true&enabledCapabilitiesOnly=true"
                }

                $AnthropicChatResponse = @{}
                $AnthropicChatResponse = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true

                $AnthropicChattestCases = New-Object System.Collections.Generic.List[Hashtable]
                Write-Host "Fetch the list of only enabled Models"

                foreach ($Item in $AnthropicChatCResponse) {
                    If ($Item.modelName -notmatch ".*Dummy.*") {
                        $AnthropicChattestCases.Add(@{
                                'Model' = $($Item.modelName)
                            })
                    }
                }

                Write-Host " No of testcases : $($AnthropicChattestCases.Count)"
            }


            It "Test Case 273084: ST_TC_DM_266325: To verify list of All Models where provider = Anthropic and Capabilities = Chat with only Mandatory parameters" -TestCases $AnthropicChattestCases {
                Write-Host "CHAT - Model with Mandatory Parameters ----  " + $_.Model
                $response = Create-GenAI-ChatResponse -Model $Model

                $response | Should -Not -BeNullOrEmpty

            }
            It "Test Case 273084: ST_TC_DM_266325: To verify list of All Models where provider = Anthropic and Capabilities = Chat with all optional Parametes Min Value" -TestCases $AnthropicChattestCases[0] {
                Write-Host "Anthropic CHAT - with Min Values Parameters ----$Model "
                $requestParams = @{
                    Method = 'POST'
                    Uri    = "/workspace/api/v1/generativeai/chat"
                    Body   = @{
                        "modelName"      = $Model
                        "engagementCode" = $engagementCode
                        "messages"       = @( @{
                                "role"    = "User"
                                "content" = "Who won the Cricket World Cup in 1983"
                            }, @{
                                "role"    = "Assistant"
                                "content" = "India won WC 1983 by defeating defending champions (team I performed asked for originally) West Indies."
                            }, @{
                                "role"    = "User"
                                "content" = "Who won was the MAN of the MATCH"
                            })
                        "parameters"     = @{
                            "temperature" = 0
                            "max_tokens"  = 1  #Marking as 1 to reduce consumtion of tokens
                            "top_k"       = 0
                            "top_p"       = 0
                            #"n"                 = 1

                        }
                    } | ConvertTo-Json
                }
                $response = $null
                $response = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true
                Write-Host "Response with Min Values is  ---  $response"

                $response | Should -Not -BeNullOrEmpty

            }
            It "Test Case 273084: ST_TC_DM_266325: To verify list of All Models where provider = Anthropic and Capabilities = Chat with all optional Parametes Max Value" -TestCases $AnthropicChattestCases[0] {
                Write-Host "Anthropic CHAT - Model with Max Values Parameters--- $Model  "
                $requestParams = @{
                    Method = 'POST'
                    Uri    = "/workspace/api/v1/generativeai/chat"
                    Body   = @{
                        "modelName"      = $Model
                        "engagementCode" = $engagementCode
                        "messages"       = @( @{
                                "role"    = "User"
                                "content" = "Who won the Cricket World Cup in 1983"
                            }, @{
                                "role"    = "Assistant"
                                "content" = "India won WC 1983 by defeating defending champions (team I performed asked for originally) West Indies."
                            }, @{
                                "role"    = "User"
                                "content" = "Who won was the MAN of the MATCH"
                            })
                        "parameters"     = @{
                            "temperature" = 2
                            "max_tokens"  = 1  #Marking as 1 to reduce consumtion of tokens
                            "top_k"       = 1
                            "top_p"       = 1
                            #"n"                 = 100

                        }
                    } | ConvertTo-Json
                }
                $ChatGenAIResponse = $null
                $ChatGenAIResponse = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true
                Write-Host "Response for all fields is ---  $ChatGenAIResponse"
                $ChatGenAIResponse | Should -Not -BeNullOrEmpty
            }
            It "Test Case 273084: ST_TC_DM_266325: To verify list of All Models where provider = Anthropic and Capabilities = Chat with Invalid Parameters Values" -TestCases $AnthropicChattestCases[0] {
                Write-Host "Anthropic CHAT - Model with Invalid Values in Parameters -Running only one 1st Model----  "
                $requestParams = @{
                    Method = 'POST'
                    Uri    = "/workspace/api/v1/generativeai/chat"
                    Body   = @{
                        "modelName"      = $Model
                        "engagementCode" = $engagementCode
                        "messages"       = @( @{
                                "role"    = "User"
                                "content" = "Who won the Cricket World Cup in 1983"
                            }, @{
                                "role"    = "Assistant"
                                "content" = "India won WC 1983 by defeating defending champions (team I performed asked for originally) West Indies."
                            }, @{
                                "role"    = "User"
                                "content" = "Who won was the MAN of the MATCH"
                            })
                        "parameters"     = @{
                            "temperature" = Get-Random -Minimum 13 -Maximum 22
                            "max_tokens"  = Get-Random -Minimum 987654 -Maximum 2345676
                            "top_p"       = Get-Random -Minimum 1 -Maximum 4
                            "top_k"       = Get-Random -Minimum -12 -Maximum 12


                        }
                    } | ConvertTo-Json
                }
                $response = @{}
                $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true
                Write-Host "Response ---  $($response.ErrorDetails.message)"
                $response.ExceptionResponse.StatusCode.value__ | Should -be 400

            }

        }
        Context "Test Case 273085: ST_TC_DM_266325: To verify list of All Models where provider = Anthropic and Capabilities = ChatStreaming" {
            BeforeDiscovery {
                Write-Host "Selected Provider - Anthropic and Capability - Chat Streaming"
                $requestParams = @{
                    Method = 'GET'
                    Uri    = "/workspace/api/v1/generativeai/model?providers=Anthropic&capabilities=ChatStreaming&enabledCapabilitiesOnly=true"
                }

                $AnthropicChatStreamingResponse = @{}
                $AnthropicChatStreamingResponse = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true

                $AnthropicChatStreamingTestCases = New-Object System.Collections.Generic.List[Hashtable]

                foreach ($Item in $AnthropicChatStreamingResponse) {
                    If ($Item.modelName -notmatch ".*Dummy.*") {
                        $AnthropicChatStreamingTestCases.Add(@{
                                'Model' = $($Item.modelName)
                            })
                    }
                }

                Write-Host " No of testcases : $($AnthropicChatStreamingTestCases.Count)"

            }

            It "Test Case 273085: ST_TC_DM_266325: To verify list of All Models where provider = Anthropic and Capabilities = ChatStreaming with only Mandatory parameters" -TestCases $AnthropicChatStreamingTestCases {
                Write-Host "Anthropic ChatStreaming - Model with Mandatory Parameters ---- " + $_.Model
                $response = Create-GenAI-ChatStreamResponse -Model $Model

                $response | Should -Not -BeNullOrEmpty

            }

            It "Test Case 273085: ST_TC_DM_266325: To verify list of All Models where provider = Anthropic and Capabilities = ChatStreaming with all optional Parametes Min Value" -TestCases $AnthropicChatStreamingTestCases[0] {
                Write-Host "Anthropic ChatStreaming - Model with Min Values Parameters  " + $_.Model
                $requestParams = @{
                    Method = 'POST'
                    Uri    = "/workspace/api/v1/generativeai/chat/stream"
                    Body   = @{
                        "modelName"      = $Model
                        "engagementCode" = $engagementCode
                        "messages"       = @( @{
                                "role"    = "User"
                                "content" = "Who won the Cricket World Cup in 1983"
                            }, @{
                                "role"    = "Assistant"
                                "content" = "India won WC 1983 by defeating defending champions (team I performed asked for originally) West Indies."
                            }, @{
                                "role"    = "User"
                                "content" = "Who won was the MAN of the MATCH"
                            })
                        "parameters"     = @{
                            "temperature" = 0
                            "max_tokens"  = 1
                            "top_k"       = 0
                            "top_p"       = 0
                            #"n"  = 1

                        }
                    } | ConvertTo-Json
                }
                $response = $null
                $response = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true
                Write-Host "Response with Min Values is  ---  $response"

                $response | Should -Not -BeNullOrEmpty

            }

            It "Test Case 273085: ST_TC_DM_266325: To verify list of All Models where provider = Anthropic and Capabilities = ChatStreaming with all optional Parametes Max Value" -TestCases $AnthropicChatStreamingTestCases[0] {
                Write-Host "Anthropic ChatStreaming - Model with Max Values Parameters - Running only first model ---- " + $_.Model
                $requestParams = @{
                    Method = 'POST'
                    Uri    = "/workspace/api/v1/generativeai/chat/stream"
                    Body   = @{
                        "modelName"      = $Model
                        "engagementCode" = $engagementCode
                        "messages"       = @( @{
                                "role"    = "User"
                                "content" = "Who won the Cricket World Cup in 1983"
                            }, @{
                                "role"    = "Assistant"
                                "content" = "India won WC 1983 by defeating defending champions (team I performed asked for originally) West Indies."
                            }, @{
                                "role"    = "User"
                                "content" = "Who won was the MAN of the MATCH"
                            })
                        "parameters"     = @{
                            "temperature" = 1
                            "max_tokens"  = 1  #Marking as 1 to reduce consumtion of tokens
                            "top_p"       = 1
                            #"n"                 = 100

                        }
                    } | ConvertTo-Json
                }
                $ChatSGenAIResponse = $null
                $ChatSGenAIResponse = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true
                Write-Host "Response for all fields is ---  $ChatSGenAIResponse"

                $ChatSGenAIResponse | Should -Not -BeNullOrEmpty

            }

            It "Test Case 273085: ST_TC_DM_266325: To verify list of All Models where provider = Anthropic and Capabilities = ChatStreaming with Invalid Parameters Values" -TestCases $AnthropicChatStreamingTestCases[0] {
                Write-Host "Anthropic ChatStreaming - Model with Invalid Values Parameters - Running only first model $Model ---- "
                $requestParams = @{
                    Method = 'POST'
                    Uri    = "/workspace/api/v1/generativeai/chat/stream"
                    Body   = @{
                        "modelName"      = $Model
                        "engagementCode" = $engagementCode
                        "messages"       = @( @{
                                "role"    = "User"
                                "content" = "Who won the Cricket World Cup in 1983"
                            }, @{
                                "role"    = "Assistant"
                                "content" = "India won WC 1983 by defeating defending champions (team I performed asked for originally) West Indies."
                            }, @{
                                "role"    = "User"
                                "content" = "Who won was the MAN of the MATCH"
                            })
                        "parameters"     = @{
                            "temperature" = Get-Random -Minimum 99 -Maximum 888
                            "max_tokens"  = Get-Random -Minimum 1987654 -Maximum 2345676
                            "top_p"       = Get-Random -Minimum 15 -Maximum 24
                            "top_k"       = Get-Random -Minimum -12 -Maximum 12


                        }
                    } | ConvertTo-Json
                }
                $response = @{}
                $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true
                Write-Host "Response ---  $($response.ErrorDetails.message)"
                $response.ExceptionResponse.StatusCode.value__ | Should -be 400
            }

        }
        Context "Test Case 273083: ST_TC_DM_266325: To verify list of All Models where provider = Anthropic and Capabilities = TextStreaming" {
            BeforeDiscovery {
                Write-Host "Fetch Models for Provider Anthropic and Capability is : TextStreaming"
                $requestParams = @{
                    Method = 'GET'
                    Uri    = "/workspace/api/v1/generativeai/model?providers=Anthropic&capabilities=textStreaming&enabledCapabilitiesOnly=true"
                }

                $AnthropicTextStreamingResponse = @{}
                $AnthropicTextStreamingResponse = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true

                $AnthropicTextStreamingTestCases = New-Object System.Collections.Generic.List[Hashtable]

                foreach ($Model in $AnthropicTextStreamingResponse.modelName) {
                    If ($Model -notmatch ".*Dummy.*") {
                        $AnthropicTextStreamingTestCases.Add(@{
                                'Model' = $Model
                            })
                        $ATextStreamingModelList += $($Model)
                    }
                }
                Write-Host "Models available for  Anthropic and TextStreaming are $($ATextStreamingModelList)"

            }

            It "Test Case 270723: ST_TC_DM_259473: To Verify Completion in all Models where Capabilty = TextStreaming with only Mandatory parameters" -TestCases $AnthropicTextStreamingTestCases {
                Write-Host "Provider Anthropic and Capability TextStreaming - Model with Mandatory Parameters " + $_.Model
                $response = Create-GenAI-TextStreamResponse -Model $Model

                $response | Should -Not -BeNullOrEmpty

            }

            It "Test Case 270724: ST_TC_DM_259473: To Verify Completion in all Models where Capabilty = TextStreaming with all optional Parametes Min Value" -TestCases $AnthropicTextStreamingTestCases[0] {
                Write-Host "Provider Anthropic and Capability TextStreaming - Model with Min Values Parameters " + $_.Model
                $requestParams = @{
                    Method = 'POST'
                    Uri    = "/workspace/api/v1/generativeai/text/stream"
                    Body   = @{
                        "modelName"      = $Model
                        "engagementCode" = $engagementCode
                        "prompt"         = "Who won the Cricket World Cup in 1983"
                        "parameters"     = @{
                            "temperature" = 0
                            "max_tokens"  = 1  #Marking as 1 to reduce consumtion of tokens
                            "top_k"       = 0
                            "top_p"       = 0
                            #"n"                 = 1

                        }
                    } | ConvertTo-Json
                }
                $TextSGenAIResponse = $null
                $TextSGenAIResponse = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true
                Write-Host "Response for all fields is ---  $TextSGenAIResponse"

                $TextSGenAIResponse | Should -Not -BeNullOrEmpty

            }

            It "Test Case 270724: ST_TC_DM_259473: To Verify Completion in all Models where Capabilty = TextStreaming with all optional Parametes Max Value" -TestCases $AnthropicTextStreamingTestCases[0] {
                Write-Host "TextStreaming - Model with Max Values Parameters - Running for  " + $_.Model
                $requestParams = @{
                    Method = 'POST'
                    Uri    = "/workspace/api/v1/generativeai/text/stream"
                    Body   = @{
                        "modelName"      = $Model
                        "engagementCode" = $engagementCode
                        "prompt"         = "Who won the Cricket World Cup in 1983"
                        "parameters"     = @{
                            "temperature" = 1
                            "max_tokens"  = 1  #Marking as 1 to reduce consumtion of tokens
                            "top_k"       = 1
                            "top_p"       = 1
                            #"n"                 = 100

                        }
                    } | ConvertTo-Json
                }
                $TextSGenAIResponse = $null
                $TextSGenAIResponse = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true
                $TextSGenAIResponse | Should -Not -BeNullOrEmpty

            }

            It "Test Case 270726: ST_TC_DM_259473: Negative TC To Verify Error in Completion in all Models where Capabilty = TextStreaming with Invalid Parameters Values" -TestCases $AnthropicTextStreamingTestCases[0] {
                Write-Host "TextStreaming - Model with Invalid  Parameters Values  - Running only first model ---- " + $_.Model
                $requestParams = @{
                    Method = 'POST'
                    Uri    = "/workspace/api/v1/generativeai/text/stream"
                    Body   = @{
                        "modelName"      = $Model
                        "engagementCode" = $engagementCode
                        "prompt"         = "Who won the Cricket World Cup in 1983"
                        "parameters"     = @{
                            "temperature" = Get-Random -Minimum -13 -Maximum -10
                            "max_tokens"  = Get-Random -Minimum -20 -Maximum -10
                            "top_p"       = Get-Random -Minimum 15 -Maximum 24
                            "top_k"       = Get-Random -Minimum -12 -Maximum 12
                        }
                    } | ConvertTo-Json
                }
                $response = @{}
                $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true
                Write-Host "Response ---  $($response.ErrorDetails.message)"
                $response.ExceptionResponse.StatusCode.value__ | Should -be 400
            }
        }
    }
    Describe "User Story 300913: Enable JSON mode for GPT 4 Turbo" {
        Context "To Verify APIs related to Capability - AzureOpenAI CHAT Model GPT 4 TURBO" {

            It "Test Case 303065: ST_TC_DM_300913: (Postive Scenario)To Verify response of  Chat Completion for Model GPT 4 Turbo  in json Formate if 'JSON' is mentioned in response_format and Message." {
                Write-Host "Verifing response in GEN AI CHAT for Model - GPT 4 tubro in json form"
                $requestParams = @{
                    Method = 'POST'
                    Uri    = "/workspace/api/v1/generativeai/chat"
                    Body   = @{
                        "modelName"      = "GPT 4 Turbo"
                        "engagementCode" = $engagementCode
                        "messages"       = @( @{
                                "role"    = "system"
                                "content" = "You are a helpful assistant willing to answer questions about ICC world championship"
                            }, @{
                                "role"    = "User"
                                "content" = "Who won cricket world cup 2011 in json format?"  #Mandatory Mention Json Format in Prompt
                            })
                        "parameters"     = @{
                            "temperature"          = 1
                            "frequency_penalty"    = 0
                            "presence_penalty"     = 0
                            "max_tokens"           = 100
                            "response_format_type" = "json_object"
                        }
                    } | ConvertTo-Json
                }
                $response = $null
                $response = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true
                Write-Host "Response for json Mode ---  $response"
                $messageObject1 = [PSCustomObject] $response.choices[0]
                Write-host "Value in messageObject1 is $messageObject1"
                $message = $messageObject1.message
                Write-host "Message is $message"
                $isValidJSON = $message | Test-Json
                Write-host "Value in isValidJSON is $isValidJSON "
                $isValidJSON | Should -be $true

            }
            It "Test Case 303066: ST_TC_DM_300913: (Negative Scenario)To Verify response of Chat Completion for GPT 4 Turbo Model in json Formate if response_format_Type is not mentioned for Json" {
                Write-Host "Verifing response in GEN AI CHAT for Model - GPT 4 Turbo in json form"
                $requestParams = @{
                    Method = 'POST'
                    Uri    = "/workspace/api/v1/generativeai/chat"
                    Body   = @{
                        "modelName"      = "GPT 4 Turbo"
                        "engagementCode" = $engagementCode
                        "messages"       = @( @{
                                "role"    = "system"
                                "content" = "You are a helpful assistant willing to answer questions about ICC world championship"
                            }, @{
                                "role"    = "User"
                                "content" = "Who won cricket world cup 2011 in json format?"  #Mandatory Mention Json Format in Prompt
                            })
                        "parameters"     = @{
                            "temperature"       = 1
                            "frequency_penalty" = 0
                            "presence_penalty"  = 0
                            "max_tokens"        = 20
                        }
                    } | ConvertTo-Json
                }
                $response = $null
                $response = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true
                Write-Host "Response for GPT 4 Turbo without response_format_type in Body should be act as Chat Model ---  $response"
                $response | Should -Not -BeNullOrEmpty

            }
            It "Test Case 303067: ST_TC_DM_300913: (Negative Scenario) To Verify response of  Chat Completion for GPT 4 Turbo Model in json Formate if 'Json' in not mentioned in the Content." {
                Write-Host "Verifing response in GEN AI CHAT for Model - GPT 4 tubro in json form"
                $requestParams = @{
                    Method = 'POST'
                    Uri    = "/workspace/api/v1/generativeai/chat"
                    Body   = @{
                        "modelName"      = "GPT 4 Turbo"
                        "engagementCode" = $engagementCode
                        "messages"       = @( @{
                                "role"    = "system"
                                "content" = "You are a helpful assistant willing to answer questions about ICC world championship"
                            }, @{
                                "role"    = "User"
                                "content" = "Who won cricket world cup 2011?"  #should throw error for Mandatory Json Format in Prompt
                            })
                        "parameters"     = @{
                            "temperature"          = 1
                            "frequency_penalty"    = 0
                            "presence_penalty"     = 0
                            "max_tokens"           = 100
                            "response_format_type" = "json_object"
                        }
                    } | ConvertTo-Json
                }
                $response = @{}
                $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true
                Write-Host "Response ---  $($response.ErrorDetails.message)"
                $responseMessage = $($response.ErrorDetails.message) | ConvertFrom-Json
                $errorMessage = $($responseMessage.error.message)
                Write-Host "Error Message if Json is not mention in content = $errorMessage "
                $response.ExceptionResponse.StatusCode.value__ | Should -be 400
                $errorMessage | Should -Contain "'messages' must contain the word 'json' in some form, to use 'response_format' of type 'json_object'."

            }
            It "Test Case 303068: ST_TC_DM_300913: (Postive Scenario) To Verify response Finish Reason of  Chat Completion for GPT 4 Turbo Model in json Format.if Less Token show finishReason = Length otherwise finishReason Stop." {
                Write-Host "Verifing response in GEN AI CHAT for Model - GPT 4 tubro in json form"
                $requestParams = @{
                    Method = 'POST'
                    Uri    = "/workspace/api/v1/generativeai/chat"
                    Body   = @{
                        "modelName"      = "GPT 4 Turbo"
                        "engagementCode" = $engagementCode
                        "messages"       = @( @{
                                "role"    = "system"
                                "content" = "You are a helpful assistant willing to answer questions about ICC world championship"
                            }, @{
                                "role"    = "User"
                                "content" = "Who won cricket world cup 2011 in json format?"  #Mandatory Mention Json Format in Prompt
                            })
                        "parameters"     = @{
                            "temperature"          = 1
                            "frequency_penalty"    = 0
                            "presence_penalty"     = 0
                            "max_tokens"           = 1   #Value of Max Token is less to Verify Finish reason
                            "response_format_type" = "json_object"
                        }
                    } | ConvertTo-Json
                }
                $response = $null
                $response = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true
                Write-Host "Response for json Mode ---  $response"
                $FinishReason = [PSCustomObject] $response.choices[0].finishReason
                Write-host "Value in messageObject1 is $FinishReason"
                $FinishReason | Should -be "Max_Tokens"
            }
            It "Test Case 303069: ST_TC_DM_300913: (Negative Scenario) To Verify response on Chat Stream Completion for GPT 4 Turbo Model for Json Mode" {
                Write-Host "Verifing response in GEN AI CHAT for Model - GPT 4 tubro in json form"
                $requestParams = @{
                    Method = 'POST'
                    Uri    = "/workspace/api/v1/generativeai/chat/stream"
                    Body   = @{
                        "modelName"      = "GPT 4 Turbo"
                        "engagementCode" = $engagementCode
                        "messages"       = @( @{
                                "role"    = "system"
                                "content" = "You are a helpful assistant willing to answer questions about ICC world championship"
                            }, @{
                                "role"    = "User"
                                "content" = "Who won cricket world cup 2011 in json format?"  #Mandatory Mention Json Format in Prompt
                            })
                        "parameters"     = @{
                            "temperature"          = 1
                            "frequency_penalty"    = 0
                            "presence_penalty"     = 0
                            "max_tokens"           = 100
                            "response_format_type" = "json_object"
                        }
                    } | ConvertTo-Json
                }
                $response = @{}
                $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true
                Write-Host "Response ---  $($response.ErrorDetails.message)"
                $($response.ErrorDetails.message) | Should -Contain "Parameter/s 'response_format_type' is/are not supported for this model/capability"
            }
            #Test Case 303070 Already covered in chat streaming

            It "Test Case 303451: ST_TC_DM_300913: (Negative Scenario)To Verify response of  Chat Completion for GPT 4 Turbo Model in json Formate if response_format have Invalid value " {
                Write-Host "Verifing response in GEN AI CHAT for Model - GPT 4 tubro if response_format = 'Invalidformate'"
                $requestParams = @{
                    Method = 'POST'
                    Uri    = "/workspace/api/v1/generativeai/chat"
                    Body   = @{
                        "modelName"      = "GPT 4 Turbo"
                        "engagementCode" = $engagementCode
                        "messages"       = @( @{
                                "role"    = "system"
                                "content" = "You are a helpful assistant willing to answer questions about ICC world championship"
                            }, @{
                                "role"    = "User"
                                "content" = "Who won cricket world cup 2011 in Json Format?"  #should throw error for Mandatory Json Format in Prompt
                            })
                        "parameters"     = @{
                            "temperature"          = 1
                            "frequency_penalty"    = 0
                            "presence_penalty"     = 0
                            "max_tokens"           = 100
                            "response_format_type" = "Invalidformate"
                        }
                    } | ConvertTo-Json
                }
                $response = @{}
                $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true
                Write-Host "Response ---  $($response.ErrorDetails.message)"
                $responseMessage = $($response.ErrorDetails.message) | ConvertFrom-Json
                $errorMessage = $($responseMessage.error.message)
                Write-Host "Error Message if Json is not mention in content = $errorMessage "
                $response.ExceptionResponse.StatusCode.value__ | Should -be 400
                $errorMessage | Should -Contain "'Invalidformate' is not one of ['json_object', 'text'] - 'response_format.type'"

            }
            It "Test Case 303072: ST_TC_DM_300913: (Postive Scenario) To Verify response of GPT 4 Turbo Model in Open AI Chat Completion Role as User" {
                Write-Host "Verifing response in Chat Completion of Model gpt-4-turbo-2024-04-09 in json form"
                $requestParams = @{
                    Method = 'POST'
                    Uri    = "/workspace/api/v1/ai/deployment/gpt-4-turbo-2024-04-09/chat/completion"
                    Body   = @{
                        "engagementCode"                 = $engagementCode
                        "messages"                       = @( @{
                                "role"    = "system"
                                "content" = "You are a helpful assistant willing to answer questions about ICC world championship"
                            }, @{
                                "role"    = "User"
                                "content" = "Who won cricket world cup 2011 in json format?"  #Mandatory Mention Json Format in Prompt
                            })
                        "temperature"                    = 1
                        "frequency_penalty"              = 0
                        "presence_penalty"               = 0
                        "max_tokens"                     = 100
                        "appendTrailingWhitespaceToStop" = $false
                        "responseFormat"                 = @{
                            "type" = "json_object"
                        }

                    } | ConvertTo-Json
                }
                $response = $null
                $response = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true
                Write-Host "Response for json Mode ---  $response"
                $messageObject1 = [PSCustomObject] $response.choices[0]
                Write-host "Value in messageObject1 is $messageObject1"
                $message = $messageObject1.message.content
                Write-host "Message is $message"
                $isValidJSON = $message | Test-Json
                Write-host "Value in isValidJSON is $isValidJSON "
                $isValidJSON | Should -be $true

            }
            It "Test Case 303072: ST_TC_DM_300913: (Postive Scenario) To Verify response of GPT 4 Turbo Model in Open AI Chat Completion - Role as Assistant (Recommended)" {
                Write-Host "Verifing response in Chat Completion of Model gpt-4-turbo-2024-04-09  in json form"
                $requestParams = @{
                    Method = 'POST'
                    Uri    = "/workspace/api/v1/ai/deployment/gpt-4-turbo-2024-04-09/chat/completion"
                    Body   = @{
                        "engagementCode"                 = $engagementCode
                        "messages"                       = @( @{
                                "role"    = "system"
                                "content" = "You are a helpful assistant willing to answer questions about ICC world championship"
                            }, @{
                                "role"    = "Assistant"
                                "content" = "Who won cricket world cup 2011 in json format?"  #Mandatory Mention Json Format in Prompt
                            })
                        "temperature"                    = 1
                        "frequency_penalty"              = 0
                        "presence_penalty"               = 0
                        "max_tokens"                     = 100
                        "appendTrailingWhitespaceToStop" = $false
                        "responseFormat"                 = @{
                            "type" = "json_object"
                        }

                    } | ConvertTo-Json
                }
                $response = $null
                $response = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true
                Write-Host "Response for json Mode ---  $response"
                $messageObject1 = [PSCustomObject] $response.choices[0]
                Write-host "Value in messageObject1 is $messageObject1"
                $message = $messageObject1.message.content
                Write-host "Message is $message"
                $isValidJSON = $message | Test-Json
                Write-host "Value in isValidJSON is $isValidJSON "
                $isValidJSON | Should -be $true

            }
            It "Test Case 303071: ST_TC_DM_300913: (Negative Scenario) To Verify response of GPT 4 Turbo Model should not work in other Capabilities except Chat and Chat Streaming" {
                Write-Host "Verifing response in GEN AI TEXT for Model - GPT 4 Tubro"

                $requestParams = @{
                    Method = 'POST'
                    Uri    = "/workspace/api/v1/generativeai/text"
                    Body   = @{
                        "modelName"      = "GPT 4 Turbo"
                        "engagementCode" = $engagementCode
                        "prompt"         = "List of top 5 IT company"
                    } | ConvertTo-Json
                }
                $response = @{}
                $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true
                Write-Host "Response ---  $($response.ErrorDetails.message)"
                $response.ExceptionResponse.StatusCode.value__ | Should -be 400
                $response.ErrorDetails.message | Should -be "Model 'GPT 4 Turbo' does not support the 'Text' capability"

            }
        }
    }
    Describe "User Story 311246: Generative AI- Add 'IsEnabled' flag to capabilities in generative ai model endpoint"{
        Context "Generative AI -  To verify Model has capability details along with Enabled flags"{
            BeforeAll{
                Write-Host "GenAI- Model with capabilities enabled flag ----GET method"
                $requestParams = @{
                    Method = 'GET'
                    Uri    = "/workspace/api/v1/generativeai/modelwithcapabilities"
                }
                $modelWithCapabilitiesResponse = @{}
                $modelWithCapabilitiesResponse = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true
                Write-Host "--First Model in the response list ---$($modelWithCapabilitiesResponse[0].modelName)"
                $firstModelWithCapabilitiesResponse = $modelWithCapabilitiesResponse[0].capabilities
            }
            It "Test Case 323825: ST_TC_DM_311246: Generative AI -  To verify list of All Models has capability details along with Enabled flags"{
                Write-Host "Model has capabilities details along with Enabled flag in the response"
                foreach ($Item in $firstModelWithCapabilitiesResponse) {
                    Write-Host "Item value in response ---$Item"
                    $Item.capabilityKey | Should -Not -BeNullOrEmpty
                    $Item.isEnabled | Should -Not -BeNullOrEmpty
                }
            }
        }

    }

}