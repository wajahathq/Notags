param(
    [Parameter(Mandatory)]
    [ValidateNotNullOrEmpty()]
    $CurrentEnvironmentData
)

Describe "Uploading file and extracting file content to plain text" -Tag "long-running" {

    Context "File uploading and content extraction" {
        BeforeDiscovery {
            #Creation of new Product-----------
            $Script:service = "workspace"
            $contextId = Get-Date -Format "yyyyMMddHHmmss"
            Write-Host "Creating a Product for Content Extraction testcases......"
            $script:productname = "TestProduct$($CurrentEnvironmentData.Environment)$($contextId)"
            $requestParams = @{
                Method = 'POST'
                Uri    = "/workspace/api/v1/product"
                Body   = @{
                    "productName"        = $productname
                    "engagementCode"     = "803000012512"  #this might change
                    "expirationDateTime" = (Get-Date).AddDays(+1).ToString("yyyy-MM-ddThh:mm:ss.000Z")
                    "requestedFor"       = @(
                        "sulagnabehera@kpmg.com"
                    )
                } | ConvertTo-Json
            }
            $productResponse = @{}
            $productResponse = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true
            $productTaskResult = @{}
            $productTaskResult = Get-BackgroundStatus $CurrentEnvironmentData $productResponse.taskId "$($service)"
            $Script:productId = $productTaskResult.taskOutput.productId
            Write-Host "Product Id is - $($productId)"

            #creation of product component-----------
            Write-Host "Creating Product Component......."
            $requestParams = @{
                Method = 'POST'
                Uri    = "/workspace/api/v1/product/$($productId)/component"
                Body   = @{
                    "componentName" = "CompFor$($productId)"
                    "blueprintKey"  = "dmz-storage-container"
                } | ConvertTo-Json
            }
            $componentResponse = @{}
            $componentResponse = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true
            $componentTaskResult = @{}
            $componentTaskResult = Get-BackgroundStatus $CurrentEnvironmentData $componentResponse.taskId "$($service)"
            $Script:componentId = $componentTaskResult.taskOutput.componentId
            Write-Host "Component Id is - $($componentId)"

            #Fetching the container name
            $requestParams = @{
                Method = 'GET'
                Uri    = "/workspace/api/v1/product/$($productId)/component/$($componentId)/part"
            }

            $ContainerResponse = @{}
            $ContainerResponse = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true

            $Script:containerName = $ContainerResponse.remoteParts[1].propertyKeyValuePairs.containerName
            Write-Host "Container name is - $($containerName)"

            #uploading file to container
            $clientId = $($CurrentEnvironmentData.ClientId)
            $clientSecret = $($currentEnvironmentData.ClientSecret)
            $tenantId = $($CurrentEnvironmentData.TenantId)
            $tempPassword = ConvertTo-SecureString "$clientSecret" -AsPlainText -Force
            $psCred = New-Object System.Management.Automation.PSCredential($clientId , $tempPassword)
            Connect-AzAccount -Credential $psCred -TenantId $tenantId  -ServicePrincipal
            Write-Host  "Azure is connected"

            $Context = New-AzStorageContext -StorageAccountName $($CurrentEnvironmentData.SAccountName)

            $FileUploadTestCases = New-Object System.Collections.Generic.List[Hashtable]
            $UploadFolder = ".\tests\FilesForContentExtraction"

            foreach ($File in (Get-ChildItem $UploadFolder)) {
                $fileName = $File.Name
                #Calling out function for Fileupload with Retry logic

                $IsUploaded = FileUploadUsingAzConnect $fileName $containerName $UploadFolder

                # FailEarly 'Validate if Upload is Successful' {
                #  Write-Host "value should be -  $($IsUploaded.Value) "
                # $($IsUploaded.Value) | Should -eq  $true
                # }

                Write-Host  "File Upload done in azure stroage container for $($fileName)"

                $FileUploadTestCases.Add(@{
                        'fileName' = $fileName
                    })
                $FileList += $($fileName)
            }

            Write-Host "Files availabe in the list are $($FileList)"
        }
        It "Should return 200 status with extracted content for $($fileName)" -TestCases $FileUploadTestCases {
            Write-Host "Content extraction for----" + $($fileName)
            $FileResponse = Content-Extraction -fileName $fileName
            $filenameWithoutExtension = [System.IO.Path]::GetFileNameWithoutExtension($fileName)
            $FileResponse.fileName | Should -eq $filenameWithoutExtension
        }

    }

    Context "Generate uri for given product and component for invalid lifeSpanDays (Negative TC)" {
        BeforeAll {
            $requestParams = @{
                Method = 'POST'
                Uri    = "/workspace/api/v1/product/$($productId)/component/$($componentId)/sastoken"
                Body   = @{
                    "directoryOrBlobPath" = "pdfDemo.pdf"
                    "lifeSpanDays"        = 8
                } | ConvertTo-Json
            }

            $response = @{}
            $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true
        }

        It "Should return 409 status code for invalid value of lifeSpanDays" {
            $response.ExceptionResponse.StatusCode.value__ | Should -be 409
        }

        It "Should return user friendly message for invalid value of lifeSpanDays" {
            $response.ErrorDetails.message | should -eq "Maximum lifespan of SAS URI must be less than or equal to 7 days."
        }
    }

    Context "Generate uri for given product and component for unknown permission value (Negative TC)" {
        BeforeAll {
            $requestParams = @{
                Method = 'POST'
                Uri    = "/workspace/api/v1/product/$($productId)/component/$($componentId)/sastoken"
                Body   = @{
                    "directoryOrBlobPath" = "pdfDemo.pdf"
                    "lifeSpanDays"        = 1
                    "permissions"         = @("Unknown")
                } | ConvertTo-Json
            }

            $response = @{}
            $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true
        }

        It "Should return 400 status code for unknown permission value" {
            $response.ExceptionResponse.StatusCode.value__ | Should -be 400
        }

        It "Should return user friendly message for unknown permission value" {
            $response.ErrorDetails.errors.generateSasTokenInput | should -eq "The generateSasTokenInput field is required."
        }
    }

    Context "Generate uri for given product and component for invalid ipAddressRange (Negative TC)" {
        BeforeAll {
            $requestParams = @{
                Method = 'POST'
                Uri    = "/workspace/api/v1/product/$($productId)/component/$($componentId)/sastoken"
                Body   = @{
                    "directoryOrBlobPath" = "pdfDemo.pdf"
                    "lifeSpanDays"        = 1
                    "permissions"         = "Read"
                    "ipAddressRange"      = @{
                        "to" = "10.210.234.52"
                    }
                } | ConvertTo-Json
            }

            $response = @{}
            $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true
        }

        It "Should return 400 status code for invalid ipAddressRange" {
            $response.ExceptionResponse.StatusCode.value__ | Should -be 400
        }

    }

    Context "Generate uri for given product and component for invalid productId and componentId (Negative TC)" {
        BeforeAll {
            $requestParams = @{
                Method = 'POST'
                Uri    = "/workspace/api/v1/product/1212331/component/3433334/sastoken"
                Body   = @{
                    "directoryOrBlobPath" = "pdfDemo.pdf"
                } | ConvertTo-Json
            }

            $response = @{}
            $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true
        }

        It "Should return 404 status code for invalid productId and componentId" {
            $response.ExceptionResponse.StatusCode.value__ | Should -be 404
        }

        It "Should return user friendly message for invalid productId and componentId" {
            $response.ErrorDetails.message | should -eq "Product with specified ID not found: 1212331"
        }
    }

    Context "Extract file content where SasUri is missing  Empty(Negative TC)" {
        BeforeAll {
            $requestParams = @{
                Method = 'POST'
                Uri    = "/workspace/api/v1/contentextraction/extractplaintext"
                Body   = @{
                    "fileSasUri" = ""
                } | ConvertTo-Json
            }

            $response = @{}
            $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true
        }

        It "Should return 400 status code where SasUri is missing" {
            $response.ExceptionResponse.StatusCode.value__ | Should -be 400
        }

        It "Should return user friendly message where SasUri is missing" {
            $response.ErrorDetails.errors.FileSasUri | should -Contain "The FileSasUri field is required."
        }
        It "Should return user friendly message where SasUri is missing" {
            $response.ErrorDetails.errors.FileSasUri | should -Contain "The FileSasUri field is not a valid fully-qualified http, https, or ftp URL."
        }
    }

    Context "Extract file content for blank request body in sasuri generation (Negative TC)" {
        BeforeAll {
            $requestParams = @{
                Method = 'POST'
                Uri    = "/workspace/api/v1/product/$($productId)/component/$($componentId)/sastoken"
                Body   = @{

                } | ConvertTo-Json
            }

            $uriResponseForBlankFile = @{}
            $uriResponseForBlankFile = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true
            $sasUriForBlankFile = $uriResponseForBlankFile.sasUri
            Write-Host "The Sas URI for "
            $requestParams = @{
                Method = 'POST'
                Uri    = "/workspace/api/v1/contentextraction/extractplaintext"
                Body   = @{
                    "fileSasUri" = "$($sasUriForBlankFile)"
                } | ConvertTo-Json
            }

            $response = @{}
            $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true
        }

        It "Should return 403 status code for blank request body in sasuri generation" {
            $response.ExceptionResponse.StatusCode.value__ | Should -be 403
        }


    }

    AfterAll {
        #Deleting the product component
        $requestParams = @{
            Method = 'DELETE'
            Uri    = "/workspace/api/v1/product/$($productId)/component/$($componentId)"
        }

        $deleteResponseForComp = @{}
        $deleteResponseForComp = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true

        $deleteTaskResultForComp = @{}
        $deleteTaskResultForComp = Get-BackgroundStatus $CurrentEnvironmentData $($deleteResponseForComp.taskId) "$($service)"

        #Deleting the product
        $requestParams = @{
            Method = 'DELETE'
            Uri    = "/workspace/api/v1/product/$($productId)"
        }

        $deleteResponseForProduct = @{}
        $deleteResponseForProduct = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true

        $deleteTaskResultForProduct = @{}
        $deleteTaskResultForProduct = Get-BackgroundStatus $CurrentEnvironmentData $($deleteResponseForProduct.taskId) "$($service)"
        Write-Host "Product $productId is deleted "
    }


}
Describe "Content Extraction API - Testcases related using deleted Product and its component for Content Extractions " -Tag "long-running" {

    Context "Test Case 281201: ST_TC_DM_277734: Generate uri for given product and component (Negative TC)" {

        It "should throw an Error 400 While generating SAS Token for deleted Product  and Components" {
            Write-Host "Trying to fetch SAS Token for Deleted product  $productId and $componentId"

            $requestParams = @{
                Method = 'POST'
                Uri    = "/workspace/api/v1/product/$($productId)/component/$($componentId)/sastoken"
                Body   = @{
                    "directoryOrBlobPath" = "textdemo.pdf"
                } | ConvertTo-Json
            }

            $response = @{}
            $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true
            Write-Host "Response is $response"

            $response.ExceptionResponse.StatusCode.value__ | Should -be 400
            $response.ErrorDetails.message | Should -be "Product is not active."
        }

    }

}
