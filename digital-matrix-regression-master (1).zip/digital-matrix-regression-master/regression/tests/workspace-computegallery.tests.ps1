param(

    [Parameter(Mandatory)]
    [ValidateNotNullOrEmpty()]
    $CurrentEnvironmentData

)

$script:osType = @("Windows", "Linux")
Describe "Workspace API - AzureComputeGallery" { 
    Context "DM_Workspace_API_110_01 - DM_Workspace_API_110_06 | Contains all public endpoints related to Azure Compute Gallery " {                             
    
        #get the image name in diffrent OS
        $requestParams = @{
            Method = 'GET'
            Uri    = "/workspace/api/v1/azurecomputegallery"                     
        }
        $responselist = @{}
        $responselist = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true 
        $script:imageNameList = $($responselist.imageName)
        Context "AzureComputeGallery with osType and imageName" {  
        foreach ($item in $osType) {
            $requestParams = @{
                Method = 'GET'
                Uri    = "/workspace/api/v1/azurecomputegallery?osType=$($item)"                     
            }
            $OsTypeResponse = @{}
            $OsTypeResponse = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true 
            $osImageList = $($OsTypeResponse.imageName)
                foreach ($item1 in $imageNameList) {
                    if($($osImageList) -match $($item1)){
                        $requestParams = @{
                            Method = 'GET'
                            Uri    = "/workspace/api/v1/azurecomputegallery?osType=$($item)&imageName=$($item1)"                     
                        }
                        $OsTypeResponseImage = @{}
                        $OsTypeResponseImage = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true
                        It "The osType should match with the response $($item)" {   
                            $($OsTypeResponseImage.osType) | should -eq $($item)  
                        }
                        It "The imageName should match with the response $($item1)" {  
                            $($OsTypeResponseImage.imageName) | should -match $($item1)    
                        }
                    }
                    else {
                            Write-Host "searching for ostype-$($item) and imagename-$($item1)"
                            $requestParams = @{
                                Method = 'GET'
                                Uri    = "/workspace/api/v1/azurecomputegallery?osType=$($item)&imageName=$($item1)"                     
                            }
                            $response = @{}
                            $script:response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true
                             
                            It "Should return 404 Not Found for ostype-$($item) and imagename-$($item1)" {                               
                                $response.ExceptionResponse.StatusCode.value__ | Should -be 404 
                            }
                            It "Should return user friendly message for ostype-$($item) and imagename-$($item1)" { 
                                $response.ErrorDetails.Message | should -be "There are no images in the gallery that match your search."
                                
                            } 
                            
                        }        
                }    
        }
        }  
    }          
    
    

    Context "Azurecompute gallery | with osType as null and search with only image name "{
        foreach ($item1 in $imageNameList) {
            $requestParams = @{
                Method = 'GET'
                Uri    = "/workspace/api/v1/azurecomputegallery?imageName=$($item1)"                     
            }
            $response = @{}
            $response = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true
        
            It "should match with imageName $($item1)" {   
                $response.imagename | Should -match $($item1)  
            }
 
        } 
    }
    # Negative Scenarios
    Context "Azurecompute gallery | with osType as Unknown"{
        BeforeAll {
            $requestParams = @{
                Method = 'GET'
                Uri    = "/workspace/api/v1/azurecomputegallery?osType=Unknown"                     
            }
            $response = @{}
            $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true
        }
        It "should match with status code as 404 not found " {   
            $response.ExceptionResponse.StatusCode.value__ | Should -be 404     
        }
 
        It "Should display user friendly message" {   
            $response.ErrorDetails.Message | should -be "There are no images in the gallery that match your search."
        }  
    }

    Context "Azurecompute gallery | with osType as null and search with invalid image name "{
        BeforeAll {
            $imageName="4@5%6"
            $requestParams = @{
                Method = 'GET'
                Uri    = "/workspace/api/v1/azurecomputegallery?imageName=$($imageName)"                     
            }
            $response = @{}
            $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true
        }
        It "should match with status code as 404 not found " {   
            $response.ExceptionResponse.StatusCode.value__ | Should -be 404     
        }
 
        It "Should display user friendly message" {   
            $response.ErrorDetails.Message | should -be "There are no images in the gallery that match your search."
        }  
 
         
    }
   
}