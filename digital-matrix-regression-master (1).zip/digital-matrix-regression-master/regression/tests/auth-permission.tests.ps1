﻿param(

    [Parameter(Mandatory)]
    [ValidateNotNullOrEmpty()]
    $CurrentEnvironmentData

)

Describe "Auth" -Tag "Permission" {
<#Context "Hey There ! Running HeathCheck"{
        $service = "Auth"
        $Healthresponse = Run-Health-check $CurrentEnvironmentData $service
        Write-Host "Healthcheck Response is $Healthresponse "
        FailEarly 'Healthcheck for Workspace' {
            $Healthresponse | Should -Be "True"
        }
} #>
#added Testcases
Context "GET /api/v1/permission" {

    Context "DM_Auth_API_05| permissionKey-list" {

        BeforeAll {
            $requestParams = @{
                Method = 'GET'
                Uri    = "/auth/api/v1/permission"
            }

            $responsePermissionList = @{}
            $responsePermissionList = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true
        }
        It "Should not return null" {
            $responsePermissionList.permissionKey | Should -not -BeNullOrEmpty
        }

        It "Should return at least one record" {
            $responsePermissionList.permissionKey.Count | Should -BeGreaterThan 0
        }
    }

}

Context "GET /api/v1/permission/{permissionKey}" {

    Context "DM_Auth_API_06_00| non-existing Numeric permissionKey" {
        BeforeAll {

            $requestParams = @{
                Method = 'GET'
                Uri    = "/auth/api/v1/permission/1234"
            }

            $response = @{}

            # we know this will return something other than a 200 response, so we're using the special error handler method
            $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true

        }
        It "Should return NotFound" {
            $response.ExceptionResponse.StatusCode.value__ | Should -be 404
        }
        It "Should return user friendly message" {
            $response.ErrorDetails.Message | should -be "Permission with key does not exist: Unknown"
        }
    }

    Context "DM_Auth_API_06_01-06_84|GET All Permissions from existing permissionKey List" {

        #will take out list of permissions from api
        $requestParams = @{
            Method = 'GET'
            Uri    = "/auth/api/v1/permission"
        }
        $PermissionListresponse = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true


        Write-Host "List of Roles in Response is ---- $($PermissionListresponse.permissionKey)"

        foreach ($item in $PermissionListresponse) {

            $requestParams = @{
                Method = 'GET'
                Uri    = "/auth/api/v1/permission/$($item.permissionKey)"
            }
            $response = @{}
            $response = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true

            It "Should not Null" {
                $PermissionListresponse.count |  Should -not -BeNullOrEmpty
            }
            It "should contain Role Details for  $($item.permissionKey) Permission Key" {
                $response.permissionKey | Should -contain  $($item.permissionKey)
            }

        }


    }


    Context "DM_Auth_API_07_13|non-existing SpecialChar roleName" {

        BeforeAll {

            $requestParams = @{
                Method = 'GET'
                Uri    = "/auth/api/v1/permission/role/%27%21%402123sd"
            }

            $response = @{}

            # we know this will return something other than a 200 response, so we're using the special error handler method
            $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true

        }
        It "Should return NotFound" {
            $response.ExceptionResponse.StatusCode.value__ | Should -be 404
        }
        It "Should return user friendly message" {
            $response.ErrorDetails.Message | should -be "Role name '!@2123sd does not exist."
        }
    }

    Context "DM_Auth_API_07_01-07_17| Verify Permission by all existing roleName List" {


        #Will take out the list of Roles from API (/auth/api/v1/role)
        $requestParams = @{
            Method = 'GET'
            Uri    = "/auth/api/v1/role"
        }

        $RoleresponseList = @{}
        $RoleresponseList = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true
        #Write-Host "List of Roles in Response is ---- $($RoleresponseList.name)"

        foreach ($item in $RoleresponseList) {

            $requestParams = @{
                Method = 'GET'
                Uri    = "/auth/api/v1/permission/role/$($item.name)"
            }
            $response = @{}
            $response = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true
            Write-Host "Value in RESPONSE is $($response[0])"

            Write-Host "Role name $($item.name) has $( $response.count) permissions  "

            It "Should not return null" {
                $RoleresponseList.count | Should -not -BeNullOrEmpty
            }

            It "Should return at least one record for $($item.name)" {
                foreach ($item in $RoleresponseList) {
                    $response.Count | Should -BeGreaterThan 0
                }
            }
        }

    }
}

}

