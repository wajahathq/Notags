param(

    [Parameter(Mandatory)]
    [ValidateNotNullOrEmpty()]
    $CurrentEnvironmentData

)

$script:engagementCode = "803000012512"
$SkipEnvironmentList = @('CAT', 'UAT', 'Production')

Describe "GEN AI UPSERT Endpoint - Workspace API Generative AI Register Model and Provider Instances Only in Azure Open AI " -Skip:($SkipEnvironmentList.Contains($CurrentEnvironmentData.Environment)) {
    BeforeDiscovery {
        #Declaring variables and its Values
        Write-Host "Defining Generic Values"
        $Script:date = Get-Date -Format "yyyyMMdd-HHmmss"
        $script:OpenAi_DummymodelName = "DummyModel_OpenAI$($CurrentEnvironmentData.Environment)$($date)"
        #$script:DummymodelName = "DummyModel_Test$($CurrentEnvironmentData.Environment)$($date)"
        $script:OpenAI_providerInstanceName = "oai-usw-dm-poc" # Using POC in KeyVault config
        $script:OpenAI_ValidAuthConfigKey = "OpenAi:USW:POC:ApiKey"

        #Negative scenario Model and Provider Instances Non Existing
        $script:ProviderInstances_ForNegativeScenario = "TestProviderInstaces_NegativeScenarios"
        $script:ModelName_ForNegativeScenario = "TestModel_NegativeScenarios"

    }

    BeforeAll {

        Write-Host "Registering / Updating a POC Provider Instances in AzureOpenAI  - $OpenAI_providerInstanceName"

        $requestParams = @{
            Method = 'POST'
            Uri    = "/workspace/api/v1/generativeai/providerinstance"
            Body   = @{
                "providerInstanceName" = $OpenAI_providerInstanceName
                "providerName"         = "AzureOpenAI"
                "GeoLocation"          = "GLOBAL"
                "authConfigurationKey" = $OpenAI_ValidAuthConfigKey
                "isEnabled"            = $true
            } | ConvertTo-Json
        }
        $OpenAiproviderresponse = @{}
        $OpenAiproviderresponse = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true

        Write-Host "Waiting 400 Sec to Cache refresh"
        Start-Sleep -Seconds 400

    }

    Describe "GET PROVIDER INSTANCES - User Story 300302: Digital Matrix - Gen AI - List All Provider Instances" {
        It "ST_TC_DM_300302: (Positive TC) To Verify list of all Provider Instance " {
            Write-Host "GET Method - Fetching list of Provider Instances"
            $requestParams = @{
                Method = 'GET'
                Uri    = "/workspace/api/v1/generativeai/providerinstance"
            }

            $response = @{}
            $response = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true

            Write-Host "No of Provider Instances = $($response.Count) "
            $response | Should -Not -BeNullOrEmpty

        }

    }

    Describe "User Story 299823: Digital Matrix - Gen AI - Register/Update Provider Instance" {

        Context "CREATE PROVIDER INSTANCES - Assertions" {
            It "Should be able to create AzureOpenAI ProviderInstance" {
                $OpenAiproviderresponse | Should  -BeNullOrEmpty
            }
            It "Should return providerInstanceName = $($OpenAI_providerInstanceName) from GET Method" {
                Write-Host "Fetching Provider instaces to verify listed New Provider instance "
                $containsProviderIns = GetStateProviderInstances $OpenAI_providerInstanceName $true

                Write-Host " Provider Instance found = $containsProviderIns "
                $containsProviderIns | Should -Be $true
            }

        }

        #Updating Provider Instances without AuthConfig Key - Update should work.
        Context "Update ProviderInstances without AuthConfigKey ---- To Validate Provider Instaces get Updated when AuthConfig Key is Not Mentioned in Body" {
            BeforeAll {

                Write-Host "Verifying  Update Provider Instance with AuthConfigKey field is not present"
                $requestParams = @{
                    Method = 'POST'
                    Uri    = "/workspace/api/v1/generativeai/providerinstance"
                    Body   = @{
                        "providerInstanceName" = $OpenAI_providerInstanceName
                        "GeoLocation"          = "GLOBAL"  #Removed AuthConfigKeyConfig and Provider Name from the Request body
                        "isEnabled"            = $true
                    } | ConvertTo-Json
                }
                $response = @{}
                $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true

            }
            It "Should Update other values in Provider Instaces without and AuthConfig Key" {
                $response | Should -BeNullOrEmpty
            }
        }

        Context "Update ProviderInstances with Invalid AuthConfigKey --- To Validate Upsert Provider Instaces with Invalid AuthConfigKey (Not in KVL) " {
            BeforeAll {
                Write-Host "Provider Instances Validation of AuthConfigKey"

                $requestParams = @{
                    Method = 'POST'
                    Uri    = "/workspace/api/v1/generativeai/providerinstance"
                    Body   = @{
                        "providerInstanceName" = $OpenAI_providerInstanceName
                        "GeoLocation"          = "GLOBAL"
                        "authConfigurationKey" = "InvalidAuthConfigKey-notinKVL"
                        "isEnabled"            = $true
                    } | ConvertTo-Json
                }
                $response = @{}
                $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true


            }
            It "Test Case 306584: ST_TC_DM_303807: (Negative TC) To Verify response for Upsert Provider Instances throw Error when Invalid AuthConfigKey" {
                Write-Host "Response ---  $($response.ErrorDetails.message)"
                $response.ExceptionResponse.StatusCode.value__ | Should -be 404
                $($response.ErrorDetails.message)  | Should -be "Provided AuthConfiguration key 'InvalidAuthConfigKey-notinKVL' is not found in KeyVault."
            }
        }

        #Negative Scenarios on Create Provider Instances
        Context "Create ProviderInstances where AuthConfig Key Field is missing --- To Validate Upsert Provider Instaces where AuthConfig Key is missing" {
            BeforeAll {

                Write-Host "Verifying  of Provider Instance with AuthConfigKey field is not present"

                $requestParams = @{
                    Method = 'POST'
                    Uri    = "/workspace/api/v1/generativeai/providerinstance"
                    Body   = @{
                        "providerInstanceName" = $ProviderInstances_ForNegativeScenario
                        "providerName"         = "AzureOpenAI"
                        "GeoLocation"          = "GLOBAL"
                        "isEnabled"            = $true
                    } | ConvertTo-Json
                }
                $response = @{}
                $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true
            }

            It "Test Case 306572: ST_TC_DM_303807: (Negative TC) To Verify response for Upsert of Creating New Provider Instances without AuthConfigKey should throw error" {

                $($response.ErrorDetails.message) | Should -be "AuthConfiguration key is required."

            }
        }

        Context "Create ProviderInstances where AuthConfig Empty/NULL --- To Validate AuthConfig Key Should be Should not be Empty/NULL " {
            BeforeAll {

                Write-Host "Verifying  of Provider Instance with AuthConfigKey field = null"
                $requestParams = @{
                    Method = 'POST'
                    Uri    = "/workspace/api/v1/generativeai/providerinstance"
                    Body   = @{
                        "providerInstanceName" = $ProviderInstances_ForNegativeScenario
                        "providerName"         = "AzureOpenAI"
                        "GeoLocation"          = "GLOBAL"
                        "authConfigurationKey" = ""
                        "isEnabled"            = $true
                    } | ConvertTo-Json
                }
                $response = @{}
                $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true

            }

            It "Test Case 306574: ST_TC_DM_303807: (Negative TC) To Verify response for Upsert Provider Instances throw Error when AuthConfigKey = Blank" {

                Write-Host "Response ---  $($response.ErrorDetails.message)"
                $($response.ErrorDetails.message)  | Should -be "AuthConfiguration key is required."

            }
        }

        Context "Create ProviderInstances where Provider Key Field is missing --- To Validate Upsert Provider Instaces where Provider is missing" {
            It "throw an Error When Provider in missing" {
                Write-Host "Verifying  of Provider Instance with Provider field is not present"

                $requestParams = @{
                    Method = 'POST'
                    Uri    = "/workspace/api/v1/generativeai/providerinstance"
                    Body   = @{
                        "providerInstanceName" = $ProviderInstances_ForNegativeScenario
                        "GeoLocation"          = "GLOBAL"
                        "authConfigurationKey" = $OpenAI_ValidAuthConfigKey
                        "isEnabled"            = $false

                    } | ConvertTo-Json
                }
                $response = @{}
                $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true


                $($response.ErrorDetails.message) | Should -be "Provider is required."

            }
        }
        Context "Create ProviderInstances Where Provider = Empty/Null --- To Validate Provider Name Should not be Empty/NULL for Upsert Provider Instance " {
            It "Test Case 306574: ST_TC_DM_303807: (Negative TC) To Verify response for Upsert Provider Instances throw Error when Provider = Blank" {

                Write-Host "Verifying  of Provider Instance with Provider field = null"
                $requestParams = @{
                    Method = 'POST'
                    Uri    = "/workspace/api/v1/generativeai/providerinstance"
                    Body   = @{
                        "providerInstanceName" = $ProviderInstances_ForNegativeScenario
                        "providerName"         = ""
                        "GeoLocation"          = "GLOBAL"
                        "authConfigurationKey" = $OpenAI_ValidAuthConfigKey
                        "isEnabled"            = $true
                    } | ConvertTo-Json
                }
                $response = @{}
                $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true

                Write-Host "Response ---  $response2"
                $($response.ExceptionResponse.StatusCode.value__) | Should -be 400
                Write-Host "Response ---  $($response2.ErrorDetails.message)"


            }

        }

    }

    Describe "User Story 299839: Digital Matrix - Gen AI - Register/Update Model" {

        #Gen AI AZUREOPENAI- Register/Update Model for Existing Provider Instance
        Context "Create Model in AzureOpenAI and Add OpenAI Provider Instance" {
            BeforeAll {
                Write-Host "Create a Dummy Model for AzureOpenAI using OpenAI Provider Instance "

                $requestParams = @{
                    Method = 'POST'
                    Uri    = "/workspace/api/v1/generativeai/model"
                    Body   = @{
                        "modelName"         = $OpenAi_DummymodelName
                        "provider"          = "AzureOpenAI"
                        "providerModelName" = "gpt-35-turbo"
                        "maxTokenCount"     = 10
                        "capabilities"      = @(
                            @{
                                "capabilityKey" = "Chat"
                                "isEnabled"     = $true
                                "endPointUrl"   = "https://test.com"
                            }
                        )
                        "instances"         = @(
                            @{
                                "providerInstanceName" = $OpenAI_providerInstanceName
                                "modelInstanceName"    = "gpt-35-turbo"
                                "priority"             = 1
                            }
                        )
                        "isEnabled"         = $true
                    } | ConvertTo-Json
                }
                $response = $null
                $response = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true
                Write-Host " Model is Created in Azure Open AI   ---  $response"


            }
            It "Should Create a AzureOpenAI model" {
                Write-Host "Model name for the completion is - $($response.modelName) "
                $($response.modelName) | Should -be $OpenAi_DummymodelName


            }
            It "Should Create Chat Completion with New Model $OpenAi_DummymodelName " {
                Write-Host "Verifing Chat Completion with New Model $OpenAi_DummymodelName "
                $requestParams = @{
                    Method = 'POST'
                    Uri    = "/workspace/api/v1/generativeai/chat"
                    Body   = @{
                        "modelName"      = $OpenAi_DummymodelName
                        "engagementCode" = $engagementCode
                        "messages"       = @( @{
                                "role"    = "User"
                                "content" = "Who won the Cricket World Cup in 2011"
                            })
                    } | ConvertTo-Json
                }

                $response = $null
                $response = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true
                Write-Host " Chat Completion with New Model Working ---  $response"

                $response | Should -Not -BeNullOrEmpty
            }

        }
        Context "Validate Mapping of AzureOpenAI Provider Instaces and its AuthConfigKey" {
            BeforeAll {
                Write-Host " Validation on AzureOpenAI Provider Instances with Valid AuthConfigKey"

                $requestParams = @{
                    Method = 'POST'
                    Uri    = "/workspace/api/v1/generativeai/providerinstance"
                    Body   = @{
                        "providerInstanceName" = $ProviderInstances_ForNegativeScenario
                        "providerName"         = "AzureOpenAI"
                        "GeoLocation"          = "GLOBAL"
                        "authConfigurationKey" = $OpenAI_ValidAuthConfigKey
                        "isEnabled"            = $false
                    } | ConvertTo-Json
                }
                $response = @{}
                $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true


            }
            It "should throw Error - Provided provider instance name $ProviderInstances_ForNegativeScenario with AuthConfigKey 'OpenAi:USW:POC:ApiKey' is not found in Azure OpenAI. " {
                Write-Host "Response ---  $($response.ErrorDetails.message)"
                $response.ExceptionResponse.StatusCode.value__ | Should -be 404
                $($response.ErrorDetails.message)  | Should -be "Provided provider instance name '$ProviderInstances_ForNegativeScenario' with AuthKey 'OpenAi:USW:POC:ApiKey' is not found in Azure OpenAI."
            }

        }

    }

    Describe "User Story 302495: Digital Matrix - Gen AI - All Model Consumption should pull from Provider Instance Map - QA Automation" {
        BeforeAll {
            Write-Host "Fetching Provider instances to Disable Existing provider Instance for $OpenAi_DummymodelName"
            $requestParams = @{
                Method = 'GET'
                Uri    = "/workspace/api/v1/generativeai/model?providers=AzureOpenAI"
            }

            $GetModelResponse = @{}
            $GetModelResponse = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true

            $script:ProviderInstanceList = @()

            foreach ($Item in $($GetModelResponse)) {
                $Model = $Item.modelName
                Write-Host "Model Name is $Model"
                if ($Model -eq $OpenAi_DummymodelName) {
                    Write-Host "inside If "
                    foreach ($Item in $Item.instances.providerInstanceName) {
                        $ProviderInstanceList += $Item
                        Write-Host "List of Provider Instaces Available for $Model =   $ProviderInstanceList "
                    }
                    Break
                }
            }
            Write-Host "Provider Instance available from Get Method =  $($ProviderInstanceList)"
        }
        Context "Disabling Provider Instaces for the Model " {
            BeforeAll {
                Write-Host "To Verify $OpenAi_DummymodelName Should not work with disable Provider Instances"

                Write-Host "Disabling Provider Instance"
                foreach ($ProviderInstance in $ProviderInstanceList) {

                    Write-Host "Disabling Provider Instance = $ProviderInstance "

                    $requestParams = @{
                        Method = 'POST'
                        Uri    = "/workspace/api/v1/generativeai/providerinstance"
                        Body   = @{
                            "providerInstanceName" = $($ProviderInstance)
                            "isEnabled"            = $false

                        } | ConvertTo-Json
                    }

                    $response = $null
                    $response = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true

                }
                Write-Host "Wait for 5 min for Cache refresh"
                Start-Sleep -Seconds 300
                foreach ($ProviderInstance in $ProviderInstanceList) {
                    Write-Host "Calling Method to Check Provider Instances State"
                    GetStateProviderInstances $ProviderInstance $false
                }
                Write-Host "Disabled all the provider Instaces"
            }
            It "Test Case 305085: ST_TC_DM_302487: (Postive Scenario)To Verify response of Chat Completion for Model Where its Provider Instances is Disabled." {
                Write-Host "Verifing response of CHAT Completion for Model - $OpenAi_DummymodelName with disable Provider"
                $requestParams = @{
                    Method = 'POST'
                    Uri    = "/workspace/api/v1/generativeai/chat"
                    Body   = @{
                        "modelName"      = $OpenAi_DummymodelName
                        "engagementCode" = $engagementCode
                        "messages"       = @( @{
                                "role"    = "system"
                                "content" = "You are a helpful assistant willing to answer questions about ICC world championship"
                            }, @{
                                "role"    = "User"
                                "content" = "Who won cricket world cup 2011?"  #Mandatory Mention Json Format in Prompt
                            })
                        "parameters"     = @{
                            "temperature"       = 1
                            "frequency_penalty" = 0
                            "presence_penalty"  = 0
                            "max_tokens"        = 10
                        }
                    } | ConvertTo-Json
                }
                $response = @{}
                $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true
                Write-Host "Response Error Message is  ---  $($response.ErrorDetails.message)"
                $response.ExceptionResponse.StatusCode.value__ | Should -be 404
            }
        }
    }

    #To Disable the Provider Instances and Dummy Model
    AfterAll {

        Write-Host "Disabling Open AI Model - $OpenAi_DummymodelName"
        $requestParams = @{
            Method = 'PUT'
            Uri    = "/workspace/api/v1/generativeai/model/$OpenAi_DummymodelName"
            Body   = @{
                "isEnabled" = $false

            } | ConvertTo-Json
        }

        $response = $null
        $response = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true

        Write-Host "Test Case 305086: ST_TC_DM_302487: (Postive Scenario)To Verify response of  Chat Completion for Model Where its Existing Provider Instances is Enable."
        Write-Host "$OpenAI_providerInstanceName Provider Instance needs to  Enable at last"
        $requestParams = @{
            Method = 'POST'
            Uri    = "/workspace/api/v1/generativeai/providerinstance"
            Body   = @{
                "providerInstanceName" = $OpenAI_providerInstanceName
                "isEnabled"            = $true

            } | ConvertTo-Json

        }
        $response = $null
        $response = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true

    }

}