param(

    [Parameter(Mandatory)]
    [ValidateNotNullOrEmpty()]
    $CurrentEnvironmentData

)
    $global:memberUserIdContext = ((New-Guid).Guid.ToString().Substring(0, 8)) + (Get-Date -Format "yyyyMMdd-HHmmss")
    $global:userName = "test-pester-$($memberUserIdContext)"
    $global:userPrincipalName = "$($userName)@$($CurrentEnvironmentData.Domain)"
Describe "Auth" -Tag "USER" {
    #Testcases for USER Contains the public endpoints related to Application Users.

    BeforeAll {
        #Create user in ad and added in Auth
        Write-Host "Create User.... for All User related Testcases"

        # Create a user that will be added to the group

        $memberUserResult = Create-User $CurrentEnvironmentData $memberUserIdContext

        Write-Host "The Response of.... $($memberUserResult) "
        $memberUserId = $memberUserResult.taskOutput.userId

        FailEarly 'Validate initial user created.' {
            $memberUserResult.status | Should -Be "Completed"
        }

        # Create a User in Auth with the same ADD user
        Write-Host "****Create user in Auth******"

        $requestParams = @{
            Method = 'POST'
            Uri    = "/auth/api/v1/user"
            Body   = @{
                "userId" = "$($memberUserId)"
            } | ConvertTo-Json
        }
        #$AuthUserresponse = $null
        $AuthUserresponse = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true

        Write-Host "RESPONSE IS $($AuthUserresponse)"
    }

    It "Should not return null" {
        $AuthUserresponse | Should -BeNull

    }
    Context "DM_Auth_API_23| Verify Search User by Text" {

        BeforeAll {

            Write-Host "USER NAME IS --$($userName) "
            $requestParams = @{
                Method = 'GET'
                Uri    = "/auth/api/v1/user?searchText=$($userName)&pageSize=1000&pageIndex=0"
            }

            #$response = @{}
            $response = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true
            Write-Host "RESPONSE IS $($response[0])"
        }

        It "Should not return null" {
            $response | Should -not -BeNullOrEmpty
        }
        It "Should return exact Role name Match - " {

            $response.userId | should -contain $($memberUserId)

        }
    }
    Context "DM_Auth_API_25| Verify Search User by specified principal name." {

        BeforeAll {

            Write-Host "USER Principal NAME IS --$($userPrincipalName) "
            $requestParams = @{
                Method = 'GET'
                Uri    = "/auth/api/v1/user/principalname/$($userPrincipalName)"
            }

            #$response = @{}
            $response = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true
            Write-Host "RESPONSE IS $($response[0])"
        }

        It "Should not return null" {
            $response | Should -not -BeNullOrEmpty
        }
        It "Should return exact Role name Match - " {

            $response.userId | should -contain $($memberUserId)

        }
    }
    Context "DM_Auth_API_26| Verify Search User by Username." {

        BeforeAll {

            Write-Host "USER NAME IS --$($userName) "
            $requestParams = @{
                Method = 'GET'
                Uri    = "/auth/api/v1/user/principalname/$($userName)"
            }

            $response = @{}
            $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true
            Write-Host "RESPONSE IS $($response)"
        }

        It "Should return 404 NOT found" {
            $response.ExceptionResponse.StatusCode.value__ | should -be 404
        }
        It "Should return Message - " {

            $response.ErrorDetails.Message | should -be "User with specified account name or email was not found: $($userName)"
        }
    }

    AfterAll {

        #delete User from Auth
        $requestParams = @{
            Method = 'DELETE'
            Uri    = "/auth/api/v1/user/$($memberUserId)"
        }

        #$response = @{}
        $response = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true $true 5

        Write-Host " Auth User Deleted $($memberUserId) ..."
        Write-Host "Delete user from AD"
        Delete-User $CurrentEnvironmentData $memberUserId
    }

}




