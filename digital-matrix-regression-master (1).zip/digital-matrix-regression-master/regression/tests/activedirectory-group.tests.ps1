﻿param(

  [Parameter(Mandatory)]
  [ValidateNotNullOrEmpty()]
  $CurrentEnvironmentData

)
$SkipEnvironmentList = @('CAT', 'UAT', 'Production')
Describe "AAD" -Tag "Group" -Skip:($SkipEnvironmentList.Contains($CurrentEnvironmentData.Environment)) {
  Context "GET /api/v1/group" {
    Context "DM_AD_API_05_01 | Search By Empty Text" {
      BeforeAll {
        $requestParams = @{
          Method = 'GET'
          Uri    = "/ad/api/v1/group"
        }

        $response = @{}
        #$response = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true
        $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true
      }

      It "Should return 400 Bad Request" {
        $response.ExceptionResponse.StatusCode.value__ | Should -be 400
      }
    }

    Context "DM_AD_API_05_02 | Search By Numbers" {
      BeforeAll {
        $requestParams = @{
          Method = 'GET'
          Uri    = "/ad/api/v1/group?searchText=9710502023211"
        }

        $response = @{}
        $response = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true

      }

      It "Should not return null" {
        $response | Should -BeNullOrEmpty
      }

      It "Should return at least one record" {
        $response.Count | Should -BeLessOrEqual 0
      }

      AfterAll {

      }
    }

    Context "DM_AD_API_05_03 | Search By Text that exists" {
      BeforeAll {
        $requestParams = @{
          Method = 'GET'
          Uri    = "/ad/api/v1/group?searchText=DM Regression Testing"
        }

        $response = @{}
        $response = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true
      }

      It "Should not return null" {
        $response | Should -not -BeNullOrEmpty
      }

      AfterAll {}
    }

    Context "DM_AD_API_05_04 | Search By Special Characters" {
      BeforeAll {
        $requestParams = @{
          Method = 'GET'
          Uri    = "/ad/api/v1/group?searchText=QA%40%23%27"
        }

        $response = @{}
        #$response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true
        $response = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true
      }

      It "Should return 200 Empty" {
        #$response.StatusCode.value__ |should -be 200
        #$response.statusCode |should -be 200
      }

      It "Should return Empty" {
        $response | Should -BeNullOrEmpty
      }

      AfterAll {}


    }
    # Added on 13/01/2022

    Context "DM_AD_API_05_05 | Search by only 2 character" {
      BeforeAll {
        $requestParams = @{
          Method = 'GET'
          Uri    = "/ad/api/v1/group?searchText=QA"
        }

        $response = @{}
        $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true
      }
      It "Should return 400" {
        $response.ExceptionResponse.StatusCode.value__ | should -be 400
      }

      It "Sould return Message" {
        $response.ErrorDetails.Message | Should -contain "Please provide at least 3 characters to search"
      }
      AfterAll {}



    }
    Context "DM_AD_API_07_01 |/api/v1/group/{displayName}|Search Group by Invalid Display name" {
      BeforeAll {

        $displayName = "displayname;['."
        $requestParams = @{
          Method = 'GET'
          Uri    = "/ad/api/v1/group/$([uri]::EscapeDataString($displayName))"
        }

        $response = @{}
        $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true
      }
      It "Should return 404" {
        $response.ExceptionResponse.StatusCode.value__ | should -be 404
      }

      It "Should return Message" {
        # $response.ErrorDetails.Message | Should -be "Group with display name was not found: $($displayName)"
        $response | Should -not -BeNullOrEmpty
      }
      AfterAll {}


    }
    Context "DM_AD_API_07_02|/api/v1/group/{displayName}|Search Group by AlphaNumeric Display name" {
      BeforeAll {

        $displayName = "1234alpha"
        $requestParams = @{
          Method = 'GET'
          Uri    = "/ad/api/v1/group/$([uri]::EscapeDataString($displayName))"
        }

        $response = @{}
        $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true
      }
      It "Should return 404" {
        $response.ExceptionResponse.StatusCode.value__ | should -be 404
      }

      It "Should return Message" {
        $response.ErrorDetails.Message | Should -be "Group with display name was not found: $($displayName)"
      }
      AfterAll {}


    }

    Context "DM_AD_API_07_03 |/api/v1/group/{displayName}|Search Group by Numeric Display name" {
      BeforeAll {
        #Search by Numeric Values
        $displayName = "123456532"
        $requestParams = @{
          Method = 'GET'
          Uri    = "/ad/api/v1/group/$([uri]::EscapeDataString($displayName))"
        }

        $response = @{}
        $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true
      }
      It "Should return 404" {
        $response.ExceptionResponse.StatusCode.value__ | should -be 404
      }

      It "Should return Message" {
        $response.ErrorDetails.Message | Should -be "Group with display name was not found: $($displayName)"
      }
      AfterAll {}


    }


    Context "DM_AD_API_07_04 |/api/v1/group/{displayName}|Search Group by Valid Display name" {
      BeforeAll {
        #Search by Numeric Values
        $displayName = "Test"
        $requestParams = @{
          Method = 'GET'
          Uri    = "/ad/api/v1/group/$([uri]::EscapeDataString($displayName))"
        }

        $response = @{}
        $response = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true
      }
      It "Should return 200" {
        $response | Should -not -BeNullOrEmpty
      }

      It "Should return Valid response" {
        $response.displayName | should -be $($displayName)
      }
      AfterAll {}


    }


    Context "DM_AD_API_07_06|/api​/v1​/group​/groupid​/{groupId}|Search Group by Invalid GroupId" {
      BeforeAll {

        #Search by Valid GroupID Value
        $groupId = "71080c4f-137b-42b7-a9cd-ef0331e36d80"

        $requestParams = @{
          Method = 'GET'
          Uri    = "/ad/api/v1/group/groupid/$([uri]::EscapeDataString($groupId))"

        }

        $response = @{}
        $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true
      }
      It "Should return 404" {
        $response.ExceptionResponse.StatusCode.value__ | should -be 404
      }

      It "Should return response" {
        $response.ErrorDetails.Message | should -be "Invalid Group Id '$($groupId)'."
      }
      AfterAll {}

    }


    Context "POST /api/v1/group" {
      BeforeAll {

        $service = "ad"
        $contextId = (New-Guid).Guid
        $groupName = "Pester$($contextId)"
        $description = "This group was created as part of a test run with context id $($contextId).  If you're reading this - it's okay to delete."

        Write-Host "BeforeAll POST /api/v1/group - context id $($contextId)"

        Write-Host "Creating group..."
        $requestParams = @{
          Method = 'POST'
          Uri    = "/$($service)/api/v1/group"
          Body   = @{
            "displayName"  = "$($groupName)"
            "description"  = "$($description)"
            "mailNickname" = "$($groupName)"
          } | ConvertTo-Json
        }

        $createResponse = $null
        $createResponse = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true

        $createTaskResult = $null
        $createTaskResult = Get-BackgroundStatus $CurrentEnvironmentData $createResponse.taskId "$($service)"

        FailEarly "Validate group '$($groupName)' created." {
          $createTaskResult.status | Should -Be "Completed"
        }

        #Getting details with group Id
        Write-Host "Retrieving response with group Id...."
        $requestParams = @{
          Method = 'GET'
          Uri    = "/ad/api/v1/group/groupid/$($createTaskResult.taskOutput.groupId)"
        }

        $groupIdresponse = @{}
        $groupIdresponse = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true

        #Getting details with group name
        Write-Host "Retrieving group..."
        $requestParams = @{
          Method = 'GET'
          Uri    = "/$($service)/api/v1/group/Pester$($contextId)"
        }

        $retrieveResponse = $null
        $retrieveResponse = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true $true 5
      }

      It "Should return valid response with specified groupID" {
        $groupIdresponse.id | Should -be $($createTaskResult.taskOutput.groupId)
      }

      It "should return a response that is not null or empty" {
        $createResponse | Should -Not -BeNullOrEmpty
      }

      It "should return a valid task result that is not null or empty" {
        $createTaskResult | Should -Not -BeNullOrEmpty
      }

      It "should return a valid activity type" {
        $createTaskResult.taskOutput.activityType | Should -Be "CreateGroup"
      }

      It "should return a group id that is not null or empty" {
        $createTaskResult.taskOutput.groupId | Should -Not -BeNullOrEmpty
      }

      It "should return a group with matching description" {
        $retrieveResponse[0].description | Should -Be $description
      }

      It "should return a group with matching mail nickname" {
        $retrieveResponse[0].mailNickname | Should -Be $groupName
      }

      It "should return the same instance of the group object" {
        $retrieveResponse[0].id | Should -Be $createTaskResult.taskOutput.groupId
      }

      AfterAll {

        Write-Host "AfterAll POST /api/v1/group"

        $requestParams = @{
          Method = 'DELETE'
          Uri    = "/$($service)/api/v1/group/$($createTaskResult.taskOutput.groupId)"
        }

        $response = $null
        $response = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true

        $taskResult = $null
        $taskResult = Get-BackgroundStatus $CurrentEnvironmentData $response.taskId "$($service)"

      }

    }
  }
  Context "User Story 303194: Support pagination for AD Group Search endpoint" {
    Context "Verify pagination for AD Group Search endpoint where pageSize= 5 " {
      BeforeAll {
        $requestParams = @{
          Method = 'GET'
          Uri    = "/ad/api/v1/group/search?pageSize=5"
        }

        $response = @{}
        $response = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true
        $groups = $($response.groups)
      }

      It "Should show only 5 results  for get group " {
        $($groups.Count) | Should -Be 5
      }
    }

    Context "Verify pagination for AD Group Search endpoint with Blank parameters " {
      BeforeAll {
        $requestParams = @{
          Method = 'GET'
          Uri    = "/ad/api/v1/group/search"
        }

        $response = @{}
        $response = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true
      }

      It "Should show only 5 results  for get group " {
        $response | Should -not -BeNullOrEmpty
      }
    }

    Context "Verify Search for AD Group Search endpoint with Invalid SkipTokens " {
      BeforeAll {
        $requestParams = @{
          Method = 'GET'
          Uri    = "/ad/api/v1/group/search?skipToken=InvalidSkipToken"
        }

        $response = @{}
        $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true
      }

      It "Should throw an Error for invalid Skiptoken" {
        $response.ExceptionResponse.StatusCode.value__ | Should -be 400
      }
    }
    Context "Verify Search for AD Group Search endpoint for valid SearchText String " {
      BeforeAll {
        $requestParams = @{
          Method = 'GET'
          Uri    = "/ad/api/v1/group?searchText=DM Regression Testing"
        }

        $response = @{}
        $response = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true
      }

      It "Should not return null" {
        $response | Should -not -BeNullOrEmpty
      }


    }
  }
}

