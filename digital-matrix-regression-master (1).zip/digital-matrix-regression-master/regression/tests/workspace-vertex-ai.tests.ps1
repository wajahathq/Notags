# param(

#     [Parameter(Mandatory)]
#     [ValidateNotNullOrEmpty()]
#     $CurrentEnvironmentData

# )


# Describe "Workspace API - vertex AI" {

#     Context "TC_263035 Create a chat prediction" {
#         BeforeAll {
#             #With all mandatory fields
#             $requestParams = @{
#                 Method = 'POST'
#                 Uri    = "/workspace/api/v1/ai/vertex/chat/prediction"
#                 Body   = @{
#                     "modelName"      = "chat-bison@001"
#                     "engagementCode" = "803000012512"
#                     "messages"       = @( @{
#                             "role"    = 1
#                             "content" = "Talk to me like an spacex contact support"
#                         }, @{
#                             "role"    = 2
#                             "content" = "Till now how many launches are done by spacex using falcon9"
#                         })
#                 } | ConvertTo-Json
#             }
#             $chatPredictionResponse1 = @{}
#             $chatPredictionResponse1 = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true

#             #With all available fields
#             $requestParams = @{
#                 Method = 'POST'
#                 Uri    = "/workspace/api/v1/ai/vertex/chat/prediction"
#                 Body   = @{
#                     "modelName"      = "chat-bison@001"
#                     "engagementCode" = "803000012512"
#                     "messages"       = @( @{
#                             "role"    = 1
#                             "content" = "Talk to me like an spacex contact support"
#                         }, @{
#                             "role"    = 2
#                             "content" = "Till now how many launches are done by spacex using falcon9"
#                         })
#                     "parameters"     = @{
#                         "temperature"     = Get-Random -Minimum 0 -Maximum 1
#                         "maxOutputTokens" = Get-Random -Minimum 100 -Maximum 1000
#                         "topP"            = Get-Random -Minimum 0 -Maximum 100
#                         "topK"            = Get-Random -Minimum 0 -Maximum 40
#                     }
#                 } | ConvertTo-Json
#             }
#             $chatPredictionResponse2 = @{}
#             $chatPredictionResponse2 = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true

#             #with maxtoken parameter only
#             $requestParams = @{
#                 Method = 'POST'
#                 Uri    = "/workspace/api/v1/ai/vertex/chat/prediction"
#                 Body   = @{
#                     "modelName"      = "chat-bison@001"
#                     "engagementCode" = "803000012512"
#                     "messages"       = @( @{
#                             "role"    = 1
#                             "content" = "Talk to me like an spacex contact support"
#                         }, @{
#                             "role"    = 2
#                             "content" = "Till now how many launches are done by spacex using falcon9"
#                         })
#                     "parameters"     = @{
#                         "maxOutputTokens" = Get-Random -Minimum 100 -Maximum 1000
#                     }
#                 } | ConvertTo-Json
#             }
#             $chatPredictionResponse3 = @{}
#             $chatPredictionResponse3 = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true

#         }

#         It "Should not be null for all mandatory fields" {
#             $chatPredictionResponse1 | Should -Not -BeNullOrEmpty
#         }

#         It "Should not be null for all available fields" {
#             $chatPredictionResponse2 | Should -Not -BeNullOrEmpty
#         }

#         It "Should not be null for parameter as maxtoken" {
#             $chatPredictionResponse3 | Should -Not -BeNullOrEmpty
#         }
#     }

#     Context "TC_263036 Create a chat prediction - Negative TC" {
#         Context "For Invalid model name" {
#             BeforeAll {
#                 $requestParams = @{
#                     Method = 'POST'
#                     Uri    = "/workspace/api/v1/ai/vertex/chat/prediction"
#                     Body   = @{
#                         "modelName"      = "text-ada-001"
#                         "engagementCode" = "803000012512"
#                         "messages"       = @( @{
#                                 "role"    = 1
#                                 "content" = "Talk to me like an spacex contact support"
#                             }, @{
#                                 "role"    = 2
#                                 "content" = "Till now how many launches are done by spacex using falcon9"
#                             })
#                     } | ConvertTo-Json
#                 }
#                 $response = @{}
#                 $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true
#             }

#             It "Should return 404 error for invalid model name" {
#                 $response.ExceptionResponse.StatusCode.value__ | Should -be 404
#             }

#         }

#         Context "For invalid engagement code" {
#             BeforeAll {
#                 $requestParams = @{
#                     Method = 'POST'
#                     Uri    = "/workspace/api/v1/ai/vertex/chat/prediction"
#                     Body   = @{
#                         "modelName"      = "chat-bison@001"
#                         "engagementCode" = "454353535"
#                         "messages"       = @( @{
#                                 "role"    = 1
#                                 "content" = "Talk to me like an spacex contact support"
#                             }, @{
#                                 "role"    = 2
#                                 "content" = "Till now how many launches are done by spacex using falcon9"
#                             })
#                     } | ConvertTo-Json
#                 }
#                 $response = @{}
#                 $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true
#             }

#             It "Should return 404 error for invalid engagement code" {
#                 $response.ExceptionResponse.StatusCode.value__ | Should -be 404
#             }
#             It "Should return user friendly message for invalid engagement code" {
#                 $response.ErrorDetails.Message | should -be "Engagement with code '454353535' not found"
#             }
#         }

#         Context "For missing mandatory field" {
#             BeforeAll {
#                 $requestParams = @{
#                     Method = 'POST'
#                     Uri    = "/workspace/api/v1/ai/vertex/chat/prediction"
#                     Body   = @{
#                         "modelName"      = "chat-bison@001"
#                         "engagementCode" = "803000012512"
#                     } | ConvertTo-Json
#                 }
#                 $response = @{}
#                 $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true
#             }

#             It "Should return 400 error for missing mandatory field" {
#                 $response.ExceptionResponse.StatusCode.value__ | Should -be 400
#             }
#         }

#         Context "For exceeded value of maxOutputTokens" {
#             BeforeAll {
#                 $requestParams = @{
#                     Method = 'POST'
#                     Uri    = "/workspace/api/v1/ai/vertex/chat/prediction"
#                     Body   = @{
#                         "modelName"      = "chat-bison@001"
#                         "engagementCode" = "803000012512"
#                         "messages"       = @( @{
#                                 "role"    = 1
#                                 "content" = "Talk to me like an spacex contact support"
#                             }, @{
#                                 "role"    = 2
#                                 "content" = "Till now how many launches are done by spacex using falcon9"
#                             })
#                         "parameters"     = @{
#                             "maxOutputTokens" = 9999999999999999999999999999999
#                         }
#                     } | ConvertTo-Json
#                 }
#                 $response = @{}
#                 $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true
#             }

#             It "Should return 400 error for exceeded value of maxOutputTokens" {
#                 $response.ExceptionResponse.StatusCode.value__ | Should -be 400
#             }
#             It "Should return user friendly message for exceeded value of maxOutputTokens" {
#                 $response.ErrorDetails.errors.request | should -eq "The request field is required."
#             }
#         }

#         Context "For exceeded value of temperature" {
#             BeforeAll {
#                 $requestParams = @{
#                     Method = 'POST'
#                     Uri    = "/workspace/api/v1/ai/vertex/chat/prediction"
#                     Body   = @{
#                         "modelName"      = "chat-bison@001"
#                         "engagementCode" = "803000012512"
#                         "messages"       = @( @{
#                                 "role"    = 1
#                                 "content" = "Talk to me like an spacex contact support"
#                             }, @{
#                                 "role"    = 2
#                                 "content" = "Till now how many launches are done by spacex using falcon9"
#                             })
#                         "parameters"     = @{
#                             "temperature" = 10
#                         }
#                     } | ConvertTo-Json
#                 }
#                 $response = @{}
#                 $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true
#             }

#             It "Should return 400 error for exceeded value of temperature" {
#                 $response.ExceptionResponse.StatusCode.value__ | Should -be 400
#             }
#         }

#         Context "For exceeded value of topP" {
#             BeforeAll {
#                 $requestParams = @{
#                     Method = 'POST'
#                     Uri    = "/workspace/api/v1/ai/vertex/chat/prediction"
#                     Body   = @{
#                         "modelName"      = "chat-bison@001"
#                         "engagementCode" = "803000012512"
#                         "messages"       = @( @{
#                                 "role"    = 1
#                                 "content" = "Talk to me like an spacex contact support"
#                             }, @{
#                                 "role"    = 2
#                                 "content" = "Till now how many launches are done by spacex using falcon9"
#                             })
#                         "parameters"     = @{
#                             "topP" = 999999999999999999999999999999999999
#                         }
#                     } | ConvertTo-Json
#                 }
#                 $response = @{}
#                 $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true
#             }

#             It "Should return 400 error for exceeded value of topP" {
#                 $response.ExceptionResponse.StatusCode.value__ | Should -be 400
#             }
#         }

#         Context "For exceeded value of topK" {
#             BeforeAll {
#                 $requestParams = @{
#                     Method = 'POST'
#                     Uri    = "/workspace/api/v1/ai/vertex/chat/prediction"
#                     Body   = @{
#                         "modelName"      = "chat-bison@001"
#                         "engagementCode" = "803000012512"
#                         "messages"       = @( @{
#                                 "role"    = 1
#                                 "content" = "Talk to me like an spacex contact support"
#                             }, @{
#                                 "role"    = 2
#                                 "content" = "Till now how many launches are done by spacex using falcon9"
#                             })
#                         "parameters"     = @{
#                             "topK" = 999999999999999999999999999999999999
#                         }
#                     } | ConvertTo-Json
#                 }
#                 $response = @{}
#                 $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true
#             }

#             It "Should return 400 error for exceeded value of topK" {
#                 $response.ExceptionResponse.StatusCode.value__ | Should -be 400
#             }
#         }
#     }

# }