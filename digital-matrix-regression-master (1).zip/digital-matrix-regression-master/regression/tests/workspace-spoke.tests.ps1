param(

  [Parameter(Mandatory)]
  [ValidateNotNullOrEmpty()]
  $CurrentEnvironmentData

)

$Script:SpokeContextId = (New-Guid).Guid
$Script:SpokeId = "$($SpokeContextId)"

Describe "Registration of new spoke" {

  Context "Getting the spoke details" {
    Write-Host "Get the list of spokes"
    $requestParams = @{
      Method = 'GET'
      Uri    = "/workspace/api/v1/spoke"
    }
  
    $SpokeListResponse = @{}
    $SpokeListResponse = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true 
    Write-Host "THE LIST COUNT IS - $($SpokeListResponse.count)"

    $SubscriptionId = $SpokeListResponse[0].spokeSubscriptionId
    $spokeListCount = $SpokeListResponse.count
    Write-Host "The subscription Id is - $($SubscriptionId)"

    if ($spokeListCount -gt 0) {

      $requestParams = @{
        Method = 'GET'
        Uri    = "/workspace/api/v1/spoke/$($SubscriptionId)"
      }
  
      $Spokeresponse = @{}
      $Spokeresponse = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true  

      It "The response body should contain valid subscriptionId" {
        $($Spokeresponse.spokeSubscriptionId) | Should -eq $($SubscriptionId)
      } 

    } 
    else {
      Write-Host "There is no data for Spoke"
    }

  }
  
  Context "DM_Workspace_API_113_57 | Creation of Spoke with duplicate data (Negative TC)" {
    BeforeAll {
      Write-Host "creating spoke with duplicate data"
      $requestParams = @{
        Method = 'POST'
        Uri    = "/workspace/api/v1/spoke"
        Body   = @{
          "spokeSubscriptionId" = "$($Spokeresponse.spokeSubscriptionId)"
          "spokePriorityValue"  = $($Spokeresponse.spokePriorityValue)
          "status"              = "$($Spokeresponse.status)"
        } | ConvertTo-Json 
    
      }

      $response = @{}
      $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true   

    }
       
    It "Should return 400 bad request for duplicate data" {
      $response.ExceptionResponse.StatusCode.value__ | Should -be 400
    }
     
  }

  Context "DM_Workspace_API_113_54 | Creation of Spoke with new subscriptionId with status as active (Negative TC)" {
    BeforeAll {
      Write-Host "creating spoke with new subscriptionId with status as active"
      $requestParams = @{
        Method = 'POST'
        Uri    = "/workspace/api/v1/spoke"
        Body   = @{
          "spokeSubscriptionId" = "$($SpokeId)"
          "spokePriorityValue"  = 2
          "status"              = "Active"
        } | ConvertTo-Json 
      }
    
      $response = @{}
      $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true
    }
      
    It "Should return 404 bad request for new subscriptionId with status as active" {
      $response.ExceptionResponse.StatusCode.value__ | Should -be 404
    }
  
    It "Should return proper error response for new subscriptionId with status as active" {
      $response.ErrorDetails.message | Should -eq "SubscriptionId not found: $($SpokeId)."  
    }  
  }
  
  Context "DM_Workspace_API_113_55 | Creation of Spoke with new subscriptionId with status as Deleted (Negative TC)" {
    BeforeAll {
      Write-Host "creating spoke with new subscriptionId with status as Deleted"
      $requestParams = @{
        Method = 'POST'
        Uri    = "/workspace/api/v1/spoke"
        Body   = @{
          "spokeSubscriptionId" = "$($SpokeId)"
          "spokePriorityValue"  = 2
          "status"              = "Deleted"
    
        } | ConvertTo-Json 
    
      }
    
      $response = @{}
      $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true
    }
      
    It "Should return 404 bad request for new subscriptionId with status as Deleted" {
      $response.ExceptionResponse.StatusCode.value__ | Should -be 404
    }
  
    It "Should return proper error response for new subscriptionId with status as Deleted" {
      $response.ErrorDetails.message | Should -eq "SubscriptionId not found: $($SpokeId)."  
    }        
  }
  
  Context "DM_Workspace_API_113_56 | Creation of Spoke with new subscriptionId with status as Unknown (Negative TC)" {
    BeforeAll {
      Write-Host "creating spoke with new subscriptionId with status as Unknown"
      $requestParams = @{
        Method = 'POST'
        Uri    = "/workspace/api/v1/spoke"
        Body   = @{
          "spokeSubscriptionId" = "$($SpokeId)"
          "spokePriorityValue"  = 2
          "status"              = "Unknown"
    
        } | ConvertTo-Json 
    
      }
    
      $response = @{}
      $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true
    }
      
    It "Should return 404 bad request for new subscriptionId with status as Unknown" {
      $response.ExceptionResponse.StatusCode.value__ | Should -be 404
    }
  
    It "Should return proper error response for new subscriptionId with status as Unknown" {
      $response.ErrorDetails.message | Should -eq "SubscriptionId not found: $($SpokeId)."  
    }        
  }
  
  Context "DM_Workspace_API_113_58 | Creation of Spoke with different status (Negative TC)" {
    BeforeAll {
      Write-Host "creating spoke with different status"
      $requestParams = @{
        Method = 'POST'
        Uri    = "/workspace/api/v1/spoke"
        Body   = @{
          "spokeSubscriptionId" = "$($SubscriptionId)"
          "spokePriorityValue"  = 2
          "status"              = "Deallocate"
    
        } | ConvertTo-Json 
      }
    
      $response = @{}
      $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true
    }
        
    It "Should return 400 bad request for different status" {
      $response.ExceptionResponse.StatusCode.value__ | Should -be 400
    }
  
    It "Should return proper error response for different status" {
      $response.ErrorDetails.errors.spokePriority | Should -eq "The spokePriority field is required."  
    }  
  }
    
}