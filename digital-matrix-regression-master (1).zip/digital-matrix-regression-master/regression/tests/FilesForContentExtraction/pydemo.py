print(my_data["name"])    # Output: John
print(my_data["age"])     # Output: 30
print(my_data["city"])    # Output: New York
print(my_data["country"]) # Output: USA
