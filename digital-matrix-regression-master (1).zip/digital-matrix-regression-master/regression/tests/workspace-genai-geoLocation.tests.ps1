param(

    [Parameter(Mandatory)]
    [ValidateNotNullOrEmpty()]
    $CurrentEnvironmentData

)

$script:engagementCode = "803000012512"
$SkipEnvironmentList = @('CAT' , 'UAT', 'Production', 'QA')

BeforeDiscovery {
    Write-Host "Fetching GEOLOCATION Feature state"

    $requestParams = @{
        Method = 'GET'
        Uri    = "/workspace/api/v1/feature/Workspace | GenerativeAI | EnableUserGeoLocation"

    }

    $response = $null
    $response = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true
    Write-Host "Response from get feature $response"
    $global:SkipGenAIFeature = @('ItsEnable')
    if ($response -contains $true) {
        $global:SkipGenAIFeature = @('ItsEnable')
        Write-Host "GeoLocation Flag is Enable in $($CurrentEnvironmentData.Environment) Proceeding with Gen AI Geolocation Testcases"
    }
    else {
        $global:SkipGenAIFeature = @('ItsDisable')
        Write-Host "GeoLocation Flag is Disable in $($CurrentEnvironmentData.Environment) only running Testcase for 501 Not Implemented"
    }


}
Describe "User Story 304554: DM - Endpoints to grant/revoke/list Regions/GPT instances for a given DM Consumer" -Skip:($SkipEnvironmentList.Contains($CurrentEnvironmentData.Environment) -or $SkipGenAIFeature.Contains("ItsDisable")) {
    BeforeAll {
        Write-Host "Fetching UserId from AD"
        $requestParams = @{
            Method = 'GET'
            Uri    = "/auth/api/v1/user/me"
        }

        $ResponseUserMe = @{}
        $ResponseUserMe = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true
        $script:DMOperatorID = $($ResponseUserMe.userId)

        Write-Host "RegressionSPN has Role as = DM Operator -  $DMOperatorID "

        $script:UserID = $($CurrentEnvironmentData.SAUserId) #"604c8764-eb1e-4f64-ad89-f50646cdf4c3" #SA account dmdevreg-svc-devops@kpmgusadvspectrum.onmicrosoft.com
        Write-Host "SA Account has Role User --- $UserID"

    }

    Describe "Generative AI Testcases - To Verify DM Operator can access Geolocation apis if EnableUserGeoLocation flag is Enabled" {

        Context "Verify that DM operator is able to delete all Geolocations assigned to User" {
            BeforeAll {
                Write-Host "Providing only UserID in Delete usergeolocation API should delete all the associated geolocation"
                $requestParams = @{
                    Method = 'DELETE'
                    Uri    = "/workspace/api/v1/generativeai/usergeolocation"
                    Body   = @{
                        "userId" = $UserID
                    } | ConvertTo-Json
                }

                $Deleteresponse = $null
                $Deleteresponse = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true


                Write-Host "Waiting 300 Sec to Cache refresh"
                Start-Sleep -Seconds 300
            }
            It "Test Case 312446: ST_TC_DM_304554: (Positive TC) Verify that DM operator is able to delete all Geolocations assigned by providing only User Id in Delete usergeolocation Method." {
                Write-Host "DM Operator is able to delete all geolocations of a User"
                $Deleteresponse | Should -BeNullOrEmpty

                Write-Host "To verify the geolocations assigned are deleted in GETusergeolocationAPI as a DM Operator"
                $requestParams = @{
                    Method = 'GET'
                    Uri    = "/workspace/api/v1/generativeai/usergeolocation/$($UserID)"
                }
                $response = @{}
                $response = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true
                Write-Host "Response ---$response"
                $response | Should -BeNullOrEmpty
            }
            It "Test Case 311888: ST_TC_DM_296654: (Postive TC) To Verify None of the Models are Accessible if User has no access to any geolocation and EnableUserGeoLocation = True" {
                Write-Host "Verify Model GPT 4 should throw Error Message  "
                $SAenvData = GetSAEnvironmentData $CurrentEnvironmentData
                $Model = "GPT 4"
                $requestParams = @{
                    Method = 'POST'
                    Uri    = "/workspace/api/v1/generativeai/chat"
                    Body   = @{
                        "modelName"      = $Model
                        "engagementCode" = $engagementCode
                        "messages"       = @( @{
                                "role"    = "User"
                                "content" = "Who won the Cricket World Cup in 1983"
                            }, @{
                                "role"    = "Assistant"
                                "content" = "India won WC 1983 by defeating defending champions (team I performed asked for originally) West Indies."
                            }, @{
                                "role"    = "User"
                                "content" = "Who won was the MAN of the MATCH"
                            })
                        "parameters"     = @{

                            "max_tokens" = 1

                        }
                    } | ConvertTo-Json
                }
                $response = @{}
                $response = Invoke-RestMethodAuthWrapperExceptionHandler $SAenvData $requestParams $true

                Write-Host "Response ---  $($response.ErrorDetails.message)"
                $response.ExceptionResponse.StatusCode.value__ | Should -be 404
                $($response.ErrorDetails.message) | Should -Contain "There are no available provider instances for the model 'GPT 4' in any of the geolocations which user '$($UserID)' can access: ''."

            }

        }
        Context "To Verify DM Operator can access POST geolocation api when EnableUserGeoLocation flag is Enabled" {
            BeforeAll {
                Write-Host "POST Geolocation API to add 1 geolocation to a User as a DMOperator "
                $requestParams = @{
                    Method = 'POST'
                    Uri    = "/workspace/api/v1/generativeai/usergeolocation"
                    Body   = @{
                        "userId"      = $UserID
                        "geoLocation" = "Americas"
                    } | ConvertTo-Json
                }
                $response = $null
                $response = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true
                Write-Host "  wait for 5 mins for Cache refresh"
                Start-Sleep -Seconds 300
            }
            It "Test Case 312038: ST_TC_DM_304554: (Positive TC) Verify DM operator can assign Geolocation region access to User with EnableUserGeoLocation Flag enabled using Post usergeolocation Method/endpoint." {
                Write-Host "Geolocation should be assigned"
                $response | Should  -BeNullOrEmpty
            }
        }
        Context "To Verify DM Operator can access GET geolocation api when EnableUserGeoLocation flag is Enabled" {
            BeforeAll {
                Write-Host "GET Geolocation API As a DM Operator"

                $requestParams = @{
                    Method = 'GET'
                    Uri    = "/workspace/api/v1/generativeai/usergeolocation/$($UserID)"
                }
                $response = $null
                $response = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true
                Write-Host "Get Geolocation API Response is  ---  $response"
            }
            It "Test Case 312040: ST_TC_DM_304554: (Positive TC) Verify DM operator can retrieve regions that a User can access by providing valid User ID with EnableUserGeoLocation Flag enabled using Get usergeolocation method." {

                $response[0].geoLocation | Should -Contain "Americas"
            }
        }
        Context "To Verify DM Operator can access DELETE geolocation api when EnableUserGeoLocation flag is Enabled" {
            BeforeAll {
                Write-Host "DELETE Geolocation API ---DM Operator"
                $requestParams = @{
                    Method = 'DELETE'
                    Uri    = "/workspace/api/v1/generativeai/usergeolocation"
                    Body   = @{
                        "userId"      = $UserID
                        "geoLocation" = "AMERICAS"
                    } | ConvertTo-Json
                }
                $response = @{}
                $response = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true

            }
            It "Test Case 312039: ST_TC_DM_304554: (Positive TC) Verify DM operator can delete/revoke user's access from a region with EnableUserGeoLocation Flag enabled using Delete usergeolocation Method/endpoint." {
                Write-Host "Deleted All Assinged Geolocation to a User"
                $response | Should -BeNullOrEmpty
            }
        }

        #Testcases As a User - as an Actual Consumer
        Context "To Verify User cannot  fetch UsersGeolocation when EnableUserGeoLocation flag is Enabled" {
            BeforeAll {
                Write-Host "GET Geolocation API as a User"
                $SAenvData = GetSAEnvironmentData $CurrentEnvironmentData
                Write-Host "Current Enviroment data is $SAenvData "
                $requestParams = @{
                    Method = 'GET'
                    Uri    = "/workspace/api/v1/generativeai/usergeolocation/$($UserID)"
                }
                $response = @{}
                $response = Invoke-RestMethodAuthWrapperExceptionHandler  $SAenvData $requestParams $true
                Write-Host "Response ---  $($response.ErrorDetails.message)"
            }
            It "Test Case 312891: ST_TC_DM_304554: (Positive TC) Verify User cannot access Get Geo location APIs when EnableUserGeoLocation flag is enabled." {
                Write-Host "Should return 403 response with proper error message while trying to access GET geoLocation api"
                $response.ExceptionResponse.StatusCode.value__ | Should -be 403
                $response.ErrorDetails.message | Should -be "DM User '$($UserID)' does not have an active account or does not have permission 'generative-ai-usergeolocation.update' (scopes: 'root/drp/generativeai/usergeolocation, root/drp/generativeai/usergeolocation')"
            }
        }
        Context "To Verify User cannot access POST geolocation api when EnableUserGeoLocation flag is Enabled" {
            BeforeAll {

                $SAenvData = GetSAEnvironmentData $CurrentEnvironmentData
                Write-Host "Current Enviroment data is $SAenvData "

                Write-Host "POST Geolocation API --User"
                $requestParams = @{
                    Method = 'POST'
                    Uri    = "/workspace/api/v1/generativeai/usergeolocation"
                    Body   = @{
                        "userId"      = $UserID
                        "geoLocation" = "GLOBAL"
                    } | ConvertTo-Json
                }
                $response = @{}
                $response = Invoke-RestMethodAuthWrapperExceptionHandler $SAenvData $requestParams $true
                Write-Host "Response Error---  $($response.ErrorDetails.message)"
            }
            It "Test Case 312891: ST_TC_DM_304554: (Positive TC) Verify User cannot access POST Geo location APIs when EnableUserGeoLocation flag is enabled." {
                Write-Host "Should return 403 response with proper error message while trying to access POST geoLocation api"
                $response.ErrorDetails.message | Should -be "DM User '$($UserID)' does not have an active account or does not have permission 'generative-ai-usergeolocation.update' (scopes: 'root/drp/generativeai/usergeolocation, root/drp/generativeai/usergeolocation')"
            }
            It "Test Case 312891: ST_TC_DM_304554: (Positive TC) Verify User cannot access POST Geo location APIs when EnableUserGeoLocation flag is enabled." {
                Write-Host "Should return 403 response"
                $response.ExceptionResponse.StatusCode.value__ | Should -be 403

            }
        }
        Context "To Verify User cannot access DELETE geolocation api when EnableUserGeoLocation flag is Enabled" {
            BeforeAll {

                $SAenvData = GetSAEnvironmentData $CurrentEnvironmentData
                Write-Host "Current Enviroment data is $SAenvData "

                Write-Host "DELETE Geolocation API --User"
                $requestParams = @{
                    Method = 'DELETE'
                    Uri    = "/workspace/api/v1/generativeai/usergeolocation"
                    Body   = @{
                        "userId"      = $UserID
                        "geoLocation" = "GLOBAL"
                    } | ConvertTo-Json
                }
                $response = @{}
                $response = Invoke-RestMethodAuthWrapperExceptionHandler $SAenvData $requestParams $true
                Write-Host "Response Error---  $($response.ErrorDetails.message)"
            }
            It "Test Case 312891: ST_TC_DM_304554: (Positive TC) Verify User cannot access DELETE Geo location APIs when EnableUserGeoLocation flag is enabled." {
                Write-Host "Should return 403 response with proper error message while trying to access DELETE geoLocation api"
                $response.ExceptionResponse.StatusCode.value__ | Should -be 403
                $response.ErrorDetails.message | Should -be "DM User '$($UserID)' does not have an active account or does not have permission 'generative-ai-usergeolocation.update' (scopes: 'root/drp/generativeai/usergeolocation, root/drp/generativeai/usergeolocation')"
            }
        }
    }


    # Negative Scenarios ---POST User geoLocation API
    Describe "Generative AI Testcases - To Verify error is thrown in POST usergeolocation Method." {

        Context "Send POST request by providing only UserID in POST UserGeolocation API" {
            BeforeAll {
                Write-Host "Send POST request by providing only UserID"
                $requestParams = @{
                    Method = 'POST'
                    Uri    = "/workspace/api/v1/generativeai/usergeolocation"
                    Body   = @{
                        "userId" = $DMOperatorID
                    } | ConvertTo-Json
                }
                $response = @{}
                $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true
                Write-Host "Response Error---  $($response.ErrorDetails.message)"
            }
            It "Test Case 312758: ST_TC_DM_304554: (Negative TC) Verify error is thrown when only UserID is provided in Post usergeolocation Method." {
                Write-Host "Should return 400 error"
                #$response.ExceptionResponse.StatusCode.value__ | Should -be 400
                $response.ErrorDetails.message | Should -be "Geo Location is required."
            }
        }
        Context "Send POST request by providing only geolocation in POST UserGeolocation API" {
            BeforeAll {
                Write-Host "Send POST request by providing only geolocation"
                $requestParams = @{
                    Method = 'POST'
                    Uri    = "/workspace/api/v1/generativeai/usergeolocation"
                    Body   = @{
                        "geoLocation" = "EMEA"
                    } | ConvertTo-Json
                }
                $response = @{}
                $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true
                Write-Host "Response Error---  $($response.ErrorDetails.message)"
            }
            It "Test Case 312445: ST_TC_DM_304554: (Negative TC) Verify error is thrown when User ID is not provided in Post usergeolocation Method." {
                Write-Host "Should return $($response.ExceptionResponse.StatusCode.value__) error"
                #$response.ExceptionResponse.StatusCode.value__ | Should -be 400
                $response.ErrorDetails.message | Should -be "UserId is required."
            }
        }
        Context "Send POST request by providing UserID as null in POST UserGeolocation API" {
            BeforeAll {
                Write-Host "Send POST request by providing only geolocation"
                $requestParams = @{
                    Method = 'POST'
                    Uri    = "/workspace/api/v1/generativeai/usergeolocation"
                    Body   = @{
                        "userId"      = ""
                        "geoLocation" = "GLOBAL"
                    } | ConvertTo-Json
                }
                $response = @{}
                $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true
                Write-Host "Response Error---  $($response.ErrorDetails.message)"
            }
            It "Test Case 312445: ST_TC_DM_304554: (Negative TC) Verify error is thrown when UserID is null in Post usergeolocation Method." {
                Write-Host "Should return 400 error"
                $response.ExceptionResponse.StatusCode.value__ | Should -be 400
            }
        }
        Context "Send POST request by providing invalid UserID in POST UserGeolocation API" {
            BeforeAll {
                Write-Host "Send POST request by providing invalid UserID"
                $requestParams = @{
                    Method = 'POST'
                    Uri    = "/workspace/api/v1/generativeai/usergeolocation"
                    Body   = @{
                        "userId"      = "87eaa737-0000-0000-0000-000000000000" #invalid GUID
                        "geoLocation" = "EMEA"
                    } | ConvertTo-Json
                }
                $response = @{}
                $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true
                Write-Host "Response Error---  $($response.ErrorDetails.message)"
            }
            It "Test Case 312441: ST_TC_DM_304554: (Negative TC) Verify error is thrown 404" {
                Write-Host "Should return 404 error"
                $response.ExceptionResponse.StatusCode.value__ | Should -be 404

            }
            It "Test Case 312441: ST_TC_DM_304554: (Negative TC) Verify error is thrown Message when providing invalid UserID in Post usergeolocation Method." {
                Write-Host "Should return error  Message for Invalid UserId"

                $response.ErrorDetails.message | Should -be "UserId: 87eaa737-0000-0000-0000-000000000000 was not found."
            }
        }
        Context "Send POST request by providing invalid Geolocation in POST UserGeolocation API" {
            BeforeAll {
                Write-Host "Send POST request by providing invalid Geolocation"
                $requestParams = @{
                    Method = 'POST'
                    Uri    = "/workspace/api/v1/generativeai/usergeolocation"
                    Body   = @{
                        "userId"      = $DMOperatorID
                        "geoLocation" = "Test"
                    } | ConvertTo-Json
                }
                $response = @{}
                $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true
                Write-Host "Response Error---  $($response.ErrorDetails.message)"
            }
            It "Test Case 312441: ST_TC_DM_304554: (Negative TC) Verify error is thrown when providing invalid Geolocation in Post usergeolocation Method." {
                Write-Host "Should return 400 error"
                $response.ExceptionResponse.StatusCode.value__ | Should -be 400
            }
        }
    }
    # Negative Scenarios ---DELETE User geoLocation API
    Describe "Generative AI Testcases - To Verify error is thrown in DELETE usergeolocation Method." {

        Context "Send DELETE request by providing invalid UserID in DELETE UserGeolocation API" {
            BeforeAll {
                Write-Host "Send DELETE request by providing invalid UserID"
                $requestParams = @{
                    Method = 'DELETE'
                    Uri    = "/workspace/api/v1/generativeai/usergeolocation"
                    Body   = @{
                        "userId"      = "87eaa737-0000-0000-0000-000000000000"
                        "geoLocation" = "EMEA"
                    } | ConvertTo-Json
                }
                $response = @{}
                $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true
                Write-Host "Response Error---  $($response.ErrorDetails.message)"
            }
            It "Test Case 312444: ST_TC_DM_304554: (Negative TC) Verify error is thrown when providing invalid User ID in Delete usergeolocation Method." {
                Write-Host "Should return 404 error"
                $response.ExceptionResponse.StatusCode.value__ | Should -be 404

            }
            It "Test Case 312444: ST_TC_DM_304554: (Negative TC) Verify error is thrown when providing invalid User ID in Delete usergeolocation Method." {
                Write-Host "Should return Error Message"

                $response.ErrorDetails.message | Should -be "UserId: 87eaa737-0000-0000-0000-000000000000 was not found."
            }
        }
        Context "Send DELETE request by providing invalid Geolocation in DELETE UserGeolocation API" {
            BeforeAll {
                Write-Host "Send DELETE request by providing invalid Geolocation"
                $requestParams = @{
                    Method = 'POST'
                    Uri    = "/workspace/api/v1/generativeai/usergeolocation"
                    Body   = @{
                        "userId"      = $DMOperatorID
                        "geoLocation" = "TestGeolocation"
                    } | ConvertTo-Json
                }
                $response = @{}
                $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true
                Write-Host "Response Error---  $($response.ErrorDetails.message)"
            }
            It "Test Case 312444: ST_TC_DM_304554: (Negative TC) Verify error is thrown when providing invalid Geolocation region in Delete usergeolocation Method." {
                Write-Host "Should return 400 error"
                $response.ExceptionResponse.StatusCode.value__ | Should -be 400
                #$response.ErrorDetails.$.geoLocation | Should -contains "The input was not valid."
            }
        }
    }

    AfterAll {

        # Write-Host "AfterAll - Assigning all Geolocation to User $UserID "
        # $requestParams = @{
        #     Method = 'POST'
        #     Uri    = "/workspace/api/v1/generativeai/usergeolocation"
        #     Body   = @{
        #         "userId"      = $UserID
        #         "geoLocation" = "GLOBAL"
        #     } | ConvertTo-Json
        # }
        # $response = $null
        # $response = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true

        # $requestParams = @{
        #     Method = 'POST'
        #     Uri    = "/workspace/api/v1/generativeai/usergeolocation"
        #     Body   = @{
        #         "userId"      = $UserID
        #         "geoLocation" = "EMEA"
        #     } | ConvertTo-Json
        # }
        # $response = $null
        # $response = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true

        # $requestParams = @{
        #     Method = 'POST'
        #     Uri    = "/workspace/api/v1/generativeai/usergeolocation"
        #     Body   = @{
        #         "userId"      = $UserID
        #         "geoLocation" = "AMERICAS"
        #     } | ConvertTo-Json
        # }
        # $response = $null
        # $response = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true
        # Write-Host "  wait for 5 mins for Cache refresh"
        # Start-Sleep -Seconds 300
        Write-Host "Assigning all Geolocation to User $UserID"

        $desiredGeoLocations = @('GLOBAL', 'EMEA', 'AMERICAS')

        # Get existing geolocations

        $requestParams = @{
            Method = 'GET'
            Uri    = "/workspace/api/v1/generativeai/usergeolocation/$UserID"
        }

        $response = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true
        $currentGeoLocations = $response | ForEach-Object { $_.geoLocation }

        foreach ($geolocation in $desiredGeoLocations) {
            # If desired geolocation not in current geolocations list, Add it
            if ($geolocation -notin $currentGeoLocations) {
                Write-Host "Adding $geolocation to user $UserID"

                $requestParams = @{
                    Method = 'POST'
                    Uri    = "/workspace/api/v1/generativeai/usergeolocation"
                    Body   = @{
                        "userId"      = $UserID
                        "geoLocation" = $geolocation
                    } | ConvertTo-Json
                }

                $null = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true
            }
        }

        Write-Host "Wait for 5 mins for Cache refresh"
        Start-Sleep -Seconds 300


    }

}


Describe "GEN AI GeoLocation Flag is Disable - Geolocation Endpoints are restricted for DM Operator and User" -Skip:($SkipEnvironmentList.Contains($CurrentEnvironmentData.Environment) -or $SkipGenAIFeature.Contains("ItsEnable")) {
    BeforeAll {
        Write-Host "Fetching UserId from AD"
        $requestParams = @{
            Method = 'GET'
            Uri    = "/auth/api/v1/user/me"
        }

        $ResponseUserMe = @{}
        $ResponseUserMe = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true
        $script:DMOperatorID = $($ResponseUserMe.userId)

        Write-Host "RegressionSPN has Role as = DM Operator -  $DMOperatorID "

        $script:UserID = $($CurrentEnvironmentData.SAUserId) #"604c8764-eb1e-4f64-ad89-f50646cdf4c3" #SA account dmdevreg-svc-devops@kpmgusadvspectrum.onmicrosoft.com
        Write-Host "SA Account has Role User --- $UserID"

    }
    #DM Operator ID
    Context "To Verify DM Operator cannot access GET geolocation api when EnableUserGeoLocation flag is Disabled" {
        BeforeAll {
            Write-Host "GET Geolocation API --- DM Operator"
            $requestParams = @{
                Method = 'GET'
                Uri    = "/workspace/api/v1/generativeai/usergeolocation/$DMOperatorID"
            }
            $response = @{}
            $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true

            Write-Host "Response ---  $response.ToString()"
        }
        It "Test Case 312892: ST_TC_DM_304554: (Positive TC) Verify DM Operator cannot access GET geolocation API when EnableUserGeoLocation flag is disabled." {
            Write-Host "Should return 501 response with proper error message while trying to access GET geoLocation api"
            $response.ExceptionResponse.StatusCode.value__ | Should -be 501

        }
    }
    Context "To Verify DM Operator cannot access POST geolocation api when EnableUserGeoLocation flag is Disabled" {
        BeforeAll {
            Write-Host "POST Geolocation API --DM Operator"
            $requestParams = @{
                Method = 'POST'
                Uri    = "/workspace/api/v1/generativeai/usergeolocation"
                Body   = @{
                    "userId"      = $DMOperatorID
                    "geoLocation" = "GLOBAL"
                } | ConvertTo-Json
            }
            $response = @{}
            $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true
            Write-Host "Response Error---  $($response.ErrorDetails.message)"
        }
        It "Test Case 312892: ST_TC_DM_304554: (Positive TC) Verify DM Operatory cannot access POST geolocation API when EnableUserGeoLocation flag is disabled." {
            Write-Host "Should return 501 response with proper error message while trying to access POST geoLocation api"
            $response.ExceptionResponse.StatusCode.value__ | Should -be 501

        }
    }
    Context "To Verify DM Operator cannot access DELETE geolocation api when EnableUserGeoLocation flag is Disabled" {
        BeforeAll {
            Write-Host "DELETE Geolocation API --DM Operator"
            $requestParams = @{
                Method = 'DELETE'
                Uri    = "/workspace/api/v1/generativeai/usergeolocation"
                Body   = @{
                    "userId"      = $DMOperatorID
                    "geoLocation" = "GLOBAL"
                } | ConvertTo-Json
            }
            $response = @{}
            $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true
            Write-Host "Response Error---  $($response.ErrorDetails.message)"
        }
        It "Test Case 312892: ST_TC_DM_304554: (Positive TC) Verify DM Operator cannot access DELETE geolocation API when EnableUserGeoLocation flag is disabled." {
            Write-Host "Should return 501 response with proper error message while trying to access DELETE geoLocation api"
            $response.ExceptionResponse.StatusCode.value__ | Should -be 501

        }
    }


}

#Automation for this needs to be modify once after Changes on US - User Story 310191: DM Regression - Merging and Stabilising Gen AI Upsert Model and Provider Instances with existing GEN AI Test case
<#Describe "User Story 296654: DM - Routing of GPT requests to right instances of Open API" {
    #This will be Covering end to end Happy flow, when DM operator assign Geolocation to a User,
    #User should able to utlise Right Instance of the ProviderModel...
    #This can be achived by Taking a model to a specific Geolocation and ProviderInstance should belongs the same geo location.

    #As Part of Negative Scenario, User should not allowed to Consume ProviderInstances in diffrent Geolocation



    Context "Happy Flow for Using Model in Americas Geolocation" -Skip:($SkipEnvironmentList.Contains($CurrentEnvironmentData.Environment) -and $SkipGenAIFeature.Contains("ItsDisable")) {
        BeforeAll {
            $Script:OpenAI_providerInstanceName = "oai-usw-dm-poc"
            $script:OpenAI_ValidAuthConfigKey = "OpenAi:USW:POC:ApiKey"
            $script:OpenAi_DummymodelName = "DummyModel_OpenAI$($CurrentEnvironmentData.Environment)$($date)"
            Write-Host "Registering / Updating a POC Provider Instances in AzureOpenAI  - $OpenAI_providerInstanceName"

            $requestParams = @{
                Method = 'POST'
                Uri    = "/workspace/api/v1/generativeai/providerinstance"
                Body   = @{
                    "providerInstanceName" = $OpenAI_providerInstanceName
                    "providerName"         = "AzureOpenAI"
                    "GeoLocation"          = "Americas"
                    "authConfigurationKey" = $OpenAI_ValidAuthConfigKey
                    "isEnabled"            = $true
                } | ConvertTo-Json
            }
            $OpenAiproviderresponse = @{}
            $OpenAiproviderresponse = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true

            Write-Host "Create a Dummy Model for AzureOpenAI using OpenAI Provider Instance"

            $requestParams = @{
                Method = 'POST'
                Uri    = "/workspace/api/v1/generativeai/model"
                Body   = @{
                    "modelName"         = $OpenAi_DummymodelName
                    #"provider"          = "AzureOpenAI"
                    "providerModelName" = "gpt-35-turbo"
                    "maxTokenCount"     = 10
                    "capabilities"      = @(
                        @{
                            "capabilityKey" = "Chat"
                            "isEnabled"     = $true
                            "endPointUrl"   = "https://test.com"
                        }
                    )
                    "instances"         = @(
                        @{
                            "providerInstanceName" = $OpenAI_providerInstanceName
                            "modelInstanceName"    = "gpt-35-turbo"
                            "priority"             = 1
                        }
                    )
                    "parameters"        = @(
                        @{
                            "parameterName" = "max_tokens"
                            "capabilityKey" = "Chat"
                            "dataType"      = "Int"
                            "minValue"      = "1"
                            "maxValue"      = "10"
                            "defaultValue"  = "1"
                        }
                    )
                    "isEnabled"         = $true
                } | ConvertTo-Json
            }
            $response = $null
            $response = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true
            Write-Host " Model is Created in Azure Open AI   ---  $response"

            Write-Host "Waiting 400 Sec to Cache refresh"
            Start-Sleep -Seconds 400

        }
        It "Assertion to check Chat Completion in America's Region" {
            Write-Host "Verifing Chat Completion with New Model $OpenAi_DummymodelName "
            $requestParams = @{
                Method = 'POST'
                Uri    = "/workspace/api/v1/generativeai/chat"
                Body   = @{
                    "modelName"      = $OpenAi_DummymodelName
                    "engagementCode" = $engagementCode
                    "messages"       = @( @{
                            "role"    = "User"
                            "content" = "Who won the Cricket World Cup in 2011"
                        })
                } | ConvertTo-Json
            }

            $response = $null
            $response = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true
            Write-Host " Chat Completion with New Model Working ---  $response"

            $response | Should -Not -BeNullOrEmpty
            $response.userGeoLocation | Should -be "AMERICAS"
        }
    }

} #>


















