param(

    [Parameter(Mandatory)]
    [ValidateNotNullOrEmpty()]
    $CurrentEnvironmentData

)
Describe "Workspace-{azureSkuResourceType}" {
Context "DM_Workspace_API_47_04 | Gets the available VM configurations in Azure for the next available subscription" {
    BeforeAll {
        $requestParams = @{
            Method = 'GET'
            Uri    = "/workspace/api/v1/azureresourcesku?azureSkuResourceType=AvailabilitySets"                
        }

        $response = @{}
        $response = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true
    }
    It "Should not return null" {                               
        $response | Should -not -BeNullOrEmpty
    }
    It "Should return at least one record" {
        $response.Count | Should -BeGreaterThan 0
    }
}
Context "DM_Workspace_API_47_04 | Gets the available VM configurations in Azure for the next available subscription" {
    BeforeAll {
        $requestParams = @{
            Method = 'GET'
            Uri    = "/workspace/api/v1/azureresourcesku?azureSkuResourceType=Disks"                
        }

        $response = @{}
        $response = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true
    }
    It "Should not return null" {                               
        $response | Should -not -BeNullOrEmpty
    }
    It "Should return at least one record" {
        $response.Count | Should -BeGreaterThan 0
    }
}
Context "DM_Workspace_API_47_04 | Gets the available VM configurations in Azure for the next available subscription" {
    BeforeAll {
        $requestParams = @{
            Method = 'GET'
            Uri    = "/workspace/api/v1/azureresourcesku?azureSkuResourceType=HostGroups"                
        }

        $response = @{}
        $response = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true
    }
    It "Should not return null" {                               
        $response | Should -not -BeNullOrEmpty
    }
    It "Should return at least one record" {
        $response.Count | Should -BeGreaterThan 0
    }
}
Context "DM_Workspace_API_47_04 | Gets the available VM configurations in Azure for the next available subscription" {
    BeforeAll {
        $requestParams = @{
            Method = 'GET'
            Uri    = "/workspace/api/v1/azureresourcesku?azureSkuResourceType=Snapshots"                
        }

        $response = @{}
        $response = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true
    }
    It "Should not return null" {                               
        $response | Should -not -BeNullOrEmpty
    }
    It "Should return at least one record" {
        $response.Count | Should -BeGreaterThan 0
    }
}
Context "DM_Workspace_API_47_04 | Gets the available VM configurations in Azure for the next available subscription" {
    BeforeAll {
        $requestParams = @{
            Method = 'GET'
            Uri    = "/workspace/api/v1/azureresourcesku?azureSkuResourceType=VirtualMachines"                
        }

        $response = @{}
        $response = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true
    }
    It "Should not return null" {                               
        $response | Should -not -BeNullOrEmpty
    }
    It "Should return at least one record" {
        $response.Count | Should -BeGreaterThan 0
    }
}
}