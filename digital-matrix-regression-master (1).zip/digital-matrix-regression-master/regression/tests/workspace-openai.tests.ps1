param(

    [Parameter(Mandatory)]
    [ValidateNotNullOrEmpty()]
    $CurrentEnvironmentData

)

$Script:DeploymentNames = @()

Describe "Workspace API - OpenAI" {
    Context "Test Case : Get Deployment names" {
        BeforeAll {
            $requestParams = @{
                Method = 'GET'
                Uri    = "/workspace/api/v1/ai/deployment"
            }

            $Script:DeploymentNameList = @{}
            $Script:DeploymentNameList = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true

            for ($i = 0; $i -lt $DeploymentNameList.length; $i++) {
                $DeploymentNames += $($DeploymentNameList[$i].deploymentName)
            }
            FailEarly 'Validate the list of response of the deplymentNames' {
                $DeploymentNameList.count | Should -Not -BeNullOrEmpty
            }

            Write-Host "Deployment Names are - $($DeploymentNames)"
        }

        It "Should get the list of deployment names" {
            $DeploymentNameList | Should -Not -BeNullOrEmpty
        }
    }

    <# Context "Test Case - create a completion" {
        It "Should retrieve the completion details in the response body" {
            #create a completion with all mandatory fileds
            $requestParams = @{
                Method = 'POST'
                Uri    = "/workspace/api/v1/ai/deployment/text-davinci-003/completion"
                Body   = @{
                    "engagementCode" = "803000012512"
                    "prompt"         = "Who is Bill Gates"
                    "maxTokens"      = Get-Random -Minimum 100 -Maximum 1000
                    "stop"           = @("<|im_end|>")
                } | ConvertTo-Json
            }
            $createCompletionResponse1 = @{}
            $createCompletionResponse1 = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true

            FailEarly 'Should return 200 status code for creating completion with mandatory fields' {
                $createCompletionResponse1 | Should -Not -BeNullOrEmpty
                $($createCompletionResponse1.model) | Should -Contain "text-davinci-003"
                $($createCompletionResponse1.choices.finishReason) | Should -Not -BeNullOrEmpty
            }


            #create a completion with all available fileds
            $requestParams = @{
                Method = 'POST'
                Uri    = "/workspace/api/v1/ai/deployment/text-davinci-003/completion"
                Body   = @{
                    "engagementCode"                   = "803000012512"
                    "prompt"                           = "What are the seven wonders of the world"
                    "temperature"                      = Get-Random -Minimum 0 -Maximum 1
                    "topP"                             = Get-Random -Minimum 0 -Maximum 1
                    "frequencyPenalty"                 = Get-Random -Minimum 0 -Maximum 2
                    "presencePenalty"                  = Get-Random -Minimum 0 -Maximum 2
                    "bestOf"                           = Get-Random -Minimum 1 -Maximum 20
                    "maxTokens"                        = Get-Random -Minimum 100 -Maximum 1000
                    "stop"                             = @("<|im_end|>")
                    "appendTrailingWhitespaceToPrompt" = $true
                    "appendTrailingWhitespaceToStop"   = $true
                } | ConvertTo-Json
            }
            $createCompletionResponse2 = @{}
            $createCompletionResponse2 = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true

            FailEarly 'Should return 200 status code for creating completion with available fields' {
                $createCompletionResponse2 | Should -Not -BeNullOrEmpty
                $($createCompletionResponse2.model) | Should -Contain "text-davinci-003"
                $($createCompletionResponse2.choices.finishReason) | Should -Not -BeNullOrEmpty
            }
        }
    } #>

    Context "Test Case : Chat Completion and Chat completion async" {
        It "Should get the chat completion and chat completion async details in the response body" {
            #create a chat completion with all mandatory fileds
            $requestParams = @{
                Method = 'POST'
                Uri    = "/workspace/api/v1/ai/deployment/gpt-4/chat/completion"
                Body   = @{
                    "engagementCode" = "803000012512"
                    "messages"       = @( @{
                            "role"    = "system"
                            "content" = "Will provide accurate result for the prompt"
                        }, @{
                            "role"    = "assistant"
                            "content" = "I am an assistant that can help answer your questions"
                        }, @{"role"   = "user"
                            "content" = "What should be our best practices in life"
                        })
                } | ConvertTo-Json
            }
            $chatCompletionResponse1 = @{}
            $chatCompletionResponse1 = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true

            FailEarly 'Should return 200 status code for chat completion with mandatory fields' {
                $chatCompletionResponse1 | Should -Not -BeNullOrEmpty
                $($chatCompletionResponse1.object) | Should -eq "chat.completion"
                $($chatCompletionResponse1.choices.finishReason) | Should -Not -BeNullOrEmpty
            }

            write-host "create a chat completion with all available fileds"
            $requestParams = @{
                Method = 'POST'
                Uri    = "/workspace/api/v1/ai/deployment/gpt-4/chat/completion"
                Body   = @{
                    "engagementCode"                 = "803000012512"
                    "messages"                       = @( @{
                            "role"    = "system"
                            "content" = "Will provide accurate result for the prompt"
                        }, @{
                            "role"    = "assistant"
                            "content" = "I am an assistant that can help answer your questions"
                        }, @{"role"   = "user"
                            "content" = "What should be the aim of our life"
                        })
                    "temperature"                    = Get-Random -Minimum 0 -Maximum 1
                    "choiceCount"                    = Get-Random -Minimum 1 -Maximum 5
                    "stop"                           = @("<|im_end|>")
                    "maxTokens"                      = Get-Random -Minimum 100 -Maximum 1000
                    "presencePenalty"                = Get-Random -Minimum 0 -Maximum 2
                    "frequencyPenalty"               = Get-Random -Minimum 0 -Maximum 2
                    "appendTrailingWhitespaceToStop" = $true

                } | ConvertTo-Json
            }
            $chatCompletionResponse2 = @{}
            $chatCompletionResponse2 = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true

            FailEarly 'Should return 200 status code for chat completion with available fields' {
                $chatCompletionResponse2 | Should -Not -BeNullOrEmpty
                $($chatCompletionResponse2.object) | Should -eq "chat.completion"
                $($chatCompletionResponse2.choices.finishReason) | Should -Not -BeNullOrEmpty
            }

            Write-host "create a chat completion async with all mandatory fileds"
            $requestParams = @{
                Method = 'POST'
                Uri    = "/workspace/api/v1/ai/deployment/gpt-4/chat/completionasync"
                Body   = @{
                    "engagementCode" = "803000012512"
                    "messages"       = @(@{
                            "role"    = "user"
                            "content" = "Best places to visit in India"
                        })
                    "stop"           = @("<|im_end|>")
                } | ConvertTo-Json
            }

            $chatCompletionAsyncResponse1 = @{}
            $chatCompletionAsyncResponse1 = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true

            FailEarly 'Should return 200 status code for chat completion async with mandatory fields' {
                $chatCompletionAsyncResponse1 | Should -Not -BeNullOrEmpty
            }

            Write-host "create a chat completion async with all available fileds"
            $requestParams = @{
                Method = 'POST'
                Uri    = "/workspace/api/v1/ai/deployment/gpt-4/chat/completionasync"
                Body   = @{
                    "engagementCode"                 = "803000012512"
                    "messages"                       = @(@{
                            "role"    = "user"
                            "content" = "What is KPMG"
                        })
                    "temperature"                    = Get-Random -Minimum 0 -Maximum 1
                    "stop"                           = @("<|im_end|>")
                    "maxTokens"                      = Get-Random -Minimum 100 -Maximum 1000
                    "presencePenalty"                = Get-Random -Minimum 0 -Maximum 2
                    "frequencyPenalty"               = Get-Random -Minimum 0 -Maximum 2
                    "appendTrailingWhitespaceToStop" = $true
                } | ConvertTo-Json
            }

            $chatCompletionAsyncResponse2 = @{}
            $chatCompletionAsyncResponse2 = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true

            FailEarly 'Should return 200 status code for chat completion async with available fields' {
                $chatCompletionAsyncResponse2 | Should -Not -BeNullOrEmpty
            }
        }
    }

     <# Context "TC-259393 - Create Completion - Negative TC"{
        Context "Create a completion without the  mandatory fields - Negative TC" {
            BeforeAll {
                $requestParams = @{
                    Method = 'POST'
                    Uri    = "/workspace/api/v1/ai/deployment/text-davinci-003/completion"
                    Body   = @{
                        "engagementCode" = "803000012512"
                        "prompt"       = "Who is Bill Gates"
                    } | ConvertTo-Json
                }
                $response = @{}
                $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true
            }

            It "Should return 400 error for creating a completion with missing mandatory fields" {
                $response.ExceptionResponse.StatusCode.value__ | Should -be 400
            }
        }

        Context "Create a completion with invalid engagement code - Negative TC" {
            BeforeAll {
                $requestParams = @{
                    Method = 'POST'
                    Uri    = "/workspace/api/v1/ai/deployment/text-davinci-003/completion"
                    Body   = @{
                        "engagementCode" = "ghsgah"
                        "prompt"         = "Who is Bill Gates"
                        "maxTokens"      = Get-Random -Minimum 100 -Maximum 1000
                        "stop"           = @("<|im_end|>")
                    } | ConvertTo-Json
                }
                $response = @{}
                $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true
            }

            It "Should return 404 error for creating a completion with invalid engagement code" {
                $response.ExceptionResponse.StatusCode.value__ | Should -be 404
            }

            It "Should return user friendly message for creating a completion with invalid engagement code" {
                $response.ErrorDetails.message | should -eq "Engagement with code 'ghsgah' not found"
            }
        }

        Context "Create a completion for exceeded max token value - Negative TC" {
            BeforeAll {
                $requestParams = @{
                    Method = 'POST'
                    Uri    = "/workspace/api/v1/ai/deployment/text-davinci-003/completion"
                    Body   = @{
                        "engagementCode" = "803000012512"
                        "prompt"         = "Who is Bill Gates"
                        "maxTokens"      = 999999999999999
                        "stop"           = @("<|im_end|>")
                    } | ConvertTo-Json
                }
                $response = @{}
                $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true
            }

            It "Should return 400 error for creating a completion with exceeded max token value" {
                $response.ExceptionResponse.StatusCode.value__ | Should -be 400
            }
        }

        Context "Create a completion for invalid stop value - Negative TC" {
            BeforeAll {
                $requestParams = @{
                    Method = 'POST'
                    Uri    = "/workspace/api/v1/ai/deployment/text-davinci-003/completion"
                    Body   = @{
                        "engagementCode" = "803000012512"
                        "prompt"         = "Who is Bill Gates"
                        "maxTokens"      = Get-Random -Minimum 100 -Maximum 1000
                        "stop"           = @(" ")
                    } | ConvertTo-Json
                }
                $response = @{}
                $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true
            }

            It "Should return 400 error for creating a completion with invalid stop value" {
                $response.ExceptionResponse.StatusCode.value__ | Should -be 400
            }

            It "Should return user friendly message for creating a completion with invalid stop value" {
                $response.ErrorDetails.message | should -eq "leading/trailing whitespace detected - please trim all input and try again"
            }
        }

    } #>

    Context "TC-259394 - Create Chat Completion - Negative TC" {
        Context "Create a chat completion without mandatory fields - Negative TC" {
            BeforeAll {
                $requestParams = @{
                    Method = 'POST'
                    Uri    = "/workspace/api/v1/ai/deployment/gpt-4/chat/completion"
                    Body   = @{
                        "engagementCode" = "803000012512"
                    } | ConvertTo-Json
                }
                $response = @{}
                $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true
            }

            It "Should return 400 error for creating a chat completion without mandatory fields" {
                $response.ExceptionResponse.StatusCode.value__ | Should -be 400
            }
        }

        Context "Create a chat completion with exceeded value of temperature, presencePenalty, frequencyPenalty - Negative TC" {
            BeforeAll {
                $requestParams = @{
                    Method = 'POST'
                    Uri    = "/workspace/api/v1/ai/deployment/gpt-4/chat/completion"
                    Body   = @{
                        "engagementCode" = "803000012512"
                        "messages" = @( @{
                                "role"    = "user"
                                "content" = "Till now how many launches are done by spacex using falcon9"
                            })
                        "temperature" = 3
                        "choiceCount"= 1
                        "stop"   = @("<|im_end|>")
                        "maxTokens" = Get-Random -Minimum 100 -Maximum 1000
                        "presencePenalty" = 3
                        "frequencyPenalty" = 3
                        "appendTrailingWhitespaceToStop" = $true
                    } | ConvertTo-Json
                }
                $response = @{}
                $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true
            }

            It "Should return 400 error for creating a chat completion with exceeded value of temperature, presencePenalty, frequencyPenalty" {
                $response.ExceptionResponse.StatusCode.value__ | Should -be 400
            }

            It "Should return user friendly message for creating a chat completion with exceeded value of temperature, presencePenalty, frequencyPenalty" {
                $response.ErrorDetails.errors.Temperature | should -eq "The field Temperature must be between 0 and 2."
                $response.ErrorDetails.errors.PresencePenalty | should -eq "The field PresencePenalty must be between -2 and 2."
                $response.ErrorDetails.errors.FrequencyPenalty | should -eq "The field FrequencyPenalty must be between -2 and 2."
            }
        }

        Context "Create a chat completion with missing engagement code - Negative TC" {
            BeforeAll {
                $requestParams = @{
                    Method = 'POST'
                    Uri    = "/workspace/api/v1/ai/deployment/gpt-4/chat/completion"
                    Body   = @{
                        "messages" = @( @{
                                "role"    = "user"
                                "content" = "Till now how many launches are done by spacex using falcon9"
                            })
                        "temperature" = 1
                        "choiceCount"= 1
                        "stop"   = @("<|im_end|>")
                        "maxTokens" = Get-Random -Minimum 100 -Maximum 1000
                        "presencePenalty" = 2
                        "frequencyPenalty" = 2
                        "appendTrailingWhitespaceToStop" = $true
                    } | ConvertTo-Json
                }
                $response = @{}
                $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true
            }

            It "Should return 400 error for creating a chat completion with missing engagement code" {
                $response.ExceptionResponse.StatusCode.value__ | Should -be 400
            }

            It "Should return user friendly message for creating a chat completion with missing engagement code" {
                $response.ErrorDetails.errors.EngagementCode | should -eq "The EngagementCode field is required."
            }
        }
    }

    Context "TC-259395 - Create chat Completion Async - Negatice TC" {
        Context "Create a chat completion async without mandatory fields - Negative TC" {
            BeforeAll {
                $requestParams = @{
                    Method = 'POST'
                    Uri    = "/workspace/api/v1/ai/deployment/gpt-4/chat/completionasync"
                    Body   = @{
                        "engagementCode" = "803000012512"
                        "messages"       = @( @{
                                "role"    = "user"
                                "content" = "Till now how many launches are done by spacex using falcon9"
                            })
                    } | ConvertTo-Json
                }
                $response = @{}
                $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true
            }

            It "Should return 400 error for creating a chat completion async without mandatory field" {
                $response.ExceptionResponse.StatusCode.value__ | Should -be 400
            }

            It "Should return user friendly message for creating a chat completion async without mandatory field" {
                $response.ErrorDetails.message | should -eq "Please provide a stop sequence, or pass appendTrailingWhitespaceToStop = true"
            }
        }

        Context "Create a chat completion async for numeric value of appendTrailingWhitespaceToStop - Negative TC" {
            BeforeAll {
                $requestParams = @{
                    Method = 'POST'
                    Uri    = "/workspace/api/v1/ai/deployment/gpt-4/chat/completionasync"
                    Body   = @{
                        "engagementCode" = "803000012512"
                        "messages"       = @( @{
                                "role"    = "user"
                                "content" = "Till now how many launches are done by spacex using falcon9"
                            })
                        "stop"           = @("<|im_end|>")
                        "appendTrailingWhitespaceToStop" = 898989
                    } | ConvertTo-Json
                }
                $response = @{}
                $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true
            }

            It "Should return 400 error for creating a chat completion async for numeric value of appendTrailingWhitespaceToStop" {
                $response.ExceptionResponse.StatusCode.value__ | Should -be 400
            }
        }
    }

    # Context "Verify Multimodal support image input - OpenAI" {
    #     Context "Verify that models supporting vision capability only accept image URL in request body -- Chat Completion" {
    #         BeforeALL{
    #             Write-Host "Model/Deployment name that support vision capability - Chat Completion"
    #             $imageUrlArray = @("https://c8.alamy.com/comp/EYEERC/yellow-taxi-cabs-and-a-red-double-decker-sightseeing-bus-on-the-road-EYEERC.jpg")
    #             $requestParams = @{
    #                 Method = 'POST'
    #                 Uri    = "/workspace/api/v1/ai/deployment/gpt-4-vision-preview/chat/completion"
    #                 Body   = @{
    #                     "engagementCode"       = "803000012512"
    #                     "messages"             = @( @{
    #                         "role"     = "user"
    #                             "content"  = "How many buses are there in the image?"
    #                             "imageUrls" = $imageUrlArray
    #                     } )
    #                     "maxTokens"            = "10"
    #                     "frequencyPenalty"     = "1"
    #                     "enableComputerVision" = $true
    #                     "enableOcr"            = $true
    #                     "enableGrounding"      = $true
    #                 } | ConvertTo-Json -Depth 10
    #             }
    #             $chatCompletionResponse1 = @{}
    #             $chatCompletionResponse1 = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true
    #         }

    #         It "Test Case 326798: ST_TC_DM_310796:(Positive TC) Verify that models supporting vision capability only accept image URL in request body-Chat Completion" {
    #             $chatCompletionResponse1 | Should -Not -BeNullOrEmpty
    #             $($chatCompletionResponse1.model) | Should -Contain "gpt-4"
    #             $($chatCompletionResponse1.userGeoLocation) | Should -Not -BeNullOrEmpty
    #             $($chatCompletionResponse1.choices.finishReason) | Should -Not -BeNullOrEmpty
    #             $($chatCompletionResponse1.choices.finishReason) | Should -Not -Be "error"
    #             $($chatCompletionResponse1.choices.message.content) | Should -Not -BeNullOrEmpty
    #         }

    #         It "Test Case 326857: ST_TC_DM_310796:(Positive TC) Verify grounding parameters in Chat Completion response for models with vision capability" {
    #             Write-Host "Response of grounding parameters --- $($chatCompletionResponse1.choices[0].enhancement.grounding.lines[0].spans[0].polygon[0])"
    #             $($chatCompletionResponse1.choices.enhancement.grounding.lines.spans.length) | Should -Not -BeNullOrEmpty
    #             $($chatCompletionResponse1.choices.enhancement.grounding.lines.spans.polygon) | Should -Not -BeNullOrEmpty
    #         }

    #         It "Test Case 327268_327446: ST_TC_DM_310796:(Positive TC) Validate image recognition and prompt response generation when enable_computer_vision is set to 'true' in Chat Completion" {
    #             $($chatCompletionResponse1.choices.message.content) | Should -Not -BeNullOrEmpty
    #             Write-Host "Prompt response ---$($chatCompletionResponse1.choices.message.content)"
    #             $($chatCompletionResponse1.choices.enhancement.grounding.lines.spans.text) | Should -Not -BeNullOrEmpty
    #             $($chatCompletionResponse1.choices.enhancement.grounding.lines.spans.polygon) | Should -Not -BeNullOrEmpty
    #         }

    #         It "Test Case 329588: ST_TC_DM_310796:(Positive TC) Verify that deployment name (Model) that supports vision capability accepts multiple image URL" {
    #             Write-Host "Model/Deployment name that support vision capability accepts multiple image urls- Chat Completion"
    #             $imageUrlArray = @("https://c8.alamy.com/comp/EYEERC/yellow-taxi-cabs-and-a-red-double-decker-sightseeing-bus-on-the-road-EYEERC.jpg","https://c8.alamy.com/comp/EG2X58/traffic-lights-with-ready-steady-go-text-EG2X58.jpg")
    #             $requestParams = @{
    #                 Method = 'POST'
    #                 Uri    = "/workspace/api/v1/ai/deployment/gpt-4-vision-preview/chat/completion"
    #                 Body   = @{
    #                     "engagementCode"       = "803000012512"
    #                     "messages"             = @( @{
    #                         "role"     = "user"
    #                             "content"  = "How many buses are there in the image?"
    #                             "imageUrls" = $imageUrlArray
    #                     } )
    #                     "maxTokens"            = "10"
    #                     "frequencyPenalty"     = "1"
    #                     "enableComputerVision" = $true
    #                     "enableOcr"            = $true
    #                     "enableGrounding"      = $true
    #                 } | ConvertTo-Json -Depth 10
    #             }
    #             $chatCompletionResponse2 = @{}
    #             $chatCompletionResponse2 = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true
    #             $($chatCompletionResponse2.choices.message.content) | Should -Not -BeNullOrEmpty
    #         }
    #     }
    #     Context "Verify that models supporting vision capability only accept image URL in request body -- Chat Completion Async" {
    #         BeforeALL{
    #             Write-Host "Model/Deployment name that support vision capability - Chat Completion Async"
    #             $imageUrlArray = @("https://techcouver.com/wp-content/uploads/2021/03/Microsoft-Office.jpeg")
    #             $requestParams = @{
    #                 Method = 'POST'
    #                 Uri    = "/workspace/api/v1/ai/deployment/gpt-4-vision-preview/chat/completionasync"
    #                 Body   = @{
    #                     "engagementCode"       = "803000012512"
    #                     "messages"             = @( @{
    #                         "role"     = "user"
    #                             "content"  = "What are items available on the table?"
    #                             "imageUrls" = $imageUrlArray
    #                     } )
    #                     "maxTokens"            = "12"
    #                     "frequencyPenalty"     = "2"
    #                     "appendTrailingWhitespaceToStop" = $true
    #                 } | ConvertTo-Json -Depth 10
    #             }
    #             $chatCompletionAsyncResponse1 = @{}
    #             $chatCompletionAsyncResponse1 = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true
    #         }

    #         It "Test Case 326798: ST_TC_DM_310796:(Positive TC) Verify that models supporting vision capability only accept image URL in request body-Chat Completion" {
    #             $chatCompletionAsyncResponse1 | Should -Not -BeNullOrEmpty
    #             # $($chatCompletionResponse1[0].model) | Should -Contain "gpt-4"
    #             # $($chatCompletionResponse1[0].finishReason) | Should -Not -BeNullOrEmpty
    #             # $($chatCompletionResponse1[0].finishReason) | Should -Not -Be "error"
    #             $responseString = $chatCompletionAsyncResponse1 | ConvertTo-Json -Depth 10
    #             # Log the response for debugging
    #             Write-Host "Response: $responseString"
    #         }

    #         It "Test Case 327454: ST_TC_DM_310796:(Positive TC) Verify no grounding parameters are available in Chat Streaming Completion response for models with vision capability" {
    #             $chatCompletionAsyncResponse1 | Should -Not -Contain "grounding"
    #         }

    #         It "Test Case 327261: ST_TC_DM_310796:(Positive TC) Verify that the parameters enable_computer_vision, enable_ocr and enable_grounding have no impact on the Chat Streaming request body for models with vision capability" {
    #             Write-Host "Vision capability parameters have no impact on Chat Completion Async"
    #             $imageUrlArray = @("https://c8.alamy.com/comp/EYEERC/yellow-taxi-cabs-and-a-red-double-decker-sightseeing-bus-on-the-road-EYEERC.jpg")
    #             $requestParams = @{
    #                 Method = 'POST'
    #                 Uri    = "/workspace/api/v1/ai/deployment/gpt-4-vision-preview/chat/completionasync"
    #                 Body   = @{
    #                     "engagementCode"       = "803000012512"
    #                     "messages"             = @( @{
    #                         "role"     = "user"
    #                             "content"  = "How many buses are there in the image?"
    #                             "imageUrls" = $imageUrlArray
    #                     } )
    #                     "maxTokens"            = "10"
    #                     "frequencyPenalty"     = "1"
    #                     "enableComputerVision" = $false
    #                     "enableOcr"            = $false
    #                     "enableGrounding"      = $false
    #                     "appendTrailingWhitespaceToStop" = $true
    #                 } | ConvertTo-Json -Depth 10
    #             }
    #             $chatCompletionAsyncResponse2 = @{}
    #             $chatCompletionAsyncResponse2 = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true
    #             Write-Host "Response of Chat Completion Async--" $chatCompletionAsyncResponse2 | ConvertFrom-Json
    #         }
    #     }

    #     #Negative test cases ---- Vision Model
    #     Context "Vision Model Capability - Negative Scenarios" {
    #         It "Test Case 327274: ST_TC_DM_310796:(Negative TC) Validate No image recognition and prompt response generation when enable_computer_vision is set to false in Chat Completion." {
    #             Write-Host "Enable_computer_vision is set to false in Chat Completion"
    #             $imageUrlArray = @("https://c8.alamy.com/comp/EG2X58/traffic-lights-with-ready-steady-go-text-EG2X58.jpg")
    #             $validateErrorMsg = "'EnableComputerVision' field should be enabled if any or both Ocr and Grounding is enabled."
    #             $requestParams = @{
    #                 Method = 'POST'
    #                 Uri    = "/workspace/api/v1/ai/deployment/gpt-4-vision-preview/chat/completion"
    #                 Body   = @{
    #                     "engagementCode"       = "803000012512"
    #                     "messages"             = @( @{
    #                         "role"     = "user"
    #                             "content"  = "How many colors are available in the image?"
    #                             "imageUrls" = $imageUrlArray
    #                     } )
    #                     "maxTokens"            = "10"
    #                     "frequencyPenalty"     = "1"
    #                     "enableComputerVision" = $false
    #                     "enableOcr"            = $true
    #                     "enableGrounding"      = $true
    #                   } | ConvertTo-Json -Depth 10
    #             }
    #             $response = @{}
    #             $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true
    #             Write-Host "Should return 400 error"
    #             $response.ExceptionResponse.StatusCode.value__ | Should -be 400
    #             Write-Host "Error Message ----" $response.ErrorDetails.message | ConvertFrom-Json
    #             # $ErrorMessage = $response.ErrorDetails.message | ConvertFrom-Json
    #             # $($response.ErrorDetails.message | ConvertFrom-Json) | Should -be "'EnableComputerVision' field should be enabled if any or both Ocr and Grounding is enabled."
    #         }

    #         IT "Test Case 327891: ST_TC_DM_310796:(Negative TC) Verify error is thrown on specifying image URL for models without vision capability - Chat Completion"{
    #             Write-Host "Ensure error is thrown on specifying image url for model that does not support vision capability - Chat Completion"
    #             $imageUrlArray = @("https://c8.alamy.com/comp/EG2X58/traffic-lights-with-ready-steady-go-text-EG2X58.jpg")
    #             $requestParams = @{
    #                 Method = 'POST'
    #                 Uri    = "/workspace/api/v1/ai/deployment/gpt-35-turbo-16k/chat/completion"
    #                 Body   = @{
    #                     "engagementCode"       = "803000012512"
    #                     "messages"             = @( @{
    #                         "role"     = "user"
    #                             "content"  = "How many colors are available in the image?"
    #                             "imageUrls" = $imageUrlArray
    #                     } )
    #                     "maxTokens"            = "10"
    #                     "frequencyPenalty"     = "1"
    #                     "enableComputerVision" = $true
    #                     "enableOcr"            = $true
    #                     "enableGrounding"      = $true
    #                   } | ConvertTo-Json -Depth 10
    #             }
    #             $response = @{}
    #             $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true
    #             Write-Host "Should return 400 error"
    #             $response.ExceptionResponse.StatusCode.value__ | Should -be 400
    #             Write-Host "Error Message"---$response.ErrorDetails.message
    #             # $response.ErrorDetails.message | Should -Contain "Provided deployment/model name does not support vision capability."
    #         }

    #         IT "Test Case 327891: ST_TC_DM_310796:(Negative TC) Verify error is thrown on specifying image URL for models without vision capability - Chat Completion Async"{
    #             Write-Host "Ensure error is thrown on specifying image url for model that does not support vision capability - Chat Completion Async"
    #             $imageUrlArray = @("https://c8.alamy.com/comp/EG2X58/traffic-lights-with-ready-steady-go-text-EG2X58.jpg")
    #             $requestParams = @{
    #                 Method = 'POST'
    #                 Uri    = "/workspace/api/v1/ai/deployment/gpt-35-turbo-16k/chat/completionasync"
    #                 Body   = @{
    #                     "engagementCode"       = "803000012512"
    #                     "messages"             = @( @{
    #                         "role"     = "user"
    #                             "content"  = "How many colors are available in the image?"
    #                             "imageUrls" = $imageUrlArray
    #                     } )
    #                     "maxTokens"            = "10"
    #                     "frequencyPenalty"     = "1"
    #                     "appendTrailingWhitespaceToStop" = $true
    #                   } | ConvertTo-Json -Depth 10
    #             }
    #             $response = @{}
    #             $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true
    #             Write-Host "Should return 400 error"
    #             $response.ExceptionResponse.StatusCode.value__ | Should -be 400
    #             Write-Host "Error Message ----" $response.ErrorDetails.message | ConvertFrom-Json
    #             # $ErrorMessage = $response.ErrorDetails.message | ConvertFrom-Json
    #             # $ErrorMessage | Should -match "Provided deployment/model name does not support vision capability."
    #         }

    #         It "Test Case 327455: ST_TC_DM_310796:(Negative TC) Verify error is thrown when inputting invalid image url for models with vision capability for User Role- Chat Completion" {
    #             Write-Host "Inputtin invalid image url for User role- Chat Completion"
    #             $imageUrlArray = @("https://test.doc")
    #             $requestParams = @{
    #                 Method = 'POST'
    #                 Uri    = "/workspace/api/v1/ai/deployment/gpt-4-vision-preview/chat/completion"
    #                 Body   = @{
    #                     "engagementCode"       = "803000012512"
    #                     "messages"             = @( @{
    #                         "role"     = "user"
    #                             "content"  = "Explain the image?"
    #                             "imageUrls" = $imageUrlArray
    #                     } )
    #                     "maxTokens"            = "10"
    #                     "frequencyPenalty"     = "1"
    #                     "enableComputerVision" = $true
    #                     "enableOcr"            = $true
    #                     "enableGrounding"      = $true
    #                 } | ConvertTo-Json -Depth 10
    #             }
    #             $response = @{}
    #             $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true
    #             Write-Host "Should return 400 error"
    #             $response.ExceptionResponse.StatusCode.value__ | Should -be 400
    #             # Write-Host "Error Message ----" $response.ErrorDetails.message.error.message | ConvertFrom-Json
    #             # $($response.ErrorDetails.message | ConvertFrom-Json) | Should -be "The provided image url is not accessible."
    #         }

    #         It "Test Case 327455: ST_TC_DM_310796:(Negative TC) Verify error is thrown when inputting special characters in image url for models with vision capability for User Role- Chat Completion" {
    #             Write-Host "Inputtin special characters in image url for User role- Chat Completion"
    #             $imageUrlArray = @("#%%(@*")
    #             $requestParams = @{
    #                 Method = 'POST'
    #                 Uri    = "/workspace/api/v1/ai/deployment/gpt-4-vision-preview/chat/completion"
    #                 Body   = @{
    #                     "engagementCode"       = "803000012512"
    #                     "messages"             = @( @{
    #                         "role"     = "user"
    #                             "content"  = "Explain the image?"
    #                             "imageUrls" = $imageUrlArray
    #                     } )
    #                     "maxTokens"            = "10"
    #                     "frequencyPenalty"     = "1"
    #                     "enableComputerVision" = $true
    #                     "enableOcr"            = $true
    #                     "enableGrounding"      = $true
    #                 } | ConvertTo-Json -Depth 10
    #             }
    #             $response = @{}
    #             $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true
    #             Write-Host "Should return 400 error"
    #             $response.ExceptionResponse.StatusCode.value__ | Should -be 400
    #             Write-Host "Error Message ----" $response.ErrorDetails.message | ConvertFrom-Json
    #             # $ErrorMessage = $response.ErrorDetails.message | ConvertFrom-Json
    #             # $ErrorMessage | Should -match "These ImageUrls are not valid - '#%%(@*'."
    #         }

    #         It "Test Case 327455: ST_TC_DM_310796:(Negative TC) Verify error is thrown when inputting special characters in image url for models with vision capability for System Role- Chat Completion" {
    #             Write-Host "Inputtin special characters in image url for User role- Chat Completion"
    #             $imageUrlArray = @("#%%(@*.pdf")
    #             $requestParams = @{
    #                 Method = 'POST'
    #                 Uri    = "/workspace/api/v1/ai/deployment/gpt-4-vision-preview/chat/completion"
    #                 Body   = @{
    #                     "engagementCode"       = "803000012512"
    #                     "messages"             = @( @{
    #                         "role"     = "system"
    #                             "content"  = "Explain the image?"
    #                             "imageUrls" = $imageUrlArray
    #                     } )
    #                     "maxTokens"            = "10"
    #                     "frequencyPenalty"     = "1"
    #                     "enableComputerVision" = $true
    #                     "enableOcr"            = $true
    #                     "enableGrounding"      = $true
    #                 } | ConvertTo-Json -Depth 10
    #             }
    #             $response = @{}
    #             $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true
    #             Write-Host "Should return 400 error"
    #             $response.ExceptionResponse.StatusCode.value__ | Should -be 400
    #             Write-Host "Error Message ----" $response.ErrorDetails.message | ConvertFrom-Json
    #             # $ErrorMessage = $response.ErrorDetails.message | ConvertFrom-Json
    #             # $($response.ErrorDetails.message | ConvertFrom-Json) | Should -Contain "These ImageUrls are not valid - '#%%(@*.pdf'."
    #         }

    #         It "Test Case 327687: ST_TC_DM_310796:(Negative TC) Verify error is thrown when inputting invalid image url for models with vision capability - Chat completionasync" {
    #             Write-Host "Inputtin invalid image url for User role- Chat Completion Async"
    #             $imageUrlArray = @("https://jpeg")
    #             $requestParams = @{
    #                 Method = 'POST'
    #                 Uri    = "/workspace/api/v1/ai/deployment/gpt-4-vision-preview/chat/completionasync"
    #                 Body   = @{
    #                     "engagementCode"       = "803000012512"
    #                     "messages"             = @( @{
    #                         "role"     = "user"
    #                             "content"  = "Explain the image?"
    #                             "imageUrls" = $imageUrlArray
    #                     } )
    #                     "maxTokens"            = "10"
    #                     "frequencyPenalty"     = "1"
    #                     "appendTrailingWhitespaceToStop" = $true
    #                 } | ConvertTo-Json -Depth 10
    #             }
    #             $response = @{}
    #             $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true
    #             Write-Host "Should return 400 error"
    #             $response.ExceptionResponse.StatusCode.value__ | Should -be 400
    #             Write-Host "Error Message ----" $response.ErrorDetails.message | ConvertFrom-Json
    #             # $ErrorMessage = $response.ErrorDetails.message | ConvertFrom-Json
    #             # $ErrorMessage | Should -be "The provided image url is not accessible."
    #         }

    #         It "Test Case 327687: ST_TC_DM_310796:(Negative TC) Verify error is thrown when inputting special characters in image url for models with vision capability - Chat completionasync" {
    #             Write-Host "Inputtin special characters in image url for User role- Chat Completion Async"
    #             $imageUrlArray = @("#%%(@*")
    #             $requestParams = @{
    #                 Method = 'POST'
    #                 Uri    = "/workspace/api/v1/ai/deployment/gpt-4-vision-preview/chat/completionasync"
    #                 Body   = @{
    #                     "engagementCode"       = "803000012512"
    #                     "messages"             = @( @{
    #                         "role"     = "user"
    #                             "content"  = "Explain the image?"
    #                             "imageUrls" = $imageUrlArray
    #                     } )
    #                     "maxTokens"            = "10"
    #                     "frequencyPenalty"     = "1"
    #                     "appendTrailingWhitespaceToStop" = $true

    #                 } | ConvertTo-Json -Depth 10
    #             }
    #             $response = @{}
    #             $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true
    #             Write-Host "Should return 400 error"
    #             $response.ExceptionResponse.StatusCode.value__ | Should -be 400
    #             Write-Host "Error Message ----" $response.ErrorDetails.message | ConvertFrom-Json
    #             # $($response.ErrorDetails.message)
    #             # # $ErrorMessage = $response.ErrorDetails.message | ConvertFrom-Json
    #             # $($response.ErrorDetails.message | ConvertFrom-Json) | Should -contains "These ImageUrls are not valid - '#%%(@*'."
    #         }

    #         It "Test Case 327455: ST_TC_DM_310796:(Negative TC) Verify error is thrown when inputting special characters in  image url for models with vision capability for System Role- Chat Completion Async" {
    #             Write-Host "Inputtin special characters in image url for User role- Chat Completion"
    #             $imageUrlArray = @("#%%(@*.pdf")
    #             $requestParams = @{
    #                 Method = 'POST'
    #                 Uri    = "/workspace/api/v1/ai/deployment/gpt-4-vision-preview/chat/completionasync"
    #                 Body   = @{
    #                     "engagementCode"       = "803000012512"
    #                     "messages"             = @( @{
    #                         "role"     = "system"
    #                             "content"  = "Explain the image?"
    #                             "imageUrls" = $imageUrlArray
    #                     } )
    #                     "maxTokens"            = "10"
    #                     "frequencyPenalty"     = "1"
    #                     "appendTrailingWhitespaceToStop" = $true
    #                 } | ConvertTo-Json -Depth 10
    #             }
    #             $response = @{}
    #             $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true
    #             Write-Host "Should return 400 error"
    #             $response.ExceptionResponse.StatusCode.value__ | Should -be 400
    #             Write-Host "Error Message ----" $response.ErrorDetails.message | ConvertFrom-Json
    #             # $ErrorMessage = $response.ErrorDetails.message | ConvertFrom-Json
    #             # $($response.ErrorDetails.message | ConvertFrom-Json) | Should -be "These ImageUrls are not valid - '#%%(@*.pdf'."
    #         }

    #     }


    # }
}
