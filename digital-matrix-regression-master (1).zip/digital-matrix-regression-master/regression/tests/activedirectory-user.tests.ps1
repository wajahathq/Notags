﻿param(

  [Parameter(Mandatory)]
  [ValidateNotNullOrEmpty()]
  $CurrentEnvironmentData

)

Describe "ADD User | Testcase related to User- AD" -Tag "User" {

  BeforeAll {

    $service = "ad"
    $memberUserIdContext = (New-Guid).Guid.ToString().Substring(0, 8)

    Write-Host "Creating user..."
    # Create a user

    $memberUserResult = Create-User $CurrentEnvironmentData $memberUserIdContext
    $memberUserId = $memberUserResult.taskOutput.userId

    FailEarly 'Validate initial user created.' {
      $memberUserResult.status | Should -Be "Completed"
    }

    Write-Host "Retrieving user..."
    $requestParams = @{
      Method = 'GET'
      Uri    = "/$($service)/api/v1/user/id/$($memberUserId)"
    }

    $retrieveResponse = $null
    $retrieveResponse = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true $true 5

    FailEarly "Validate initial user '$($memberUserId)' retrieved." {
      $retrieveResponse.userPrincipalName | Should -not -BeNullOrEmpty
    }

    $Username = $retrieveResponse.firstName
    $UserPrincipalName = $retrieveResponse.userPrincipalName
    $accountType = $retrieveResponse.accountType
    $updateEmail = $retrieveResponse.emailAddress

    Write-Host "Retrieving the user using the user principal name------"
    $requestParams = @{
      Method = 'GET'
      Uri    = "/ad/api/v1/user/userprincipalname/$($UserPrincipalName)"
    }

    $userPrincipalresponse = @{}
    $userPrincipalresponse = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true
  }

  It "checking duplicacy fir user  some values" {
    Write-Host "Creating duplicate user..."

    $service = "ad"

    # Create duplicate user
    $userName = "test-pester-$($memberUserIdContext)"
    $userPrincipalName = "$($userName)@$($CurrentEnvironmentData.Domain)"
    $alternateEmailAddress = "$($userName)@$($CurrentEnvironmentData.Domain)"
    $mailNickname = "$($userName)"
    $displayName = "$($userName) display"
    $firstName = "$($userName)"
    $lastname = "lastname"
    $emailAddress = "$($userName)@$($CurrentEnvironmentData.Domain)"
    $password = Get-RandomPassword

    $requestParams = @{
      Method = 'POST'
      Uri    = "/$($service)/api/v1/user"
      Body   = @{
        "userPrincipalName"     = "$($userPrincipalName)"
        "password"              = "$($password)"
        "alternateEmailAddress" = "$($alternateEmailAddress)"
        "mailNickname"          = "$($mailNickname)"
        "mobilePhone"           = "+15621234567"
        "displayName"           = "$($displayName)"
        "firstName"             = "$($firstName)"
        "lastname"              = "$($lastname)"
        "emailAddress"          = "$($emailAddress)"

      } | ConvertTo-Json
    }

    $response = @{}
    $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true

    $response.ExceptionResponse.StatusCode.value__ | should -be 409
  }

  It "Should return body with some values" {
    $userPrincipalresponse | Should -not -BeNullOrEmpty
  }

  It "Should return response having the userPrincipal name" {
    $userPrincipalresponse.userPrincipalName | Should -eq $($UserPrincipalName)
  }

  It "should return the same instance of the user object" {
    $retrieveResponse.id | Should -Be $memberUserId
  }

  It "should add user type group member in less than 60 seconds" {
      ([timespan]($memberUserResult.duration)).Seconds | Should -BeLessOrEqual 60
  }
  It "should return the expected status when adding group member to group" {
    $memberUserResult.status | Should -Be "Completed"
  }

  It "should return the expected activity type when adding group member to group" {
    $memberUserResult.taskOutput.activityType | Should -Be "CreateUser"
  }

  It "Should have account type as cloud native account" {
    $($retrieveResponse.accountType) | Should -be $accountType
  }


  Context "DM_AD_API_20_02 | /api/v1/user/userprincipalname/{userPrincipalName}|Search By Invalid User Principal Name" {
    BeforeAll {


      $userprincipalname = "invalid@kpmgusadvspectrum.onmicrosoft.com"
      $requestParams = @{
        Method = 'GET'
        Uri    = "/ad/api/v1/user/userprincipalname/$([uri]::EscapeDataString($userprincipalname))"
      }

      $response = @{}
      $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true

    }

    It "Should return 404" {
      $response.ExceptionResponse.StatusCode.value__ | should -be 404
    }

    It "Should return response" {
      $response.ErrorDetails.Message | Should -contain "User with principal name was not found: $($userprincipalname)"

    }
  }

  Context "DM_AD_API_20_03 | /api/v1/user/userprincipalname/{userPrincipalName}|Search By Invalid User Principal Name having Speical char" {
    BeforeAll {


      $userprincipalname = "Name'@#%^"
      $requestParams = @{
        Method = 'GET'
        Uri    = "/ad/api/v1/user/userprincipalname/$([uri]::EscapeDataString($userprincipalname))"
      }

      $response = @{}
      $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true

    }

    It "Should return 400 Bad Request" {
      $response.ExceptionResponse.StatusCode.value__ | should -be 400
    }

    It "Should return response" {
      $response.ErrorDetails.Message | Should -contain "User Principal Name contains an invalid character."

    }
  }

  Context "DM_AD_API_20_04 | /api/v1/user/userprincipalname/{userPrincipalName}|Search By Invalid Numeric User Principal Name" {
    BeforeAll {


      $userprincipalname = "12353563"
      $requestParams = @{
        Method = 'GET'
        Uri    = "/ad/api/v1/user/userprincipalname/$([uri]::EscapeDataString($userprincipalname))"
      }

      $response = @{}
      $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true

    }

    It "Should return 404 Bad Request" {
      $response.ExceptionResponse.StatusCode.value__ | should -be 404
    }

    It "Should return response" {
      $response.ErrorDetails.Message | Should -contain "User with principal name was not found: $($userprincipalname)"

    }
  }

  Context "DM_AD_API_36_09 | Creating User without mailNickname" {
    BeforeAll {
      # Creating user with missing mailNickname
      $service = "ad"
      $contextId = (New-Guid).Guid
      $userName = "test-pester-$($contextId)"
      $userPrincipalName = "$($userName)@$($CurrentEnvironmentData.Domain)"
      $alternateEmailAddress = "$($userName)@$($CurrentEnvironmentData.Domain)"
      $displayName = "$($userName) display"
      $firstName = "$($userName)"
      $lastname = "lastname"
      $emailAddress = "$($userName)@$($CurrentEnvironmentData.Domain)"
      $password = Get-RandomPassword

      $requestParams = @{
        Method = 'POST'
        Uri    = "/$($service)/api/v1/user"
        Body   = @{
          "userPrincipalName"     = "$($userPrincipalName)"
          "password"              = "$($password)"
          "alternateEmailAddress" = "$($alternateEmailAddress)"
          "mobilePhone"           = "+15621234567"
          "displayName"           = "$($displayName)"
          "firstName"             = "$($firstName)"
          "lastname"              = "$($lastname)"
          "emailAddress"          = "$($emailAddress)"

        } | ConvertTo-Json
      }

      $response = @{}
      $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true

    }

    It "Should return 400 Bad Request for missing mailNickname" {
      $response.ExceptionResponse.StatusCode.value__ | should -be 400
    }

    It "Should return proper error message for missing mailNickname" {
      $response.ErrorDetails.errors.MailNickname | Should -contain "The MailNickname field is required."
    }

    AfterAll {

    }

  }

  Context "DM_AD_API_36_10 | Creating User without alternateEmailAddress" {
    BeforeAll {
      # Creating user with missing alternateEmailAddress
      $service = "ad"
      $contextId = (New-Guid).Guid.ToString().Substring(0, 8)
      $userName = "test-pester-$($contextId)"
      $userPrincipalName = "$($userName)@$($CurrentEnvironmentData.Domain)"
      $mailNickname = "$($userName)"
      $displayName = "$($userName) display"
      $firstName = "$($userName)"
      $lastname = "lastname"
      $emailAddress = "$($userName)@$($CurrentEnvironmentData.Domain)"
      $password = Get-RandomPassword

      $requestParams = @{
        Method = 'POST'
        Uri    = "/$($service)/api/v1/user"
        Body   = @{
          "userPrincipalName" = "$($userPrincipalName)"
          "password"          = "$($password)"
          "mailNickname"      = "$($mailNickname)"
          "mobilePhone"       = "+15621234567"
          "displayName"       = "$($displayName)"
          "firstName"         = "$($firstName)"
          "lastname"          = "$($lastname)"
          "emailAddress"      = "$($emailAddress)"

        } | ConvertTo-Json
      }

      $response = @{}
      $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true

    }

    It "Should return 400 Bad Request for missing alternateEmailAddress" {
      $response.ExceptionResponse.StatusCode.value__ | should -be 400
    }

    It "Should return proper error message for missing alternateEmailAddress" {
      $response.ErrorDetails.errors.AlternateEmailAddress | Should -contain "The AlternateEmailAddress field is required."
    }

    AfterAll {

    }


  }

  Context "DM_AD_API_36_11 | Creating User without displayName" {
    BeforeAll {
      # Creating user with missing displayName
      $service = "ad"
      $contextId = (New-Guid).Guid.ToString().Substring(0, 8)
      $userName = "test-pester-$($contextId)"
      $userPrincipalName = "$($userName)@$($CurrentEnvironmentData.Domain)"
      $alternateEmailAddress = "$($userName)@$($CurrentEnvironmentData.Domain)"
      $mailNickname = "$($userName)"
      $firstName = "$($userName)"
      $lastname = "lastname"
      $emailAddress = "$($userName)@$($CurrentEnvironmentData.Domain)"
      $password = Get-RandomPassword

      $requestParams = @{
        Method = 'POST'
        Uri    = "/$($service)/api/v1/user"
        Body   = @{
          "userPrincipalName"     = "$($userPrincipalName)"
          "password"              = "$($password)"
          "alternateEmailAddress" = "$($alternateEmailAddress)"
          "mailNickname"          = "$($mailNickname)"
          "mobilePhone"           = "+15621234567"
          "firstName"             = "$($firstName)"
          "lastname"              = "$($lastname)"
          "emailAddress"          = "$($emailAddress)"

        } | ConvertTo-Json
      }

      $response = @{}
      $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true

    }

    It "Should return 400 Bad Request for missing displayName" {
      $response.ExceptionResponse.StatusCode.value__ | should -be 400
    }

    It "Should return proper error message for missing displayName" {
      $response.ErrorDetails.errors.DisplayName | Should -contain "The DisplayName field is required."
    }

    AfterAll {

    }


  }

  Context "DM_AD_API_36_12 | Creating User with userPrincipalName in a password" {
    BeforeAll {
      #Should throw error when $userPrincipalName is inserted in password field..
      $service = "ad"
      $contextId = (New-Guid).Guid.ToString().Substring(0, 8)
      $userName = "test-pester-$($contextId)"
      $userPrincipalName = "$($userName)@$($CurrentEnvironmentData.Domain)"
      $alternateEmailAddress = "$($userName)@$($CurrentEnvironmentData.Domain)"
      $mailNickname = "$($userName)"
      $displayName = "$($userName) display"
      $firstName = "$($userName)"
      $lastname = "lastname"
      $emailAddress = "$($userName)@$($CurrentEnvironmentData.Domain)"

      $requestParams = @{
        Method = 'POST'
        Uri    = "/$($service)/api/v1/user"
        Body   = @{
          "userPrincipalName"     = "$($userPrincipalName)"
          "alternateEmailAddress" = "$($alternateEmailAddress)"
          "mailNickname"          = "$($mailNickname)"
          "mobilePhone"           = "+15621234567"
          "displayName"           = "$($displayName)"
          "firstName"             = "$($firstName)"
          "lastname"              = "$($lastname)"
          "emailAddress"          = "$($emailAddress)"
          "password"              = "$($userPrincipalName)"

        } | ConvertTo-Json
      }

      $response = @{}
      $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true

    }

    It "Should return 400 Bad Request for missing password" {
      $response.ExceptionResponse.StatusCode.value__ | should -be 400
    }

    It "Should return proper error message for Invalid password" {
      $response.ErrorDetails.errors.Password | Should -contain "Strong password required. Enter 8-256 characters. Do not include common words or names. Combine uppercase letters, lowercase letters, numbers and symbols."
    }

  }

  Context "DM_AD_API_36_13 | Creating User without userPrincipalName" {
    BeforeAll {
      # Creating user with missing userPrincipalName
      $service = "ad"
      $contextId = (New-Guid).Guid.ToString().Substring(0, 8)
      $userName = "test-pester-$($contextId)"
      $alternateEmailAddress = "$($userName)@$($CurrentEnvironmentData.Domain)"
      $mailNickname = "$($userName)"
      $displayName = "$($userName) display"
      $firstName = "$($userName)"
      $lastname = "lastname"
      $emailAddress = "$($userName)@$($CurrentEnvironmentData.Domain)"
      $password = Get-RandomPassword

      $requestParams = @{
        Method = 'POST'
        Uri    = "/$($service)/api/v1/user"
        Body   = @{
          "password"              = "$($password)"
          "alternateEmailAddress" = "$($alternateEmailAddress)"
          "mailNickname"          = "$($mailNickname)"
          "mobilePhone"           = "+15621234567"
          "displayName"           = "$($displayName)"
          "firstName"             = "$($firstName)"
          "lastname"              = "$($lastname)"
          "emailAddress"          = "$($emailAddress)"

        } | ConvertTo-Json
      }

      $response = @{}
      $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true

    }

    It "Should return 400 Bad Request for missing userPrincipalName" {
      $response.ExceptionResponse.StatusCode.value__ | should -be 400
    }

    It "Should return proper error message for missing userPrincipalName" {
      $response.ErrorDetails.errors.UserPrincipalName | Should -contain "The UserPrincipalName field is required."
    }

    AfterAll {

    }


  }

  # Added Testcase Related to GUEST User
  Context " POST /api/v1/user/guest | Creates external/guest user" {
    #forExternal Guest user the Domain can be anything(expect kpmg.com)
    Context "DM_AD_API_23_01-23_31 | Create External Guest User" {
      BeforeAll {
        Write-Host "Create a External USER using same name as User name"
        $requestParams = @{
          Method = 'POST'
          Uri    = "/$($service)/api/v1/user/guest"
          Body   = @{
            "emailAddress" = "$($Username)@externalUser.com"

          } | ConvertTo-Json

        }
        $Guestuserresponse = $null
        $Guestuserresponse = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true

        $createTaskResult = $null
        $createTaskResult = Get-BackgroundStatus $CurrentEnvironmentData $Guestuserresponse.taskId "$($service)"
        $ExternalmemberUserId = $createTaskResult.taskOutput.userId

        FailEarly "Validate External Guest User '$($Username)' created." {
          $createTaskResult.status | Should -Be "Completed"
        }

        Write-Host "Retrieving user..."
        $requestParams = @{
          Method = 'GET'
          Uri    = "/$($service)/api/v1/user/id/$($ExternalmemberUserId)"
        }

        $retrieveResponse = $null
        $retrieveResponse = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true $true 5

        FailEarly "Validate External Guest User '$($ExternalmemberUserId)' retrieved." {
          $retrieveResponse.id | Should -not -BeNullOrEmpty
        }

        #Resends an invitation to the specified guest user email

        $emailAddressValue = $retrieveResponse.emailAddress

        Write-Host "Resending an invitation to the external guest user email"
        $requestParams = @{
          Method = 'POST'
          Uri    = "/$($service)/api/v1/user/guest/resendinvitation"
          Body   = @{
            "emailAddress" = $($emailAddressValue)

          } | ConvertTo-Json

        }

        $ResendResponse = @{}
        $ResendResponse = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true

      }

      It "Should return 200 response code for resend invitation to guest user" {
        $ResendResponse | Should -not -BeNullOrEmpty
      }
      It "should add user type group member in less than 60 seconds" {
        ([timespan]($createTaskResult.duration)).Seconds | Should -BeLessOrEqual 60
      }
      It "should return the expected status when adding group member to group" {
        $createTaskResult.status | Should -Be "Completed"
      }

      It "should return the expected activity type when adding group member to group" {
        $createTaskResult.taskOutput.activityType | Should -Be "CreateGuestUser"
      }

      It "should return the same instance of the user object" {
        $retrieveResponse.id | Should -Be $ExternalmemberUserId
      }
    }

    Context "DM_AD_API_38_658 and DM_AD_API_38_660 | Resend invitation to internal guest user" {
      BeforeAll {
        Write-Host "CREATING INTERNAL CLOUD NATIVE ACCOUNT FOR RESEND INVITATION PURPOSE"
        $contextId = (New-Guid).Guid.ToString().Substring(0, 8)
        $userName = "test-pester-$($contextId)"
        $userPrincipalName = "$($userName)@$($CurrentEnvironmentData.Domain)"
        $alternateEmailAddress = "$($userName)@kpmg.com"
        $mailNickname = "$($userName)"
        $displayName = "$($userName) display"
        $firstName = "$($userName)"
        $lastname = "lastname"
        $emailAddress = "$($userName)@$($CurrentEnvironmentData.Domain)"
        $password = Get-RandomPassword

        $requestParams = @{
          Method = 'POST'
          Uri    = "/ad/api/v1/user"
          Body   = @{
            "userPrincipalName"     = "$($userPrincipalName)"
            "password"              = "$($password)"
            "alternateEmailAddress" = "$($alternateEmailAddress)"
            "mailNickname"          = "$($mailNickname)"
            "mobilePhone"           = "+15621234567"
            "displayName"           = "$($displayName)"
            "firstName"             = "$($firstName)"
            "lastname"              = "$($lastname)"
            "emailAddress"          = "$($emailAddress)"

          } | ConvertTo-Json
        }

        $createUserResponse = @{}
        $createUserResponse = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true

        $createTaskResult = @{}
        $createTaskResult = Get-BackgroundStatus $CurrentEnvironmentData $createUserResponse.taskId "$($service)"
        $AdUserIDResponse = $createTaskResult.taskOutput.userId

        Write-Host "RETRIEVING THE AD RESPONSE"
        $requestParams = @{
          Method = 'GET'
          Uri    = "/ad/api/v1/user/id/$($AdUserIDResponse)"
        }

        $AdEmailResponse = $null
        $AdEmailResponse = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true
        $InternalMailAddress = $AdEmailResponse.alternateEmailAddress

        Write-Host "CREATING INTERNAL GUEST USER"
        $requestParams = @{
          Method = 'POST'
          Uri    = "/$($service)/api/v1/user/guest"
          Body   = @{

            "emailAddress" = "$($InternalMailAddress)"

          } | ConvertTo-Json
        }

        $GuestResponse = @{}
        $GuestResponse = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true

        $GuestTaskResult = @{}
        $GuestTaskResult = Get-BackgroundStatus $CurrentEnvironmentData $GuestResponse.taskId "$($service)"
        $InternalGuestUserId = $GuestTaskResult.taskOutput.userId

        Write-Host "RETRIEVING INTERNAL GUEST USER RESPONSE"
        $requestParams = @{
          Method = 'GET'
          Uri    = "/ad/api/v1/user/id/$($InternalGuestUserId)"
        }

        $GuestUserResponse = @{}
        $GuestUserResponse = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true
        $GuestUserMailid = $GuestUserResponse.emailAddress

        Write-Host "Resending invitation to the internal guest user"
        $requestParams = @{
          Method = 'POST'
          Uri    = "/ad/api/v1/user/guest/resendinvitation"
          Body   = @{
            "emailAddress" = "$($GuestUserMailid)"

          } | ConvertTo-Json

        }

        $ResendForInternalResponse = @{}
        $ResendForInternalResponse = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true
      }

      It "Should resend invitation for internal guest user" {
        $ResendForInternalResponse.userId | should -Match -RegularExpression "^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[0-9a-f]{4}-[0-9a-f]{12}$"
      }
      AfterAll {

        Write-Host "Deleting the internal guest user for resend invitation"
        $requestParams = @{
          Method = 'DELETE'
          Uri    = "/ad/api/v1/user/$($InternalGuestUserId)"
        }

        $DeleteGuestResponse = @{}
        $DeleteGuestResponse = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true

        $DeleteGuestResult = @{}
        $DeleteGuestResult = Get-BackgroundStatus $CurrentEnvironmentData $DeleteGuestResponse.taskId "$($service)"
      }


    }

    Context "DM_AD_API_23_32 | Create Guest user with already existing email Id - Negative TC" {
      BeforeAll {
        Write-Host "Executing the same guest user with same emailId"
        $requestParams = @{
          Method = 'POST'
          Uri    = "/$($service)/api/v1/user/guest"
          Body   = @{
            "emailAddress" = "$($emailAddressValue)"

          } | ConvertTo-Json

        }
        $response = @{}
        $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true
      }

      It "Should return 400 status code for resending the same guest user with same emailId" {
        $response.ExceptionResponse.StatusCode.value__ | should -be 400
      }

      AfterAll {

      }

    }

    Context "DM_AD_API_38_656 | Resend invitation to guestuser with missing emailId - Negative TC" {
      BeforeAll {

        $requestParams = @{
          Method = 'POST'
          Uri    = "/$($service)/api/v1/user/guest/resendinvitation"
          Body   = @{
            "emailAddress" = ""

          } | ConvertTo-Json

        }

        $response = @{}
        $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true

      }

      It "Should return 400 Bad Request for missing emailId to resend invitation" {
        $response.ExceptionResponse.StatusCode.value__ | should -be 400
      }

      It "Should return proper error message for missing emailId to resend invitation" {
        $response.ErrorDetails.errors.EmailAddress | Should -contain "The EmailAddress field is required."
      }
    }

    Context "DM_AD_API_38_657 - DM_AD_API_38_662 | Resend invitation to guestuser which doesnot have guestuser account - Negative TC" {
      BeforeAll {

        #Resends an invitation to the specified guestuser which doesnot have guestuser account - Negative TC

        $requestParams = @{
          Method = 'POST'
          Uri    = "/$($service)/api/v1/user/guest/resendinvitation"
          Body   = @{
            "emailAddress" = "abc@externalUser.com"

          } | ConvertTo-Json

        }

        $response = @{}
        $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true

      }

      It "Should return 400 Bad Request which doesnot have guestuser account" {
        $response.ExceptionResponse.StatusCode.value__ | should -be 400
      }

      It "Should return proper error message which doesnot have guestuser account" {
        $response.ErrorDetails.message | Should -contain "The email address you specified does not belong to a guest account"
      }
    }

    <#Context "DM_AD_API_DM_AD_API_23_32 | Verify Duplicate External Guest User" {
      BeforeAll {
        Write-Host "Create a External USER using same name as User name"
        $requestParams = @{
          Method = 'POST'
          Uri    = "/$($service)/api/v1/user/guest"
          Body   = @{
            "emailAddress" = "$($Username)@externalUser.com"

          } | ConvertTo-Json

        }
        $Guestuserresponse = $null
        $Guestuserresponse = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true

        $createTaskResult = $null
        $createTaskResult = Get-BackgroundStatus $CurrentEnvironmentData $Guestuserresponse.taskId "$($service)"


      }

      It "should add user type group member in less than 60 seconds" {
             ([timespan]($createTaskResult.duration)).Seconds | Should -BeLessOrEqual 60
      }
      It "should return the expected status when adding group member to group" {
        $createTaskResult.status | Should -Be "Failed"
      }

      It "should return the expected activity type when adding group member to group" {
        $createTaskResult.taskOutput.activityType | Should -Be "CreateGuestUser"
      }

      It "should return the same instance of the user object" {
        $createTaskResult.output | Should -Contain "Non-external user already exists with the given mail address and can't be invited."
      }
    }#>
  }

  Describe "Validations for User First and Last name while updating the user." {
    Context "Update the user's first name and last name with an empty string"  {
      BeforeALL{
        Write-Host "Update User's first name and last name"
        $requestParams = @{
          Method = 'PUT'
          Uri    = "/ad/api/v1/user/$($memberUserId)"
          Body   = @{
            "firstName" = ""
             "lastlastName" = ""
          } | ConvertTo-Json
        }
        $response = @{}
        $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true
      }
      It "Test Case 321067: ST_TC_DM_312857:(Positive TC) Verify that updating the user's first name and last name with an empty string is not allowed."{
        Write-Host "Should return 400 error"
        $response.ExceptionResponse.StatusCode.value__ | Should -be 400
      }
    }
    Context "Update the user's first name and last name as Null" {
      BeforeALL{
        Write-Host "Update User's first name and last name as Null"
        $requestParams = @{
          Method = 'PUT'
          Uri    = "/ad/api/v1/user/$($memberUserId)"
          Body   = @{
            "firstName" = "Null"
             "lastlastName" = "Null"
          } | ConvertTo-Json
        }
        $afterUpdatingUserResponse = $null
        $afterUpdatingUserResponse = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true

        $updatedUserResult = @{}
        $updatedUserResult = Get-BackgroundStatus $CurrentEnvironmentData $afterUpdatingUserResponse.taskId "$($service)"

      }
      It "Test Case 321066: ST_TC_DM_312857:(Positive TC) Verify whether updating the user's first name and last name as null is allowed." {
        Write-Host "User first name and last name should be updated as null"
        Write-Host "--Response TaskId -- $($afterUpdatingUserResponse[0].taskId)"
        $afterUpdatingUserResponse[0].taskId | Should -not -BeNullOrEmpty
      }
      It "Validation of User first name is updated as Null" {
        Write-Host "Retrieving the updated value in Get User method"
        $firstNameValue ="Null"
        $requestParams = @{
          Method = 'GET'
          Uri    = "/ad/api/v1/user/id/$($memberUserId)"
        }
        $response = $null
        $response = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true
        Write-Host "--First name value ---$($response[0].firstName)"
       $response[0].firstName | should -eq $firstNameValue
      }

    }
  }






  AfterAll {

    #delete member user

    Delete-User $CurrentEnvironmentData $memberUserId
  }

}

