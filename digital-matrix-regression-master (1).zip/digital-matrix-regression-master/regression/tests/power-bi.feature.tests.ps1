[CmdletBinding()]
param(

    [Parameter(Mandatory)]
    [ValidateNotNullOrEmpty()]
    $CurrentEnvironmentData

)

Describe "PBI" -Tag "Feature" {

    #forEach Feature name where Flag is true            
    Context "DM_PowerBI_API_01_00-DM_PowerBI_API_01-114|Test for Flag and its response value" {

        $scope = "https://analysis.windows.net/powerbi/api/.default"
        $script:envData = GetOBOEnvironmentData $CurrentEnvironmentData $scope
        #Write-Host "ENV DATA IS ---  $envData"
        $service = "powerbi"
                
        Write-Host "BeforeAll POST /api/v1/group - context id $($contextId)"

        Write-Host "Retrieving  feature for includeCodeFlags = FALSE"
        $requestParams = @{
            Method = 'GET'
            Uri    = "/$($service)/api/v1/feature?includeCodeFlags=false"                       

        } 
        
        $retrieveResponseFlagFalse = $null
        $retrieveResponseFlagFalse = Invoke-RestMethodAuthWrapper $envData $requestParams $true $true 5    
        #Write-Host "Response is $($retrieveResponseFlagFalse.featureName)"

        ############################################
                
        Write-Host "Retrieving  feature for includeCodeFlags = true"
        $requestParams = @{
            Method = 'GET'
            Uri    = "/$($service)/api/v1/feature?includeCodeFlags=true"                       

        } 
            
        $retrieveResponseFlagtrue = @{}
        $retrieveResponseFlagtrue = Invoke-RestMethodAuthWrapper $envData $requestParams $true $true 5    
        Write-Host "Response COUNT $($retrieveResponseFlagtrue.featureName.count)"
    
        Write-Host "Response TRUE $($retrieveResponseFlagtrue.featureName)"
        Write-Host "Response FALSE $($retrieveResponseFlagfalse.featureName)"
        
        <#It "should return TRUE FLAG response that is not null or empty" {
            $retrieveResponseFlagtrue.featureName.count | Should -BeGreaterThan 0
        }

        It "should return for FALSE FLAG response that is not null or empty" {
            $retrieveResponseFlagFalse.count | Should -BeGreaterThan 0
        }>#>        
        foreach ($item in $retrieveResponseFlagtrue.featureName) {
            $requestParams = @{
                Method = 'GET'
                Uri    = "/$($service)/api/v1/feature/$item"                
            }
            $response = @{}
            $response = Invoke-RestMethodAuthWrapper $envData $requestParams $true
            Write-Host "Response is $($response)"
            
            #It "Should not return null" {                               
            #  $response | Should -not -BeNullOrEmpty
            #} 
            It "Should return exact match Where Flag is True for featureName $($item) " {
                foreach ($item in $retrieveResponseFlagtrue.featureName) {
                    $($response) | Should -be $($item.isEnabled)
                }
            }
        }

        # for all the Feature where Flag value is False 
        foreach ($item in $retrieveResponseFlagFalse.featureName) {
            $requestParams = @{
                Method = 'GET'
                Uri    = "/$($service)/api/v1/feature/$item"                
            }
            $response = @{}
            $response = Invoke-RestMethodAuthWrapper $envData $requestParams $true
            Write-Host "Response is $($response)"
                
            #It "Should not return null" {                               
            #  $response | Should -not -BeNullOrEmpty
            #} 
            It "Should return exact match Where Flag is False for featureName $($item) " {
                foreach ($item in $retrieveResponseFlagFalse.featureName) {
                    $($response) | Should -be $($item.isEnabled)
                }
            }
        }

        
        AfterAll {}
    }
}