﻿param(

  [Parameter(Mandatory)]
  [ValidateNotNullOrEmpty()]
  $CurrentEnvironmentData

)

Describe "Workspace" -Tag "Engagement" {
    Context "GET /api/v1/engagement/{engagementNumber}" {
        Context "DM_Workspace_API_33_12 | Gets all engagements and search by engagement number" {
          
        
            $requestParams = @{
                Method = 'GET'
                Uri    = "/workspace/api/v1/engagement"                
            }
    
            $EngagementresponseList = @{}
            $EngagementresponseList = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true
            #Write-Host "List of Roles in Response is ---- $($RoleresponseList.name)"
            
            foreach ($item in $EngagementresponseList.engagementNumber[0]) {
                    
                $requestParams = @{
                    Method = 'GET'
                    Uri    = "/workspace/api/v1/engagement/$($item)"                
                }
                $response = @{}
                $response = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true
                Write-Host "Value in $($response.engagementNumber) should be eq to  $($item)"
    
                It "Should not Null" {  
                    $EngagementresponseList.count |  Should -not -BeNullOrEmpty
                } 
                
                It "should match with the engagement number" {  
                    $response.engagementNumber | Should -be $($item)
                }
    
            }
    
        }
     #With Invalid Engagement number 
    Context "DM_Workspace_API_33_13 | Non-existing engagementNumber" {
      BeforeAll {

        $engagementNumber = "@@number12345^#%-"

        $requestParams = @{
          Method = 'GET'
          Uri = "/workspace/api/v1/engagement/$([uri]::EscapeDataString($engagementNumber))"
        }

        $response = @{}

        # we know this will return something other than a 200 response, so we're using the special error handler method
        $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true

      }
      It "Should return 404" {
        $response.ExceptionResponse.StatusCode.value__ | Should -be 404
      }
      It "Should return user friendly message" {
        $response.ErrorDetails.Message | Should -be "The Engagement number $($engagementNumber) is not found."
      }
    }
  }

  Context "GET /api/v1/engagement" {
    Context "DM_Workspace_API_32_01 | Search by allColumnSearch" {
      BeforeAll {
        $requestParams = @{
          Method = 'GET'
          Uri = "/workspace/api/v1/engagement?allColumnsSearch=paid%20time"
        }

        $response = @{}
        $response = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true
      }

      It "Should not return null" {
        $response | Should -not -BeNullOrEmpty
      }

      It "Should return at least one record" {
        $response.Count | Should -BeGreaterThan 0
      }

      AfterAll {

      }
    }

    Context "DM_Workspace_API_32_01 | Search by engagementName" {
      BeforeAll {
        $requestParams = @{
          Method = 'GET'
          Uri = "/workspace/api/v1/engagement?engagementName=paid%20time"
        }

        $response = @{}
        $response = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true

        # we reset the access and refersh tokens in case they expired
        #$token = $requestPayload.accessToken
        #$refreshToken = $requestPayload.refreshToken
      }

      It "Should not return null" {
        $response | Should -not -BeNullOrEmpty
      }

      It "Should return at least one record" {
        $response.Count | Should -BeGreaterThan 0
      }

      It "Should match search" {
        foreach ($engagement in $response) {
          $engagement.engagementName | Should -Match "paid time"
        }
      }

      AfterAll {

      }
    }
    # Search with Engagement number and Engagement Name
    Context "DM_Workspace_API_32_03 | search by engagement number and Engagement name" {                             
        $requestParams = @{
            Method = 'GET'
            Uri    = "/workspace/api/v1/engagement"                
        }

        $EngagementresponseList = @{}
        $EngagementresponseList = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true
        It "Should not Null" {  
            $EngagementresponseList.count |  Should -not -BeNullOrEmpty
        } 
        foreach ($item in $EngagementresponseList.engagementNumber[0]) {

            foreach ($item1 in $EngagementresponseList.engagementName[0]) {
                Write-Host "Filtering with engagement number -$($item) and engagementName-$($item1)"
                $requestParams = @{
                    Method = 'GET'
                    Uri    = "/workspace/api/v1/engagement?engagementNumber=$($item)&engagementName=$($item1)"                     
                }

                $response = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true 
                #$ResponseArray = @()
                
                if ($response.engagementNumber -eq $($item) -and $response.engagementName -eq $($item1)) {
                        
                    It "Engagement number should match with the response for EngagementNumber -$($item) " {   
                        $($response.engagementNumber) | should -eq $($item)  
                    }
                           
                    It "The engagementName should match with the response for EngagementName -$($item1)" {  
                        $($response.engagementName) | should -eq $($item1)    
                    }
                        
                }
                else {
                    It "should have 200 OK with null response" {   
                        $response| should -BeNullOrEmpty     
                    }
                }
                    
            }
                
        }
    }
        
        Context "DM_Workspace_API_32_04" {
            BeforeAll {
                $requestParams = @{
                    Method  = 'GET'
                    Uri     = "/workspace/api/v1/engagement?engagementName=paid%20time"
                }
                
                $response = @{}
                $response = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true

                # we reset the access and refersh tokens in case they expired
                #$token = $requestPayload.accessToken
                #$refreshToken = $requestPayload.refreshToken
            }         
        
            It "DM_Workspace_API_32_04 - Should not return null" {                               
                $response | Should -not -BeNullOrEmpty
            }   
        
            It "DM_Workspace_API_32_04 - Should return at least one record" {
                $response.Count | Should -BeGreaterThan 0
            }
        
            It "DM_Workspace_API_32_04 - Should match search" {
                foreach ($engagement in $response) {
                    $engagement.engagementName | Should -Match "paid time"
                }
            }

            AfterAll {
          
            }
        }

Context "DM_Workspace_API_32_05" {
            BeforeAll {
                $requestParams = @{
                    Method  = 'GET'
                    Uri     = "/workspace/api/v1/engagement?engagementManagerName=Panosh%2CAditi%20Reddy"
                }
                
                $response = @{}
                $response = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true
                
                # we reset the access and refersh tokens in case they expired
                #$token = $requestPayload.accessToken
                #$refreshToken = $requestPayload.refreshToken
            }         
        
            #It "DM_Workspace_API_32_05 - Should not return null" {                               
               # $response | Should -not -BeNullOrEmpty
            #}              
        

            It "DM_Workspace_API_32_05 - Should match search" {
                foreach ($engagement in $response) {
                    $engagement.engagementManagerName | Should -Match "Panosh,Aditi Reddy"
                }
            
            }

            AfterAll {
          
            }
        }

        Context "DM_Workspace_API_32_06" {
            BeforeAll {
                $requestParams = @{
                    Method  = 'GET'
                    Uri     = "/workspace/api/v1/engagement?engagementManagerEmail=apanosh%40kpmg.com"
                }
                
                $response = @{}
                $response = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true
                
                # we reset the access and refersh tokens in case they expired
                #$token = $requestPayload.accessToken
                #$refreshToken = $requestPayload.refreshToken
            }         
        
            #It "DM_Workspace_API_32_06 - Should not return null" {                               
                #$response | Should -not -BeNullOrEmpty
           # }              
        

            It "DM_Workspace_API_32_06 - Should match search" {
                foreach ($engagement in $response) {
                    $engagement.engagementManagerEmailAddress | Should -Match "apanosh@kpmg.com"
                }
            
            }

            AfterAll {
          
            }
        }

Context "DM_Workspace_API_32_07" {
            BeforeAll {
                $requestParams = @{
                    Method  = 'GET'
                    Uri     = "/workspace/api/v1/engagement?engagementPartnerName=Bracken%2CMeghan%20B"
                }
                
                $response = @{}
                $response = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true
                
                # we reset the access and refersh tokens in case they expired
                #$token = $requestPayload.accessToken
                #$refreshToken = $requestPayload.refreshToken
            }         
        
           # It "DM_Workspace_API_32_07 - Should not return null" {                               
              #  $response | Should -not -BeNullOrEmpty
           # }              
        

            It "DM_Workspace_API_32_07 - Should match search" {
                foreach ($engagement in $response) {
                    $engagement.engagementPartnerName | Should -Match "Bracken,Meghan B"
                }
            
            }

            AfterAll {
          
            }
        }

Context "DM_Workspace_API_32_08" {
            BeforeAll {
                $requestParams = @{
                    Method  = 'GET'
                    Uri     = "/workspace/api/v1/engagement?engagementPartnerEmail=mbracken%40kpmg.com"
                }
                
                $response = @{}
                $response = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true
                
                # we reset the access and refersh tokens in case they expired
                #$token = $requestPayload.accessToken
                #$refreshToken = $requestPayload.refreshToken
            }         
        
           # It "DM_Workspace_API_32_08 - Should not return null" {                               
              #  $response | Should -not -BeNullOrEmpty
           # }              
        

            It "DM_Workspace_API_32_08 - Should match search" {
                foreach ($engagement in $response) {
                    $engagement.engagementPartnerEmailAddress | Should -Match "mbracken@kpmg.com"
                }
            
            }

            AfterAll {
          
            }
        }
Context "DM_Workspace_API_33_01" {
            BeforeAll {
                $requestParams = @{
                    Method  = 'GET'
                    Uri     = "/workspace/api/v1/engagement?engagementNumber=190000000043"
                }
                
                $response = @{}
                $response = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true
                
                # we reset the access and refersh tokens in case they expired
                #$token = $requestPayload.accessToken
                #$refreshToken = $requestPayload.refreshToken
            }         
        
            It "DM_Workspace_API_33_01 - Should not return null" {                               
                $response | Should -not -BeNullOrEmpty
            }              
        
            It "DM_Workspace_API_33_01 - Should return at least one record" {
                $response.engagementNumber | Should -Be "190000000043"
            }
 
            AfterAll {
          
            }
        }
Context "DM_Workspace_API_33_03" {
            BeforeAll {
                $requestParams = @{
                    Method  = 'GET'
                    Uri     = "/workspace/api/v1/engagement?engagementStatus=Frozen"
                }
                
                $response = @{}
                $response = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true

                # we reset the access and refersh tokens in case they expired
                #$token = $requestPayload.accessToken
                #$refreshToken = $requestPayload.refreshToken
            }         
        
            It "DM_Workspace_API_33_03 - Should not return null" {                               
                $response | Should -not -BeNullOrEmpty
            }  
            It "DM_Workspace_API_33_03 - Search By All Columns Should return at least one record" {
                $response.Count | Should -BeGreaterThan 0
            } 
        
        
            It "DM_Workspace_API_33_03 - Should match search" {
                foreach ($engagement in $response) {
                    $engagement.engagementStatus | Should -Match "Frozen"
                }
            }
 
            AfterAll {
          
            }
        }

        Context "DM_Workspace_API_33_04" {
            BeforeAll {
                $requestParams = @{
                    Method  = 'GET'
                    Uri     = "/workspace/api/v1/engagement?engagementStatus=Open"
                }
                
                $response = @{}
                $response = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true

                # we reset the access and refersh tokens in case they expired
                #$token = $requestPayload.accessToken
                #$refreshToken = $requestPayload.refreshToken
            }         
        
            It "DM_Workspace_API_33_04 - Should not return null" {                               
                $response | Should -not -BeNullOrEmpty
            } 
           
            It "DM_Workspace_API_33_04 - Search By All Columns Should return at least one record" {
                $response.Count | Should -BeGreaterThan 0
            }   
        
        
            It "DM_Workspace_API_33_04 - Should match search" {
                foreach ($engagement in $response) {
                    $engagement.engagementStatus | Should -Match "Open"
                }
            }
 
            AfterAll {
          
            }
        }

        Context "DM_Workspace_API_33_05" {
            BeforeAll {
                $requestParams = @{
                    Method  = 'GET'
                    Uri     = "/workspace/api/v1/engagement?clientCode=1000504840"
                }
                
                $response = @{}
                $response = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true

                # we reset the access and refersh tokens in case they expired
                #$token = $requestPayload.accessToken
                #$refreshToken = $requestPayload.refreshToken
            }         
        
            It "DM_Workspace_API_33_05 - Should not return null" {                               
                $response | Should -not -BeNullOrEmpty
            }   
        
            It "DM_Workspace_API_33_05 - Should return at least one record" {
                $response.Count | Should -BeGreaterThan 0
            }
        
            It "DM_Workspace_API_33_05 - Should match search" {
                foreach ($engagement in $response) {
                    $engagement.clientCode | Should -Match "1000504840"
                }
            }
 
            AfterAll {
          
            }
        }

        Context "DM_Workspace_API_33_06" {
            BeforeAll {
                $requestParams = @{
                    Method  = 'GET'
                    Uri     = "/workspace/api/v1/engagement?clientName=Zenkyoren%20Asset%20Management%20Of%20Ameri"
                }
                
                $response = @{}
                $response = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true

                # we reset the access and refersh tokens in case they expired
                #$token = $requestPayload.accessToken
                #$refreshToken = $requestPayload.refreshToken
            }         
        
            It "DM_Workspace_API_33_06 - Should not return null" {                               
                $response | Should -not -BeNullOrEmpty
            }   
            It "DM_Workspace_API_33_06 - Should return at least one record" {
                $response.Count | Should -BeGreaterThan 0
            }
            
        
            It "DM_Workspace_API_33_06 - Should match search" {
                foreach ($engagement in $response) {
                    $response.clientName | Should -Match "Zenkyoren Asset Management Of Ameri"
                }
            }
 
            AfterAll {
          
            }
        }

        Context "DM_Workspace_API_33_07" {
            BeforeAll {
                $requestParams = @{
                    Method  = 'GET'
                    Uri     = "/workspace/api/v1/engagement?engagementManagerName=Iwase%2CShoichi"
                }
                
                $response = @{}
                $response = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true

                # we reset the access and refersh tokens in case they expired
                #$token = $requestPayload.accessToken
                #$refreshToken = $requestPayload.refreshToken
            }         
        
            It "DM_Workspace_API_33_07 - Should not return null" {                               
                $response | Should -not -BeNullOrEmpty
            }  
            It "DM_Workspace_API_33_07 - Should return at least one record" {
                $response.Count | Should -BeGreaterThan 0
            } 
       
            
            It "DM_Workspace_API_33_07 - Should match search" {
                foreach ($engagement in $response) {
                    $engagement.engagementManagerName | Should -Match "Iwase,Shoichi"
                }
            }
 
            AfterAll {
          
            }
        }

    # Search with Engagement number and EngagementPartnerName
    Context "DM_Workspace_API_33_08 | search by engagement number and EngagementPartnerName" {                             
        $requestParams = @{
            Method = 'GET'
            Uri    = "/workspace/api/v1/engagement"                
        }

        $EngagementresponseList = @{}
        $EngagementresponseList = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true
        $total=$EngagementresponseList.count
        Write-Host $total
       #Write-Host "engagement Partners list $($EngagementresponseList.engagementPartnerName)"
        It "Should not Null" {  
            $EngagementresponseList.count |  Should -not -BeNullOrEmpty
        } 

        foreach ($Num1 in $EngagementresponseList.engagementNumber[$total-2]) {
            foreach ($Name1 in $EngagementresponseList.engagementPartnerName[$total-2]) {
                Write-Host "Filtering with engagement number -$($Num1) and engagementPartnerName-$($Name1)"
                $requestParams = @{
                    Method = 'GET'
                    Uri    = "/workspace/api/v1/engagement?engagementNumber=$($Num1)&engagementPartnerName=$($Name1)"                     
                }
                $response = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true 
              
                if ($response.engagementNumber -eq $($Num1) -and $response.engagementPartnerName -eq $($Name1)) {
                        
                    It "Engagement number should match with the response for EngagementNumber -$($Num1) " {   
                        $($response.engagementNumber) | should -eq $($Num1) 
                    }
                           
                    It "The engagementPartnerName should match with the response for EngagementName -$($Name1)" {  
                        $($response.engagementPartnerName) | should -eq $($Name1)    
                    }
                        
                }
                else {
                    It "should have 200 OK with null response" {   
                        $response| should -BeNullOrEmpty     
                    }
                }
                    
            }
                
        }
    }

        <# Context "DM_Workspace_API_33_09" {
            BeforeAll {
                $requestParams = @{
                    Method  = 'GET'
                    Uri     = "/workspace/api/v1/engagement?engagementNumber=2000097148"
                }
                
                $response = @{}
                $response = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true
                
                # we reset the access and refersh tokens in case they expired
                #$token = $requestPayload.accessToken
                #$refreshToken = $requestPayload.refreshToken
            }         
        
            It "DM_Workspace_API_33_09 - Should not return null" {                               
                $response | Should -not -BeNullOrEmpty
            }              
        
            It "DM_Workspace_API_33_09 - Should return at least one record" {
                $response.engagementNumber | Should -Be "2000097148"
            }
 
            AfterAll {
          
            }
        } #>

        Context "DM_Workspace_API_33_10" {
            BeforeAll {
                $requestParams = @{
                    Method  = 'GET'
                    Uri     = "/workspace/api/v1/engagement?clientCode=1000532740&engagementManagerName=Iwase%2CShoichi"
                }
                
                $response = @{}
                $response = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true
                
                # we reset the access and refersh tokens in case they expired
                #$token = $requestPayload.accessToken
                #$refreshToken = $requestPayload.refreshToken
            }         
        
            It "DM_Workspace_API_33_10 - Should not return null" {                               
                $response | Should -not -BeNullOrEmpty
            }              
        
            It "DM_Workspace_API_33_10 - Should return at least one record" {
                $response.clientCode | Should -Match "1000532740"
            }
            
            It "DM_Workspace_API_33_10 - Should match search" {
                foreach ($engagement in $response) {
                    $engagement.engagementManagerName | Should -Match "Iwase,Shoichi"
               }
            }
           
            AfterAll {
          
            }
        }  
	
	Context "DM_Workspace_API_33_11 | Invalid allColumnsSearch" {
            BeforeAll {
                $requestParams = @{
                    Method  = 'GET'
                    Uri     = "/workspace/api/v1/engagement?allColumnsSearch=%40354%23%24%25"
                }
                
                $response = @{}
                $response = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true
                
                # we reset the access and refersh tokens in case they expired
                #$token = $requestPayload.accessToken
                #$refreshToken = $requestPayload.refreshToken
            }         
        
            It "Should return null" {                               
                $response | Should -BeNullOrEmpty
            }              
            
            AfterAll {
          
            }
        } 
  }
}