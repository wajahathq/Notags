param(

    [Parameter(Mandatory)]
    [ValidateNotNullOrEmpty()]
    $CurrentEnvironmentData

)

$Script:service = "powerbi"
$Script:resourceNameContextId = (New-Guid).Guid
$Script:resourceName = "NewRN $($resourceNameContextId)"
$Script:credentialAccountNameContextId = (New-Guid).Guid
$Script:credentialAccountName = "NewCAN $($credentialAccountNameContextId)"
$dataSourceResourceType = @("Unknown", "AnalysisServices", "SqlServer", "DataLakeGen2")
$credentialAuthorizationMethod = @("Unknown", "Basic", "Windows", "OAuth2", "Key")
$dataSourceCredentialType = @("Unknown", "ServicePrincipal", "ServiceAccount")

Describe "PBI" -Tag "ResourceCredential" {
    Context "POST /api/v1/resourcecredential" {
        foreach ($item1 in $dataSourceResourceType) {
            foreach ($item2 in $credentialAuthorizationMethod) {
                foreach ($item3 in $dataSourceCredentialType) {
                    if ($item1 -eq "Unknown" -or $item2 -eq "Unknown" -or $item3 -eq "Unknown") {
                        Write-Host "Running for dataSourceResourceType = $item1 , credentialAuthorizationMethod = $item2 and dataSourceCredentialType = $item3 "
                        $envData = GetOBOEnvironmentData $CurrentEnvironmentData "https://analysis.windows.net/powerbi/api/.default"
                        $requestParams = @{
                            Method = 'POST'
                            Uri    = "/$($service)/api/v1/resourcecredential"
                            Body   = @{
                                "dataSourceResourceType"        = "$($item1)"
                                "resourceName"                  = $($resourceName)
                                "credentialAuthorizationMethod" = "$($item2)"
                                "dataSourceCredentialType"      = "$($item3)"
                                "credentialAccountName"         = $($credentialAccountName)
                                "credentialKeySecretName"       = "DummySqlPassword"
                            } | ConvertTo-Json
                        }

                        $response = @{}
                        $Script:response = Invoke-RestMethodAuthWrapperExceptionHandler $envdata $requestParams $true

                        It "Should return 400 bad request- for $item1 or $item2 or $item3 " {
                            $response.ExceptionResponse.StatusCode.value__ | Should -be 400
                        }
                    }
                    else {
                        Write-Host "Running for dataSourceResourceType = $item1 , credentialAuthorizationMethod = $item2 and dataSourceCredentialType = $item3 "
                        $envData = GetOBOEnvironmentData $CurrentEnvironmentData "https://analysis.windows.net/powerbi/api/.default"
                        $requestParams = @{
                            Method = 'POST'
                            Uri    = "/$($service)/api/v1/resourcecredential"
                            Body   = @{
                                "dataSourceResourceType"        = "$($item1)"
                                "resourceName"                  = $($resourceName)
                                "credentialAuthorizationMethod" = "$($item2)"
                                "dataSourceCredentialType"      = "$($item3)"
                                "credentialAccountName"         = $($credentialAccountName)
                                "credentialKeySecretName"       = "DummySqlPassword"
                            } | ConvertTo-Json
                        }

                        $ResourceCredentialResponse = @{}
                        $ResourceCredentialResponse = Invoke-RestMethodAuthWrapper $envData $requestParams $true

                        It "should return valid Resource Type for $item1 or $item2 or $item3" {
                            $($ResourceCredentialResponse.resourceType) | Should -eq $($dataSourceResourceType)
                        }

                        It "should return valid credential auth Method" {
                            $($ResourceCredentialResponse.credentialAuthMethod) | Should -eq $($credentialAuthorizationMethod)
                        }

                        It "should return valid datasource credential type" {
                            $($ResourceCredentialResponse.credentialType) | Should -eq $($dataSourceCredentialType)
                        }

                        $ResourceCredentialId = $($ResourceCredentialResponse.resourceCredentialMapId)

                        Write-Host "Getting the resource credential....."

                        $envdata = GetOBOEnvironmentData $CurrentEnvironmentData "https://analysis.windows.net/powerbi/api/.default"
                        $requestParams = @{
                            Method = 'GET'
                            Uri    = "/$($service)/api/v1/resourcecredential"
                        }

                        $CredentialResponse = @{}
                        $CredentialResponse = Invoke-RestMethodAuthWrapper $envData $requestParams $true

                        It "should return response body having resourceCredentialId" {
                            $($CredentialResponse.resourceCredentialMapId) | Should -contain $($ResourceCredentialId)
                        }

                        Write-Host "Unregisters Power BI Datasource Resource Credentials = $($ResourceCredentialId).."

                        $envData = GetOBOEnvironmentData $CurrentEnvironmentData "https://analysis.windows.net/powerbi/api/.default"
                        $requestParams = @{
                            Method = 'DELETE'
                            Uri    = "/$($service)/api/v1/resourcecredential/$($ResourceCredentialId)"
                        }

                        $response = @{}
                        $response = Invoke-RestMethodAuthWrapper $envData $requestParams $true
                    }
                }
            }
        }
    }

}
