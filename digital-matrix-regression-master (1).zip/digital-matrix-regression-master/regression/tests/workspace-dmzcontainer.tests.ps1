# Pester regression tests
# Below code is Written  for Story 100057
#Creating RBAC Standalone Container and uploading data file to them using AZ connect
#using Client ID Tanent Id and Client Secret id from the Enviroment Variable

param(

    [Parameter(Mandatory)]
    [ValidateNotNullOrEmpty()]
    $CurrentEnvironmentData

)
Describe "Workspace-datamovement | create container" {

    Context "DMZ File Upload system - US 100057" {
        BeforeAll {
            Write-Host "Creating Standalone RBAC Container..."
            $service = "workspace"
            $requestParams = @{
                Method = 'POST'
                Uri    = "/workspace/api/v1/datamovement/container"
                Body   = @{
                    "usage" = "RBAC"
                } | ConvertTo-Json
            }

            $rbacContainerResponse = $null
            $rbacContainerResponse = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true

            $rbacContainerTaskResult = $null
            $rbacContainerTaskResult = Get-BackgroundStatus $CurrentEnvironmentData $rbacContainerResponse.taskId "$($service)"

            $script:rbacContainerName = $rbacContainerTaskResult.taskOutput.containerName
            $script:RBCUri = $rbacContainerTaskResult.taskOutput.containerUrl

            Write-Host "The container name is $($rbacContainerName)"

            $clientId = $($CurrentEnvironmentData.ClientId)
            $clientSecret = $($currentEnvironmentData.ClientSecret)
            $tenantId = $($CurrentEnvironmentData.TenantId)
            $tempPassword = ConvertTo-SecureString "$clientSecret" -AsPlainText -Force
            $psCred = New-Object System.Management.Automation.PSCredential($clientId , $tempPassword)
            Connect-AzAccount -Credential $psCred -TenantId $tenantId  -ServicePrincipal
            Write-Host  "Azure is connected"

            $Context = New-AzStorageContext -StorageAccountName $($CurrentEnvironmentData.SAccountName)

            $filepath = "DMZtestfile.txt"
            $UploadFile = @{
                File             = ".\tests\DMZtestfile.txt"
                Container        = $($rbacContainerName)
                Blob             = $($filepath)
                Context          = $Context
                StandardBlobTier = 'Hot'
            }

            Set-AzStorageBlobContent @UploadFile -Force

            Write-Host  "File Upload done in azure stroage $($rbacContainerName) "



    }
    
    Context "DMZ - Audit Log DM_Workspace_API_114_02| Happy Flow" {

        BeforeAll {
            Write-Host "Audit Log for RBAC Container..."

            Start-Sleep -Seconds 300
            Write-Host "Todays Date is --- $a -Format "yyyy-MM-dd'T'HH:mm:ss.fff'Z'""
            $StartDate = ((Get-Date).ToUniversalTime().AddMinutes(-30)).ToString('yyyy-MM-ddTHH:mm:ss.fffZ')
            $EndDate = ((Get-Date).ToUniversalTime().AddDays(8)).ToString('yyyy-MM-ddTHH:mm:ss.fffZ')
            $requestParams = @{
                Method = 'POST'
                Uri    = "/workspace/api/v1/datamovement/container/$($rbacContainerName)/logs"
                Body   = @{
                    "startDate" =  $StartDate
                    "endDate"   =  $EndDate
                    "isSuccess"  = $true
                    "statusCode" = 200
                } | ConvertTo-Json
            }

            $AuditLogResponse = $null
            $AuditLogResponse = Retry-Request $CurrentEnvironmentData $requestParams 5 $RBCUri


        }

        It "Should show the logs for RBAC Continer" {
            $AuditLogResponse | Should -not -BeNullOrEmpty
        }

    }
    Context "DMZ - Audit Log DM_Workspace_API_114_03 | with Invalid RBAC container" {

        BeforeAll {
            Write-Host "Audit Log for Invalid RBAC Container..."

            $InvalidrbacContainerName = "Invalid$($rbacContainerName)"
            $requestParams = @{
                Method = 'POST'
                Uri    = "/workspace/api/v1/datamovement/container/$($InvalidrbacContainerName)/logs"
                Body   = @{
                    "isSuccess"  = $true
                    "statusCode" = 200
                } | ConvertTo-Json
            }

            $response = @{}
            $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true

            Write-Host "Audit response is --- $($response.ErrorDetails.message)"
        }

        It "should throw 404 invalid rbac name" {
            $response.ExceptionResponse.StatusCode.value__ | Should -be 404

        }

        It "should throw message for invalid RBAC name " {

            $response.ErrorDetails.message | Should -Contain "Container '$($InvalidrbacContainerName)' does not exist."
        }
    }
    Context "DMZ - Audit Log DM_Workspace_API_114_04 | with CaseSensetive RBAC container Name" {

        BeforeAll {
            Write-Host "Audit Log for Case Senstive RBAC Container..."

            $CaseSenstiverbacContainerName = $rbacContainerName.ToUpper()
            $requestParams = @{
                Method = 'POST'
                Uri    = "/workspace/api/v1/datamovement/container/$($CaseSenstiverbacContainerName)/logs"
                Body   = @{
                    "isSuccess"  = $true
                    "statusCode" = 200
                } | ConvertTo-Json
            }

            $AuditLogResponse = $null
            $AuditLogResponse = Retry-Request $CurrentEnvironmentData $requestParams 5 $RBCUri
        }


        It "should show Audit result irrrespective of Case" {
            $AuditLogResponse | Should -not -BeNullOrEmpty
        }

    }
    Context "DMZ - Audit Log DM_Workspace_API_114_05 | with Valid Dates" {

        BeforeAll {
            Write-Host "Audit Log for RBAC Container with Valid Dates."

            $a = (Get-Date).ToUniversalTime()
            Write-Host "Todays Date is --- $a -Format "yyyy-MM-dd'T'HH:mm:ss.fff'Z'""
            $StartDate = ((Get-Date).ToUniversalTime().AddMinutes(-30)).ToString('yyyy-MM-ddTHH:mm:ss.fffZ')
            $EndDate = ((Get-Date).ToUniversalTime().AddDays(8)).ToString('yyyy-MM-ddTHH:mm:ss.fffZ')
            $requestParams = @{
                Method = 'POST'
                Uri    = "/workspace/api/v1/datamovement/container/$($rbacContainerName)/logs"
                Body   = @{
                    "startDate" =  $StartDate
                    "endDate"   =  $EndDate
                } | ConvertTo-Json
            }


            $AuditLogResponse = @{}
            $AuditLogResponse = Retry-Request $CurrentEnvironmentData $requestParams 5 $RBCUri

            Write-Host "Audit response is --- $AuditLogResponse"
        }

        It "should return logs for Valid Dates filter" {
            $AuditLogResponse | Should -not -BeNullOrEmpty

        }
    }
    Context "DMZ - Audit Log DM_Workspace_API_114_06 | Status Code - 200" {

        BeforeAll {
            Write-Host "Audit Log for RBAC Container where Status Code - 200.."

            $requestParams = @{
                Method = 'POST'
                Uri    = "/workspace/api/v1/datamovement/container/$($rbacContainerName)/logs"
                Body   = @{
                    "isSuccess"  = $true
                    "statusCode" = 200
                } | ConvertTo-Json
            }

            $AuditLogResponse = @{}
            $AuditLogResponse = Retry-Request $CurrentEnvironmentData $requestParams 5 $RBCUri
            Write-Host "Audit response is --- $($AuditLogResponse.statusCode)"
        }

        It "This is the test" {
            Write-Host "This is the Response $($AuditLogResponse[0].statusCode) "
            $AuditLogResponse[0].statusCode | Should -be 200

        }
    }
    Context "DMZ - Audit Log DM_Workspace_API_114_08  | is Success is true" {

        BeforeAll {
            Write-Host "Audit Log for RBAC Container where  is Success is true"
            $requestParams = @{
                Method = 'POST'
                Uri    = "/workspace/api/v1/datamovement/container/$($rbacContainerName)/logs"
                Body   = @{
                    "isSuccess" = $true
                } | ConvertTo-Json
            }

            $AuditLogResponse = @{}
            $AuditLogResponse = Retry-Request $CurrentEnvironmentData $requestParams 5 $RBCUri

            Write-Host "Audit response is --- $($AuditLogResponse.isSuccess)"
        }

        It "should contains logs of status Success" {
            Write-Host "This is the Response $($AuditLogResponse[0].isSuccess) "
            $AuditLogResponse[0].statusText | Should -be "Success"

        }
    }
     Context "DMZ - Audit Log DM_Workspace_API_114_09  | is Success is False" {

        BeforeAll {
            Write-Host "Audit Log for RBAC Container where  is Success is false"
            $requestParams = @{
                Method = 'POST'
                Uri    = "/workspace/api/v1/datamovement/container/$($rbacContainerName)/logs"
                Body   = @{
                    "isSuccess" = $false
                } | ConvertTo-Json
            }

            $AuditLogResponse = @{}
            $AuditLogResponse = Retry-Request $CurrentEnvironmentData $requestParams 5 $RBCUri

        }

        It "should contains logs of status Success" {
            $AuditLogResponse | Should -BeNullOrEmpty

        }
    }

    AfterAll {

        $requestParams = @{
            Method = 'DELETE'
            Uri    = "/workspace/api/v1/datamovement/container"
            Body   = @{
                "containerName" = "$($rbacContainerName)"
            } | ConvertTo-Json
        }

        $Deleteresponse = $null
        $Deleteresponse = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true
        Write-Host "RBAC Container Deleted"

    }

}
}
