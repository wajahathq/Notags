
param(
    [Parameter(Mandatory)]
    [ValidateNotNullOrEmpty()]
    $CurrentEnvironmentData
)
Describe "HealthCheck" {
    Context " Workspace Health check" {
        BeforeAll {
            $service = "workspace"
            $expectedstatus = "Healthy"
            Write-Host "Running Healthcheck for $service"
            $Healthresponse = Run-Health-check $CurrentEnvironmentData $service 3 $expectedstatus 11
            Write-Host "Status in Healtcheck is - $($Healthresponse.Status)"
        }

        It "Healthcheck Response for $service is $Healthresponse" {
            #Assertion
            $Healthresponse.Status | Should -be "Healthy"
        }
    }

    Context " Auth Health check" {
        BeforeAll {
            $service = "auth"
            Write-Host "Running Healthcheck for $service"
            $Healthresponse = Run-Health-check $CurrentEnvironmentData $service 3 $expectedstatus 11
            Write-Host "Status in Healtcheck is - $($Healthresponse.Status)"
        }

        It "Healthcheck Response for $service is $Healthresponse" {
            #Assertion
            $Healthresponse.Status | Should -be "Healthy"
        }
    }

    Context " Active Directory Health check" {
        BeforeAll {
            $service = "ad"
            Write-Host "Running Healthcheck for $service"
            $Healthresponse = Run-Health-check $CurrentEnvironmentData $service 3 $expectedstatus 11
            Write-Host "Status in Healtcheck is - $($Healthresponse.Status)"
        }

        It "Healthcheck Response for $service is $Healthresponse" {
            #Assertion
            $Healthresponse.Status | Should -be "Healthy"
        }
    }

    Context " Powerbi Health check" {
        BeforeAll {
            $service = "powerbi"
            $maxretry = 3  # Max number of retry attempts
            $retryInterval = 5  # Retry interval in seconds
            $timeout = 300  # Timeout in seconds
            $expectedStatus = "Healthy"  # Expected status from health check
            $Healthresponse = $null
            $attempt = 0
    
            Write-Host "Running Healthcheck for $service"

            # Retry logic
            while ($attempt -lt $maxretry) {
                try {
                    $Healthresponse = Run-Health-check $CurrentEnvironmentData $service $maxretry $expectedstatus $timeout
                    Write-Host "Attempt $($attempt + 1): Status in Healthcheck is - $($Healthresponse.Status)"

                    # Check if the health check status is as expected
                    if ($Healthresponse.Status -eq $expectedStatus) {
                        Write-Host "Healthcheck successful after $($attempt + 1) attempts."
                        break
                    }
                    else {
                        Write-Host "Healthcheck failed after $($attempt + 1) attempts. Retrying..."
                    }
                }
                catch {

                    Write-Host "Error occurred while running health check. Retrying in $retryInterval seconds, attempt $($attempt + 1) of $maxretry."
                    # Increment the retry counter and wait before retrying
                    $attempt++
                    if ($attempt -lt $maxRetries) {
                        Write-Host "Retrying in $retryInterval seconds..."
                        Start-Sleep -Seconds $retryInterval
                    } else {
                        Write-Host "Healthcheck failed after $maxRetries attempts. No more retries remaining."
                    }
                }
            }
        }

        It "Healthcheck Response for $service is $Healthresponse" {
            #Assertion
            $Healthresponse.Status | Should -be $expectedStatus
        }
    }

    Context " devops Health check" {
        BeforeAll {
            $service = "devops"
            Write-Host "Running Healthcheck for $service"
            $Healthresponse = Run-Health-check $CurrentEnvironmentData $service 3 $expectedstatus 11
            Write-Host "Status in Healtcheck is - $($Healthresponse.Status)"
        }

        It "Healthcheck Response for $service is $Healthresponse" {
            #Assertion
            $Healthresponse.Status | Should -be "Healthy"
        }
    }

}
