param(

    [Parameter(Mandatory)]
    [ValidateNotNullOrEmpty()]
    $CurrentEnvironmentData

)
Describe "Workspace GenericLookUp" {
    Context "GenericLookUp for Workspace"  {
        BeforeALL{
            Write-Host "Checking Category Data Filter "
            $validcategorydata = "DataType"
            $requestParams = @{
                Method = 'GET'
                Uri    = "/workspace/api/v1/genericlookup/$validcategorydata"
            }
            $responsegenericlookup = @{}
            $responsegenericlookup = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true

        }
        It "ST_TC_DM_308925: To verify that category filter on the generic lookup returns valid lookup IDs and corresponding captions when valid category data is provided."{
            Write-Host "Verify lookup ids and captions for category filter"
            $responsegenericlookup | Should -not -BeNullOrEmpty

        }
        It " To verify that the category filter on the generic lookup returns an error message when invalid category data is provided."{
            Write-Host "Error message should be dispalyed when invalid category filter is provided"
            $Invalidcategorydata = "Capabilities"
            $requestParams = @{
                Method = 'GET'
                Uri    = "/workspace/api/v1/genericlookup/$Invalidcategorydata"
            }
            $response = @{}
            $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true
            Write-Host "Response ---  $($response.ErrorDetails.message)"
            $response.ExceptionResponse.StatusCode.value__ | Should -be 404
            $response.ErrorDetails.message | Should -be "Category: $Invalidcategorydata was not found."
        }
    }
}
Describe "Auth GenericLookUp" {
    Context "GenericLookUp for Auth"  {
        BeforeALL{
            Write-Host "Checking Category Data Filter "
            $validcategorydata ="RoleStatus"
            $requestParams = @{
                Method = 'GET'
                Uri    = "/auth/api/v1/genericlookup/$validcategorydata"
            }
            $responsegenericlookup = @{}
            $responsegenericlookup = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true

        }
        It "ST_TC_DM_308925: To verify that category filter on the generic lookup returns valid lookup IDs and corresponding captions when valid category data is provided."{
            Write-Host "Verify response for category filter is not null empty"
            $responsegenericlookup | Should -not -BeNullOrEmpty

        }
        It " To verify that the category filter on the generic lookup returns an error message when invalid category data is provided."{
            Write-Host "Error message should be dispalyed when invalid category filter is provided"
            $Invalidcategorydata = "Invalid*123"
            $requestParams = @{
                Method = 'GET'
                Uri    = "/auth/api/v1/genericlookup/$Invalidcategorydata"
            }
            $response = @{}
            $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true
            Write-Host "Response ---  $($response.ErrorDetails.message)"
            $response.ExceptionResponse.StatusCode.value__ | Should -be 404
            $response.ErrorDetails.message | Should -be "Category: $Invalidcategorydata was not found."


        }

    }

}