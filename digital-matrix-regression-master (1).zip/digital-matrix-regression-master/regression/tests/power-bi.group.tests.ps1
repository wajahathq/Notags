param(

    [Parameter(Mandatory)]
    [ValidateNotNullOrEmpty()]
    $CurrentEnvironmentData

)
Describe "PBI" -Tag "Group" {
    Context "POST /api/v1/group" {

        BeforeAll {
            $script:pbiGroup1CreationSucceeded = $false
            $script:pbiGroup2CreationSucceeded = $false
            $script:groupIdAdCreationSucceeded = $false
            $script:memberUserIdAdCreationSucceeded = $false
            $service = "powerbi"
            $contextId = Get-Date -Format "yyyyMMdd-HHmmss"
            $groupName = "PesterPBI1$($CurrentEnvironmentData.Environment)$($contextId)"
            $nestedgroupName = "PesterPBI2$($CurrentEnvironmentData.Environment)$($contextId)"
            $description = "This group was created as part of a test run with context id $($contextId).  If you're reading this - it's okay to delete."

            Write-Host "BeforeAll POST /api/v1/group - context id $($contextId)"
            $envData = GetOBOEnvironmentData $CurrentEnvironmentData "https://analysis.windows.net/powerbi/api/.default"

            Write-Host "Creating 1st PBI group with name $($groupName)"
            $requestParams = @{
                Method = 'POST'
                Uri    = "/$($service)/api/v1/group"
                Body   = @{
                    "groupName" = "$($groupName)"
                } | ConvertTo-Json
            }

            $createResponse = $null
            $createResponse = Invoke-RestMethodAuthWrapper $envData $requestParams $true
            

            Write-Host "Create group response---- $($createResponse)"

            $taskid = $createResponse.taskId

            Write-Host "task id.... $($taskid)"

            $createTaskResult = $null
            $createTaskResult = Get-BackgroundStatus $envData $createResponse.taskId $service
            $script:pbiGroup1 = $createTaskResult.taskOutput.groupId
            Write-Host " 1st PBI group id response---- $($pbiGroup1)"

            FailEarly "Validate 1st PBI group '$($groupName)' created." {
                $createTaskResult.status | Should -Be "Completed"
            }

            $script:pbiGroup1CreationSucceeded = $true

            Write-Host "Retrieving group..."

            $requestParams = @{
                Method = 'GET'
                #Uri    = "/$($service)/api/v1/group?searchText=$($groupName)&pageIndex=0&pageSize=1000"
                Uri    = "/$($service)/api/v1/group?searchText=$($groupName)&pageIndex=0&pageSize=1000"
            }

            $retrieveResponse = @{}
            $retrieveResponse = Invoke-RestMethodAuthWrapper $envData $requestParams $true

            Write-Host "Get method responses.... $($retrieveResponse)"

            # creating 2nd PBI group
            Write-Host "Creating 2nd PBI group with name $($nestedgroupName)..."
            $requestParams = @{
                Method = 'POST'
                Uri    = "/powerbi/api/v1/group"
                Body   = @{
                    "groupName" = "$($nestedgroupName)"
                } | ConvertTo-Json
            }

            $createResponse2 = $null
            $createResponse2 = Invoke-RestMethodAuthWrapper $envData $requestParams $true

            $taskid = $createResponse2.taskId

            Write-Host "task id.... $($taskid)"

            $createTaskResult2 = $null
            $createTaskResult2 = Get-BackgroundStatus $envData $createResponse2.taskId $service
            $script:pbiGroup2 = $createTaskResult2.taskOutput.groupId
            Write-Host "2nd PBI group id in response---- $($pbiGroup2)"

            FailEarly "Validate 2nd PBI group '$($nestedgroupName)' created." {
                $createTaskResult2.status | Should -Be "Completed"
            }

            $script:pbiGroup2CreationSucceeded = $true

            #Now Creating User and Group from AD  for adding group to PBI group
            $groupIdContext = (New-Guid).Guid
            $memberUserIdContext = (New-Guid).Guid

            # Create the group that will have its group membership modified

            $groupResult = Create-Group $CurrentEnvironmentData $groupIdContext
            $global:groupIdAd = $groupResult.taskOutput.groupId

            FailEarly 'Validate AD Group created.' {
                $groupResult.status | Should -Be "Completed"
            }

            $script:groupIdAdCreationSucceeded = $true

            # Create a  AD user that will be added to the group

            $memberUserResult = Create-User $CurrentEnvironmentData $memberUserIdContext
            $global:memberUserIdAd = $memberUserResult.taskOutput.userId

            FailEarly 'Validate AD User created.' {
                $memberUserResult.status | Should -Be "Completed"
            }

            $script:memberUserIdAdCreationSucceeded = $true

            Write-Host " POST adding group to group..."

            $requestParams = @{
                Method = 'POST'
                Uri    = "/powerbi/api/v1/groupmembership"
                Body   = @{
                    "groupId" = $($pbiGroup1)
                    "memberId" = $($groupIdAd)
                    "memberType" = "group"
                    "accessLevel" = "viewer"
                } | ConvertTo-Json
            }

            $groupcreateResponse = $null
            $groupcreateResponse = Invoke-RestMethodAuthWrapper $envData $requestParams $true

            $GroupaddTaskid = $groupcreateResponse.taskId

            $GroupaddTaskResult = $null
            $GroupaddTaskResult = Get-BackgroundStatus $envData $GroupaddTaskid $service

            FailEarly 'Validate AD Group added as member to 1st PBI Group.' {
                $GroupaddTaskResult.status | Should -Be "Completed"
            }

            # this is test check
            #Adding group to AD Group
            Write-Host " POST adding group to AD User..."

            $requestParams = @{
                Method = 'POST'
                Uri    = "/powerbi/api/v1/groupmembership"
                Body   = @{
                    "groupId" = $($pbiGroup1)
                    "memberId" = $($memberUserIdAd)
                    "memberType" = "user"
                    "accessLevel" = "viewer"
                } | ConvertTo-Json
            }

            $usercreateResponse = $null
            $usercreateResponse = Invoke-RestMethodAuthWrapper $envData $requestParams $true

            $useraddTaskid = $usercreateResponse.taskId

            $useraddTaskResult = $null
            $useraddTaskResult = Get-BackgroundStatus $envData $useraddTaskid $service

            FailEarly 'Validate AD User added as member to 1st PBI Group.' {
                $useraddTaskResult.status | Should -Be "Completed"
            }

            Write-Host " Get list of All group with /api/v1/group"

            Write-Host "Retrieving group..."

            $envdata = GetOBOEnvironmentData $CurrentEnvironmentData "https://analysis.windows.net/powerbi/api/.default"
            $requestParams = @{
                Method = 'GET'
                #Uri    = "/$($service)/api/v1/group?searchText=$($groupName)&pageIndex=0&pageSize=1000"
                Uri    = "/powerbi/api/v1/group"
            }

            $retrieveGetAllGroupsResponse = @{}
            $retrieveGetAllGroupsResponse = Invoke-RestMethodAuthWrapper $envdata $requestParams $true

            Write-Host " Total number of Group exisit is ----  $($retrieveGetAllGroupsResponse.count)"

            $global:totalGroups = $retrieveGetAllGroupsResponse.count
        } #END OF BEFORE ALL

        It "should return a response that is not null or empty" {
            $createResponse | Should -Not -BeNullOrEmpty
        }

        It "should return a group id that is not null or empty" {
            $($createTaskResult.taskOutput.groupId) | Should -Not -BeNullOrEmpty
        }

        It "should return a 1st $($pbiGroup1) group id in response" {
            Write-Host "Retrieving group..."

            $envData = GetOBOEnvironmentData $CurrentEnvironmentData "https://analysis.windows.net/powerbi/api/.default"
            $requestParams = @{
                Method = 'GET'
                Uri    = "/powerbi/api/v1/group?searchText=$($groupName)&pageIndex=0&pageSize=1000"
            }

            $retrieveResponse = @{}
            $retrieveResponse = Invoke-RestMethodAuthWrapper $envData $requestParams $true

            Write-Host "Get method responses.... $($retrieveResponse.id)"

            $($retrieveResponse.id) | Should -be $($pbiGroup1)
        }

        It "should return a 2nd $($pbiGroup2) group id in response" {
            Write-Host "Retrieving group..."

            $envData = GetOBOEnvironmentData $CurrentEnvironmentData "https://analysis.windows.net/powerbi/api/.default"
            $requestParams = @{
                Method = 'GET'
                Uri    = "/powerbi/api/v1/group?searchText=$($nestedgroupName)&pageIndex=0&pageSize=1000"
            }

            $retrieveResponse = @{}
            $retrieveResponse = Invoke-RestMethodAuthWrapper $envData $requestParams $true

            Write-Host "Get method responses.... $($retrieveResponse.id)"

            $($retrieveResponse.id) | Should -be $($pbiGroup2)
        }

        It "should Add another AD Group as Memeber and response is 200" {
            $($GroupaddTaskResult.taskOutput.groupId) | Should -be $($pbiGroup1)
            $($GroupaddTaskResult.status) | Should -be "Completed"
            $($GroupaddTaskResult.taskOutput.activityType) | Should -be "AddPowerBiGroupMember"
        }

        It "should Add another PBI user as Memeber and response is 200" {
            $($useraddTaskResult.taskOutput.groupId) | Should -be $($pbiGroup1)
            $($useraddTaskResult.status) | Should -be "Completed"
            $($useraddTaskResult.taskOutput.activityType) | Should -be "AddPowerBiGroupMember"
        }

        It "should throw error when adding one PBI group to another PBI group"{
            Write-Host " POST adding group to AD User..."

            $envData = GetOBOEnvironmentData $CurrentEnvironmentData "https://analysis.windows.net/powerbi/api/.default"
            $requestParams = @{
                Method = 'POST'
                Uri    = "/powerbi/api/v1/groupmembership"
                Body   = @{
                    "groupId" = $pbiGroup1
                    "memberId"= $pbiGroup2
                    "memberType" = "group"
                    "accessLevel" = "viewer"
                } | ConvertTo-Json
            }
            $response = @{}
            $response = Invoke-RestMethodAuthWrapperExceptionHandler $envData $requestParams $true

            Write-Host "Response from the above testcases is ----$response and $($response.ErrorDetails.message)"
            $response.ErrorDetails.message | should -be "Invalid Group Id '$($pbiGroup2)'."
        }

        It "should throw error when adding one Invalid user to another PBI group"{
            Write-Host " POST adding group to AD User..."

            $envData = GetOBOEnvironmentData $CurrentEnvironmentData "https://analysis.windows.net/powerbi/api/.default"
            $requestParams = @{
                Method = 'POST'
                Uri    = "/powerbi/api/v1/groupmembership"
                Body   = @{
                    "groupId" = $pbiGroup1
                    "memberId"= "Invalid-$($memberUserIdAd)"
                    "memberType" = "user"
                    "accessLevel" = "viewer"
                } | ConvertTo-Json
            }
            $response = @{}
            $response = Invoke-RestMethodAuthWrapperExceptionHandler $envData $requestParams $true

            Write-Host "Response from the above testcases is ----$response and $($response.memberId)"
            $response.ExceptionResponse.StatusCode.value__ | Should -be 400
            #$response.ErrorDetails.errors.memberId | should -contain "Invalid-$($memberUserIdAd)"
        }

        It "should throw error when memberType is Unknown "{
            Write-Host " POST adding group to AD User..."

            $envData = GetOBOEnvironmentData $CurrentEnvironmentData "https://analysis.windows.net/powerbi/api/.default"
            $requestParams = @{
                Method = 'POST'
                Uri    = "/powerbi/api/v1/groupmembership"
                Body   = @{
                    "groupId" = $pbiGroup1
                    "memberId"= "$($memberUserIdAd)"
                    "memberType" = "unknown"
                    "accessLevel" = "viewer"
                } | ConvertTo-Json
            }
            $response = @{}
            $response = Invoke-RestMethodAuthWrapperExceptionHandler $envData $requestParams $true

            Write-Host "Response from the above testcases is ----$response and $($response.memberId)"
            $response.ExceptionResponse.StatusCode.value__ | Should -be 400
            $response.ErrorDetails.message | should -be "Invalid Principal Type. Valid ActivityLogStatusEnum are: User, Group, ServicePrincipal"
        }

        It "should throw error when AccessLevel is Unknown "{
            Write-Host " POST adding group to AD User..."

            $envData = GetOBOEnvironmentData $CurrentEnvironmentData "https://analysis.windows.net/powerbi/api/.default"
            $requestParams = @{
                Method = 'POST'
                Uri    = "/powerbi/api/v1/groupmembership"
                Body   = @{
                    "groupId" = $pbiGroup1
                    "memberId"= "$($memberUserIdAd)"
                    "memberType" = "unknown"
                    "accessLevel" = "viewer"
                } | ConvertTo-Json
            }
            $response = @{}
            $response = Invoke-RestMethodAuthWrapperExceptionHandler $envData $requestParams $true

            Write-Host "Response from the above testcases is ----$response and $($response.memberId)"
            $response.ExceptionResponse.StatusCode.value__ | Should -be 400
            $response.ErrorDetails.message | should -be "Invalid Principal Type. Valid ActivityLogStatusEnum are: User, Group, ServicePrincipal"
        }

        It "should throw error when Group id is Invalid "{
            Write-Host " POST adding group to AD User..."

            $envData = GetOBOEnvironmentData $CurrentEnvironmentData "https://analysis.windows.net/powerbi/api/.default"
            $requestParams = @{
                Method = 'POST'
                Uri    = "/powerbi/api/v1/groupmembership"
                Body   = @{
                    "groupId" = "invalid-$($pbiGroup1)"
                    "memberId"= "$($memberUserIdAd)"
                    "memberType" = "user"
                    "accessLevel" = "Viewer"
                } | ConvertTo-Json
            }
            $response = @{}
            $response = Invoke-RestMethodAuthWrapperExceptionHandler $envData $requestParams $true

            Write-Host "Response from the above testcases is ----$response and $($response.memberId)"
            $response.ExceptionResponse.StatusCode.value__ | Should -be 400
           # $response.ErrorDetails.message | should -be "Invalid Principal Type. Valid ActivityLogStatusEnum are: User, Group, ServicePrincipal"
        }

        It "should throw error when accessLevel is ADMIN "{
            Write-Host " POST adding group to AD User..."

            $envData = GetOBOEnvironmentData $CurrentEnvironmentData "https://analysis.windows.net/powerbi/api/.default"
            $requestParams = @{
                Method = 'POST'
                Uri    = "/powerbi/api/v1/groupmembership"
                Body   = @{
                    "groupId" = $pbiGroup1
                    "memberId"= "$($memberUserIdAd)"
                    "memberType" = "user"
                    "accessLevel" = "Admin"
                } | ConvertTo-Json
            }

            $response = @{}
            $response = Invoke-RestMethodAuthWrapperExceptionHandler $envData $requestParams $true

            Write-Host "Response from the above testcases is ----$response and $($response.memberId)"
            $response.ExceptionResponse.StatusCode.value__ | Should -be 403
            $response.ErrorDetails.message | should -be "Digital Matrix does not support adding additional admins to PBI groups"
        }
    <#Context "POST powerBI- GroupMemebership -Testcases"{

        Write-Host " POST adding group to group..."

        $envData = GetOBOEnvironmentData $CurrentEnvironmentData "https://analysis.windows.net/powerbi/api/.default"
        $requestParams = @{
            Method = 'POST'
            Uri    = "/powerbi/api/v1/groupmembership"
            Body   = @{
                "groupId" = $($pbiGroup1)
                "memberId"= $($groupIdAd)
                "memberType" = "group"
                "accessLevel" = "viewer"
            } | ConvertTo-Json
        }
        $createResponse = $null
        $createResponse = Invoke-RestMethodAuthWrapper $envData $requestParams $true

        # this is test check
        #Adding group to AD Group
        Write-Host " POST adding group to AD User..."

        $envData = GetOBOEnvironmentData $CurrentEnvironmentData "https://analysis.windows.net/powerbi/api/.default"
        $requestParams = @{
            Method = 'POST'
            Uri    = "/powerbi/api/v1/groupmembership"
            Body   = @{
                "groupId" = $pbiGroup1
                "memberId"= $memberUserIdAd
                "memberType" = "user"
                "accessLevel" = "viewer"
            } | ConvertTo-Json
        }
        $usercreateResponse = $null
        $usercreateResponse = Invoke-RestMethodAuthWrapper $envData $requestParams $true


       } #>
    Context "Power BI- GET Group ids by Indexing and Page Size " {
            BeforeEach {
                #I have used Equivalant Partitioning for the checking page size (0,1,maxcount-1, maxcount)
                function GetGroupbyPageSize ($pagesize) {
                    Write-Host "Testcase to Check number of Groups with Page Size"
                    $requestParams = @{
                        Method = 'GET'
                        Uri    = "/powerbi/api/v1/group?pageIndex=0&pageSize=$($pagesize)"

                    }

                    $response = @{}
                    $response = Invoke-RestMethodAuthWrapper $envdata $requestParams $true
                   Write-Host "Number of group in response is $($response.count)"
                    return $response
                }
            }

            It "Should return one record when Page size is Totalcount+1" {
                $response = GetGroupbyPageSize($totalGroups + 1)
                Write-Host "Getting $($response.count) in response and search for $($totalGroups + 1) "
                $($response.count) | Should -be  $($totalGroups)
            }

            It "Should return one record when Page size is Totalcount" {
                $response = GetGroupbyPageSize($totalGroups)
                Write-Host "Getting $($response.count) in response and search for $($totalGroups) "
                $($response.count) | Should -be  $($totalGroups)
            }

            It "should return total group ids that is not null or empty" {
                #$retrieveGetAllGroupsResponse = GetGroupbyPageSize(1)
                $($retrieveGetAllGroupsResponse.count) | Should -Not -BeNullOrEmpty
            }

            It "Should return one record when Page size is 0" {

                $response = GetGroupbyPageSize(0)
                Write-Host "Getting $($response.count) in response and search for page size 1 "
                Write-Host "Response for this is comming as --- $response"
                $($response) | Should -BeNullOrEmpty
            }
            #condition Failing with response null
            <# It "Should return one record when Page size is 1" {
                $one = 1
                $response = GetGroupbyPageSize(1)
                Write-Host "Getting $($response.count) in response and search for page size 1 "
                Write-Host "Response for this is comming as --- $response[0]"
                $($response.count) | Should -Be $($one)
            }#>
            It "Should return one record when Page size is Totalcount-1" {
                $response = GetGroupbyPageSize($totalGroups - 1)
                Write-Host "Getting $($response.count) in response and search for $($totalGroups - 1) "
                $($response.count) | Should -be  $($totalGroups - 1)
            }
        }

        Context "PBI- Get Groupids with Invalid parameters- Negative" {
            #covering DM_PowerBI_API_05_01,DM_PowerBI_API_05_33,DM_PowerBI_API_05_34,DM_PowerBI_API_05_35,DM_PowerBI_API_05_38    ,DM_PowerBI_API_05_42
            It "when Searched with AplhaNumeric Search Text" {
                Write-Host " Get list of All group with /api/v1/group with Aplpha Numeric Search Text "
                $SearchText = "INVALIDSearchtext1234$%%#"

                $envdata = GetOBOEnvironmentData $CurrentEnvironmentData "https://analysis.windows.net/powerbi/api/.default"
                $requestParams = @{
                    Method = 'GET'
                    #Uri    = "/$($service)/api/v1/group?searchText=$($groupName)&pageIndex=0&pageSize=1000"
                    Uri    = "/powerbi/api/v1/group?searchText=$($SearchText)"
                }

                $retrieveResponse = @{}
                $retrieveResponse = Invoke-RestMethodAuthWrapper $envdata $requestParams $true

                $($retrieveResponse) | Should -BeNullOrEmpty
            }

            It "when Searched with Out- of range Page Size Value" {
                Write-Host "Testcase to Check number of Groups with Page Size"
                $pagesize = 9999999999
                $requestParams = @{
                    Method = 'GET'
                    Uri    = "/powerbi/api/v1/group?pageIndex=0&pageSize=$($pagesize)"
                }

                $response = @{}
                $response = Invoke-RestMethodAuthWrapperExceptionHandler $envdata $requestParams $true

                #Write-Host "Response is ---- $response and validating  $response.ErrorDetails.pageSize can do --- $response.pageSize "
                $response.ExceptionResponse.StatusCode.value__ | Should -be 400
                #$response.ErrorDetails.pageSize | should -be "The value '$($pagesize)' is not valid."
            }

            It "when Searched with Out- of range Page Size and Page Index Value" {
                Write-Host "Testcase to Check number of Groups with Page Size"
                #$pagesize = 9999999999
                $requestParams = @{
                    Method = 'GET'
                    Uri    = "/powerbi/api/v1/group?pageIndex=1234567890&pageSize=234567890"
                }

                $response = @{}
                $response = Invoke-RestMethodAuthWrapperExceptionHandler $envdata $requestParams $true

                $response.ExceptionResponse.StatusCode.value__ | Should -be 400
                $response.ErrorDetails.message | should -be "Operation returned an invalid status code 'BadRequest'"
            }
        }

        Context "Creating already existing group again - Negative" {
            It "Should get conflict error for creating the already existing group again"{
                Write-Host "Existing group creation"
                $requestParams = @{
                    Method = 'POST'
                    Uri    = "/$($service)/api/v1/group"
                    Body   = @{
                        "groupName" = "$($groupName)"
                    } | ConvertTo-Json
                }
    
                $response = @{}
                $response = Invoke-RestMethodAuthWrapperExceptionHandler $envdata $requestParams $true

                $response.ExceptionResponse.StatusCode.value__ | Should -be 409
                $response.ErrorDetails.message | should -be "There is already an existing Power BI group with this name: '$($groupName)'"

            }
        }

        Context "Adding same group to the existing group again - Negative" {
            It "Should get conflict error for adding the same group to the existing group again"{
                Write-Host "Adding same group to the existing group again"
                $requestParams = @{
                    Method = 'POST'
                    Uri    = "/powerbi/api/v1/groupmembership"
                    Body   = @{
                        "groupId" = $($pbiGroup1)
                        "memberId" = $($groupIdAd)
                        "memberType" = "group"
                        "accessLevel" = "viewer"
                    } | ConvertTo-Json
                }
    
                $response = @{}
                $response = Invoke-RestMethodAuthWrapperExceptionHandler $envdata $requestParams $true

                $response.ExceptionResponse.StatusCode.value__ | Should -be 409
                $response.ErrorDetails.message | should -be "Group $($groupIdAd) Already exists"
            }
        }

        AfterAll {
            Write-Host "AfterAll POST /api/v1/group"
            Write-Host "Deleting PBI groups..."

            $envData = GetOBOEnvironmentData $CurrentEnvironmentData "https://analysis.windows.net/powerbi/api/.default"

            Write-Host "Cleaning up after PBI group membership tests"

            # delete group pbiGroup1
            if ($pbiGroup1CreationSucceeded)
            {
                Delete-PBIGroup $envData $pbiGroup1
            }

            # delete group pbiGroup2
            if ($pbiGroup2CreationSucceeded)
            {
                Delete-PBIGroup $envData $pbiGroup2
            }

            #delete AD group
            if ($groupIdAdCreationSucceeded)
            {
                Delete-Group $CurrentEnvironmentData $groupIdAd
            }

            #delete member user
            if ($memberUserIdAdCreationSucceeded)
            {
                Delete-User $CurrentEnvironmentData $memberUserIdAd
            }
        }
    }
}