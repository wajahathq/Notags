param(

    [Parameter(Mandatory)]
    [ValidateNotNullOrEmpty()]
    $CurrentEnvironmentData

)
$script:contextId = Get-Date -Format "yyyyMMdd-HHmmss"
$Script:currentDate = Get-Date
$Script:endDate = (Get-Date).AddDays(20)
$Script:userName = $Env:UserName + "@" + $($CurrentEnvironmentData.Domain)
$enagagmentcode = "803000012512"
Describe "Workspace API - Product Creation" -Tag "long-running" {

    BeforeAll {
        $contextId = Get-Date -Format "yyyyMMddHHmmss"
        Write-Host "Creating a Product......"
        $script:productname = "TestProduct$($CurrentEnvironmentData.Environment)$($contextId)"
        $requestParams = @{
            Method = 'POST'
            Uri    = "/workspace/api/v1/product"
            Body   = @{
                "productName"        = $productname
                "engagementCode"     = "803000012512"  #this might change
                "expirationDateTime" = (Get-Date).AddDays(+1).ToString("yyyy-MM-ddThh:mm:ss.000Z")
                "requestedFor"       = @(
                    "sunidhinema@kpmg.com"
                )
            } | ConvertTo-Json
        }

        $response = @{}
        $response = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true
        $Producttaskid = $response.taskid
        Write-Host "Product Creation Task ID is ---- $Producttaskid"

        $productTaskResult = @{}
        $productTaskResult = Get-BackgroundStatus $CurrentEnvironmentData $Producttaskid "workspace"

        FailEarly 'Validate product creation' {
            $productTaskResult.status | Should -Be "Completed"
        }
        $Script:productId = $productTaskResult.taskOutput.productId
        Write-Host "Product Id... $($productId)"

        $Script:productgroupId = $productTaskResult.taskOutput.activeDirectoryGroupId

        # refer Defect 256896: DM Regression Automation - Unable to Create local Users using SPN accounts for SFTP Process Adding human User as a Owner to the product to perform SFTP
        Write-Host "Adding owner to ADGroup which has created while Product creation -- $productgroupId ..."

        $requestParams = @{
            Method = 'POST'
            Uri    = "/ad/api/v1/groupmembership/owners"
            Body   = @{
                "ownerId"   = "$($CurrentEnvironmentData.HumanownerId)"
                "groupId"   = "$($productgroupId)"
                "ownerType" = "user"
            } | ConvertTo-Json
        }

        $addGroupOwnerResponse = $null
        $addGropuOwnerResponse = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true $true 5

        $addGroupOwnerTaskResult = $null
        $addGroupOwnerTaskResult = Get-BackgroundStatus $CurrentEnvironmentData $addGropuOwnerResponse.taskId "ad"

        FailEarly 'Validate product creation' {
            $addGroupOwnerTaskResult.status | Should -Be "Completed"
        }

        Write-Host " User ID  has added to the Product to share ownership"

    }

    #Product Related Testcases
    Context "User Story 214790: QA Verify all endpoints related to products." {
        Context "Test Case 217840: TC_DM_WS_Product Creation" {
            Context "Validations on product creation" {
                It "should return a completed task result" {
                    $productTaskResult.status | Should -Be "Completed"
                }

                It "should return the correct activity type" {
                    $productTaskResult.taskOutput.activityType | Should -Be "Createproduct"
                }

                It "should create the workspace in less than 15 minutes" {
            ([timespan]($productTaskResult.duration)).Seconds | Should -BeLessOrEqual 900
                }

            }
            Context "Test Case 217840: Invalid Engagement code" {
                BeforeAll {
                    Write-Host "Test Case 217840: Invalid Engagement code"
                    $productname = "testproductfor_engagmentcode"
                    Write-Host "Product name is $($productname)...."
                    $requestParams = @{
                        Method = 'POST'
                        Uri    = "/workspace/api/v1/product"
                        Body   = @{
                            "productName"        = $productname
                            "engagementCode"     = "123456789098"  #Invalid Engagement code
                            "expirationDateTime" = (Get-Date).AddDays(+1).ToString("yyyy-MM-ddThh:mm:ss.000Z")
                            "requestedFor"       = @(
                                "sunidhinema@kpmg.com"
                            )
                        } | ConvertTo-Json
                    }

                    $response = @{}
                    $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true
                    Write-Host "response is ----- $($response.ErrorDetails.message)"

                }

                It "Should throw message for invalid Engagement code $($response.message)" {
                    $response.ErrorDetails.message | Should -be "Specified engagement code does not exist: 123456789098"
                }
                It "should have Status code 404" {
                    $response.ExceptionResponse.StatusCode.value__ | Should -be 404
                }
            }
            Context "Test Case 217840:Invalid Expiration Date (ideallly should be more than 1 hour from now)" {
                BeforeAll {
                    Write-Host "Test Case 217840:Invalid Expiration Date"
                    $script:productname = "testproductfor_Expirationdate"
                    Write-Host "Product name is $($productname)...."
                    $requestParams = @{
                        Method = 'POST'
                        Uri    = "/workspace/api/v1/product"
                        Body   = @{
                            "productName"        = $productname
                            "engagementCode"     = "803000012512"  #Valid Engagement code
                            "expirationDateTime" = (Get-Date).AddDays(-1).ToString("yyyy-MM-ddThh:mm:ss.000Z")
                            "requestedFor"       = @(
                                "sunidhinema@kpmg.com"
                            )
                        } | ConvertTo-Json

                    }

                    $response = @{}
                    $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true


                }
                It "Should throw message for invalid Engagement code" {
                    $response.ErrorDetails.message | Should -be "Product expiration date must be at least one hour from now."
                }
                It "should have Status code 400" {
                    $response.ExceptionResponse.StatusCode.value__ | Should -be 400
                }
            }
            Context "Test Case 217840: Product with Invalid  EMAIL address for Requested For" {
                BeforeAll {
                    Write-Host "Test Case 217840: Product with Invalid  EMAIL address for Requested For"
                    $productname = "testproductfor_Invalidemail"
                    Write-Host "Product name is $($productname)...."
                    $requestParams = @{
                        Method = 'POST'
                        Uri    = "/workspace/api/v1/product"
                        Body   = @{
                            "productName"        = $productname
                            "engagementCode"     = "803000012512"  #valid Engagement code
                            "expirationDateTime" = (Get-Date).AddDays(+1).ToString("yyyy-MM-ddThh:mm:ss.000Z")
                            "requestedFor"       = @(
                                "Invalidmail"
                            )
                        } | ConvertTo-Json


                    }
                    $response = @{}
                    $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true


                }

                It "Should throw message for invalid Engagement code" {
                    $response.ErrorDetails.message | Should -be " : 'Invalidmail' is not in a valid format"
                }
                It "should have Status code 400" {
                    $response.ExceptionResponse.StatusCode.value__ | Should -be 400
                }

            }
            #Question - unable to Fetch Value from Error formated in array []
            Context "Test Case 217840: Product with ProductName more than 50 Char" {
                BeforeAll {
                    Write-Host "Test Case 217840: Product with ProductName more than 50 Char"
                    $requestParams = @{
                        Method = 'POST'
                        Uri    = "/workspace/api/v1/product"
                        Body   = @{
                            "productName"        = "Productwith50char123456789009876543211234567890end6363636"
                            "engagementCode"     = "803000012512"  #valid Engagement code
                            "expirationDateTime" = (Get-Date).AddDays(+1).ToString("yyyy-MM-ddThh:mm:ss.000Z")
                            "requestedFor"       = @(
                                "sunidhinema@kpmg.com"
                            )
                        } | ConvertTo-Json
                    }

                    $response = @{}
                    $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true

                }


                It "should have Status code 400" {
                    $response.ExceptionResponse.StatusCode.value__ | Should -be 400
                }

            }

        }
        Context "Test Case 217847: TC_DM_WS_Update Product" {

            BeforeAll {
                Write-Host "Updating a Product where increaing the Expiration date by 1 day..."
                $script:productname = "TestProduct$($CurrentEnvironmentData.Environment)$($contextId)"
                $datetoUpdate = (Get-Date).AddDays(+1).ToString("yyyy-MM-ddThh:mm:ss.000Z")
                Write-Host "Date to update is  ---- $datetoUpdate "
                $requestParams = @{
                    Method = 'PUT'
                    Uri    = "/workspace/api/v1/product/$($productId)"
                    Body   = @{
                        "expirationDateTime" = $datetoUpdate

                    } | ConvertTo-Json
                }

                $response = @{}
                $response = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true

                #Get Updated Details for Product
                Write-Host "Get Details for Product Id... $($productId) Updated with New Expiy date"

                $requestParams = @{
                    Method = 'GET'
                    Uri    = "/workspace/api/v1/product/$($productId)"
                }
                $response = @{}
                $response = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true
            }
            It "should have updated date" {
                $response.productId | Should -Be $productId
            }

        }
        Context "Test Case 219388: TC_DM_WS_Update Product Negative - Expiration date less than current date " {

            BeforeAll {
                Write-Host "Updating a Product Expiration date where the Expiration date is Lesser then current date...."
                $requestParams = @{
                    Method = 'PUT'
                    Uri    = "/workspace/api/v1/product/$($productId)"
                    Body   = @{
                        "expirationDateTime" = (Get-Date).AddDays(-1).ToString("yyyy-MM-ddThh:mm:ss.000Z")
                    } | ConvertTo-Json
                }

                $response = @{}
                $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true

            }
            It "Should throw message for invalid Engagement code" {
                $response.ErrorDetails.message | Should -be "Product expiration date must be at least one hour from now."
            }
            It "should have Status code 400" {
                $response.ExceptionResponse.StatusCode.value__ | Should -be 400
            }

        }
        Context "Test Case 219388: TC_DM_WS_Update Product Negative - Invalid Status " {

            BeforeAll {
                Write-Host "Updating a Product with Invalid Status - Should throw Error"
                $requestParams = @{
                    Method = 'PUT'
                    Uri    = "/workspace/api/v1/product/$($productId)"
                    Body   = @{
                        "status" = "testnegative"
                    } | ConvertTo-Json
                }

                $response = @{}
                $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true

            }
            It "should have Status code 400" {
                $response.ExceptionResponse.StatusCode.value__ | Should -be 400
            }

        }
    }

    #Data Transfer Process
    Context "User Story 219741: QA Verify Data Transfer and Malware capabilities" {
        BeforeAll {
            Write-Host "Creating Product Componets using Product Blueprints"
            $ProductComponetName = (New-Guid).ToString().Substring(0, 5)
            $requestParams = @{
                Method = 'POST'
                Uri    = "/workspace/api/v1/product/$($productId)/component"
                Body   = @{
                    "componentName" = "publicpc_$($productId)_$($ProductComponetName)"
                    "blueprintKey"  = "dmz-storage-container"
                } | ConvertTo-Json
            }

            $createResponse1 = $null
            $createResponse1 = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true

            Write-Host "Creating Another Public Container for Data transfer process"
            $ProductComponetName2 = (New-Guid).ToString().Substring(0, 5)
            $requestParams = @{
                Method = 'POST'
                Uri    = "/workspace/api/v1/product/$($productId)/component"
                Body   = @{
                    "componentName" = "publicpc_$($productId)_$($ProductComponetName2)"
                    "blueprintKey"  = "dmz-storage-container"
                } | ConvertTo-Json
            }

            $createResponse = $null
            $createResponse = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true

            #Running Background task for Product Compoents

            $createTaskResult1 = $null
            $createTaskResult1 = Get-BackgroundStatus $CurrentEnvironmentData $createResponse1.taskId "workspace"

            $createTaskResult = $null
            $createTaskResult = Get-BackgroundStatus $CurrentEnvironmentData $createResponse.taskId "workspace"

            $script:publicproductcomponent2 = $createTaskResult.taskOutput.componentId

            $script:publicproductcomponent1 = $createTaskResult1.taskOutput.componentId

            FailEarly 'Validate Workspace created' {
                $createTaskResult1.status | Should -Be "Completed"
            }

            FailEarly 'Validate Workspace created' {
                $createTaskResult.status | Should -Be "Completed"
            }

            Write-Host "Public Container for $($productId) is $($publicproductcomponent2)"
            Write-Host "Public Container for $($productId) is $($publicproductcomponent1)"

            #Fetching the public container details
            $requestParams = @{
                Method = 'GET'
                Uri    = "/workspace/api/v1/product/$($productId)/component/$($publicproductcomponent1)/part"
            }
            $PublicContainerDetailResponse = @{}
            $PublicContainerDetailResponse = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true

            $sourceStorageAccountName = $($PublicContainerDetailResponse.remoteParts[1].propertyKeyValuePairs.storageAccountName)
            $sourceContainerName = $($PublicContainerDetailResponse.remoteParts[1].propertyKeyValuePairs.containerName)

            Write-Host "Source Account Storage name is = $($sourceStorageAccountName)========="
            Write-Host "Source Container Name is = $($sourceContainerName)===="

            #details for public container 2
            #Fetching the public container details
            $requestParams = @{
                Method = 'GET'
                Uri    = "/workspace/api/v1/product/$($productId)/component/$($publicproductcomponent2)/part"
            }
            $PublicContainerDetailResponse = @{}
            $PublicContainerDetailResponse = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true

            $sourceStorageAccountName2 = $($PublicContainerDetailResponse.remoteParts[1].propertyKeyValuePairs.storageAccountName)
            $sourceContainerName2 = $($PublicContainerDetailResponse.remoteParts[1].propertyKeyValuePairs.containerName)

            Write-Host "Source Account Storage for $publicproductcomponent2 is = $($sourceStorageAccountName2)======="
            Write-Host "Source Container Name for $publicproductcomponent2 = $($sourceContainerName2)===="

            Write-Host "Non Malicious File Upload to $publicproductcomponent1"
            $Cleanfilepath = "DMZtestfile.txt"
            $root = "./"
            $fileContent = "This is my Clean Sample Test file for Upload "
            New-DynamicFile -FileName $Cleanfilepath -FileContent $fileContent
            Write-Host "File name for a Clean file $Cleanfilepath"
            #Defining new Approch
            $IsUploaded_Cleanfile = FileUploadUsingAzConnect $Cleanfilepath $sourceContainerName $root
            Write-host "$IsUploaded_Cleanfile - value"

            # FailEarly 'Validate if Upload is Successful' {
            #  Write-Host "value should be -  $($IsUploaded_Cleanfile.Value) "
            # $($IsUploaded_Cleanfile.Value) | Should -eq  $true
            # }

            Write-Host  "File Uploaded in Azure stroage for $($sourceContainerName)"
            #Uploading Malicious File
            Write-Host "Started Uploading - Malicious File"

            #Create a dynamic Malicious File
            $Malfilepath = "maltestfile.txt"
            $EICARCODE = 'X5O!P%@AP[4\PZX54(P^)7CC)7}$EICAR-STANDARD-ANTIVIRUS-TEST-FILE!$H+H*'
            $fileContent = "This is Simple Text file without EICAR CODE"
            New-DynamicFile -FileName $Malfilepath -FileContent $fileContent
            Write-Host "File name for a Mal file $Malfilepath"


            Write-Host "File Upload started in $publicproductcomponent1"
            $IsUploaded_Malfile = FileUploadUsingAzConnect $Malfilepath $sourceContainerName $root
            Write-host "$IsUploaded_Malfile - value"

            #FailEarly 'Validate if Upload is Successful' {
            #   Write-Host "$($IsUploaded_Malfile.value) "
            #  $IsUploaded_Malfile.Value | -eq $true
            # }
            Write-Host  "Mal File Uploaded in azure storage for $($sourceContainerName)"

            try {
                Write-Host "Appending Eicar code into the $Malfilepath"
                $Context = New-AzStorageContext -StorageAccountName $($CurrentEnvironmentData.SAccountName)
                $storageBlob = Get-AzStorageBlob -Blob $Malfilepath -Container $sourceContainerName -Context $Context
                $storageBlob.ICloudBlob.UploadText($EICARCODE)
                Write-Host "Eicar code is appended in $Malfilepath file"
            }
            catch {
                Write-Host "An error occurred: $($_.Exception.Message)"
            }
        }

        It "to verify Sample File data Trasnfer and Scanning on a Clean file Where deleteFromSourceAfterSuccess = false" {
            #DataTransfer Process
            Write-Host "Running Only Data Trasfer Assertion for $Cleanfilepath"
            $requestParams = @{
                Method = 'POST'
                Uri    = "/workspace/api/v1/product/$($productId)/datatransfer"
                Body   = @{
                    "sourceStorageAccountName"     = "$($sourceStorageAccountName)"
                    "sourceContainerName"          = "$($sourceContainerName)"
                    "targetStorageAccountName"     = "$($sourceStorageAccountName2)"
                    "targetContainerName"          = "$($sourceContainerName2)"
                    "actions"                      = @(
                        "DataTransfer" , "MalwareScan"
                    )
                    "deleteFromSourceAfterSuccess" = $false
                    "filePaths"                    = @(
                        $($Cleanfilepath)
                    )
                } | ConvertTo-Json
            }

            $transferResponse = $null
            $transferResponse = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true
            Write-Host "Task id for Normal file datatrasnfer and  Scan is - $($transferResponse.taskId) and File name is - $Cleanfilepath "
            $tranferTaskResult = $null
            $tranferTaskResult = Get-BackgroundStatus $CurrentEnvironmentData $($transferResponse.taskId) "workspace"
            Write-Host  "File Transfer and MalwareScaning sucessful in $($sourceContainerName2)"

            FailEarly 'Validate File transfer is completed' {
                $tranferTaskResult.status | Should -Be "Completed"
            }

            #Start-Sleep -Seconds 100
            $requestParams = @{
                Method = 'GET'
                Uri    = "/workspace/api/v1/product/$($productId)/datatransfer/$($tranferTaskResult.taskId)/filestatus?includeAllMessages=true&includeActions=true"
            }
            $DummyFileStatusResponse = @{}
            $DummyFileStatusResponse = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true
            Write-Host  "File Status Status is - $($DummyFileStatusResponse.actions[1].status) "
            $DummyFileStatusResponse.filePath | Should -Be $Cleanfilepath
            $DummyFileStatusResponse.actions[1].actionName | Should -Be "DataTransfer"
            $DummyFileStatusResponse.actions[1].status | Should -Be "Completed"
        }
        It "to verify Sample File data Trasnfer and Scanning on a Clean file Where deleteFromSourceAfterSuccess = true" {
            #DataTransfer Process
            Write-Host "Running Only Data Trasfer Assertion for $Cleanfilepath"
            $requestParams = @{
                Method = 'POST'
                Uri    = "/workspace/api/v1/product/$($productId)/datatransfer"
                Body   = @{
                    "sourceStorageAccountName"     = "$($sourceStorageAccountName)"
                    "sourceContainerName"          = "$($sourceContainerName)"
                    "targetStorageAccountName"     = "$($sourceStorageAccountName2)"
                    "targetContainerName"          = "$($sourceContainerName2)"
                    "actions"                      = @(
                        "DataTransfer" , "MalwareScan"
                    )
                    "deleteFromSourceAfterSuccess" = $true
                    "filePaths"                    = @(
                        $($Cleanfilepath)
                    )
                } | ConvertTo-Json
            }

            $transferResponse = $null
            $transferResponse = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true
            Write-Host "Task id for Normal file datatrasnfer and  Scan is - $($transferResponse.taskId) and File name is - $Cleanfilepath "
            $tranferTaskResult = $null
            $tranferTaskResult = Get-BackgroundStatus $CurrentEnvironmentData $($transferResponse.taskId) "workspace"
            Write-Host  "File Transfer and MalwareScaning sucessful in $($sourceContainerName2)"

            FailEarly 'Validate File transfer is completed' {
                $tranferTaskResult.status | Should -Be "Completed"
            }

            Write-Host "Checking File is deleted from Stroage Account"
            $Context = New-AzStorageContext -StorageAccountName $($CurrentEnvironmentData.SAccountName)
            #$storageBlob = Get-AzStorageBlob -Blob $Malfilepath -Container $sourceContainerName -Context $Context
            $blobs = Get-AzStorageBlob -Context $Context -Container $sourceContainerName
            foreach ($blob in $blobs) {
                $fileName = $blob.Name.Split("/")[-1]
                Write-Host "Inside foreach loop for $($blob.Name) and file name extracted $fileName"
                if ($fileName -eq $Cleanfilepath) {
                    Write-Host "$fileName is equals to $Cleanfilepath "
                    $fileExists = $true
                    Write-Host "$fileName is not deleted from the source"
                    break
                }
                elseif ($fileName -eq $Malfilepath) {
                    Write-Host "File $fileName is available in the storage for further testcases"
                    $fileExists = $false
                }
                else {
                    Write-Host "PASS - File has been deleted from the source $fileName"
                    $fileExists = $false
                }

            }

            $fileExists | Should -Be $false
            Write-Host "File has been deleted from the source"

        }
        #Testcase Scanning a Malicious File
        It "Verify Malscan for Malicious file and status should be failed" {
            Write-Host "Scanning started for Mal File - on $Malfilepath"
            $Filecontent = Get-AzStorageBlob -Blob $Malfilepath -Container $sourceContainerName -Context $Context
            Write-Host "Content of $Malfilepath is ---- $Filecontent "
            #MalwareScan Process
            $requestParams = @{
                Method = 'POST'
                Uri    = "/workspace/api/v1/product/$($productId)/datatransfer"
                Body   = @{
                    "sourceStorageAccountName"     = "$($sourceStorageAccountName)"
                    "sourceContainerName"          = "$($sourceContainerName)"
                    "actions"                      = @(
                        "MalwareScan"
                    )
                    "deleteFromSourceAfterSuccess" = $false
                    "filePaths"                    = @(
                        $($Malfilepath)
                    )
                } | ConvertTo-Json
            }

            $ScanResponse = $null
            $ScanResponse = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true
            Write-Host "Task id for Mal Scan is - $($ScanResponse.taskId) and File name is - $Malfilepath "
            $ScanTaskResult = $null
            $ScanTaskResult = Get-BackgroundStatus $CurrentEnvironmentData $($ScanResponse.taskId) "workspace"

            Write-Host  "MalwareScaning sucessful in $($sourceContainerName) and File $Malfilepath is Malicious"

            #Check File Status
            Start-Sleep -Seconds 100
            $requestParams = @{
                Method = 'GET'
                Uri    = "/workspace/api/v1/product/$($productId)/datatransfer/$($ScanResponse.taskId)/filestatus?includeAllMessages=true&includeActions=true"
            }
            $FileStatusResponse = @{}
            $FileStatusResponse = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true
            Write-Host  "File Status Status is - $($FileStatusResponse.actions.status) "
            $FileStatusResponse.filePath | Should -Be $Malfilepath
            $FileStatusResponse.actions.actionName | Should -Be "MalwareScan"
            $FileStatusResponse.actions.status | Should -Be "Failed"
        }


    }

    #Product Component
    Context "User Story 214797: QA Verify all endpoints related to product Component" {
        Context "Test Case 230301: TC_DM_WS_Create ProductComponent for Product" {
            BeforeAll {
                Write-Host "Creating Product Componets using Product Blueprints = empty-resource-group"
                $ProductComponetName = (New-Guid).ToString().Substring(0, 5)
                $requestParams = @{
                    Method = 'POST'
                    Uri    = "/workspace/api/v1/product/$($productId)/component"
                    Body   = @{
                        "componentName" = "emptypc_$($productId)_$($ProductComponetName)"
                        "blueprintKey"  = "empty-resource-group"
                    } | ConvertTo-Json
                }

                $createResponse = $null
                $createResponse = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true

                $createTaskResult = $null
                $createTaskResult = Get-BackgroundStatus $CurrentEnvironmentData $createResponse.taskId "workspace"
                FailEarly 'Validate Workspace created' {
                    $createTaskResult.status | Should -Be "Completed"
                }
                $Script:emptyproductcomponent1 = $createTaskResult.taskOutput.componentId

                Write-Host "Empty Container for $($productId) is $($emptyproductcomponent1)"


            }
            It "should return a completed task result" {
                $createTaskResult.status | Should -Be "Completed"
            }

            It "should create the resource collection in less than 30 minutes" {
             ([timespan]($createTaskResult.duration)).Seconds | Should -BeLessOrEqual 1800
            }
        }
        Context "Test Case 230305: TC_DM_WS_Fetch List of components by ProductId" {
            BeforeAll {
                $requestParams = @{
                    Method = 'GET'
                    Uri    = "/workspace/api/v1/product/$($productId)/component"
                }

                $response = @{}
                $response = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true
                Write-Host "response Array count --- $($response.Count) "
                $script:componentarray = $response.componentId
                $script:totalcomponent = $($response.Count)
            }
            It "should retrun componenet Details associated with Product " {
                $response.count | Should -Not -BeNullOrEmpty
            }
        }
        Context "Test Case 230306: TC_DM_WS_Update Metadata of a specified ProductComponent" {
            BeforeAll {
                Write-Host "Updating Product Component = $publicproductcomponent1 Details but Updating status as DeletingFailed  "

                $requestParams = @{
                    Method = 'PUT'
                    Uri    = "/workspace/api/v1/product/$($productId)/component/$($publicproductcomponent1)"
                    Body   = @{
                        "status" = "DeletingFailed"
                    } | ConvertTo-Json
                }

                $response = $null
                $response = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true

                Write-Host " Updated $($publicproductcomponent1)"

                Write-Host "Get Product details with Updated State"
                $requestParams = @{
                    Method = 'GET'
                    Uri    = "/workspace/api/v1/product/$($productId)/component/$($publicproductcomponent1)"
                }

                $response = $null
                $response = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true

                Write-Host "status is $($response.status) "



            }
            It "should retrun Message for Invalid Component" {
                $response.status | Should -be "DeletingFailed"
            }

        }
        Context "Test Case 219388: TC_DM_WS_Update Invalid State of Product Component Negative" {
            BeforeAll {
                Write-Host "Fetching the Component by Invalid ComponentId and ProductId"

                $requestParams = @{
                    Method = 'PUT'
                    Uri    = "/workspace/api/v1/product/$($productId)/component/$($publicproductcomponent1)"
                    Body   = @{
                        "status" = "Invalid state"
                    } | ConvertTo-Json
                }

                $response = @{}
                $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true
                Write-Host " Updated $($publicproductcomponent1)"


            }
            It "should retrun 400 for Invalid State " {
                $response.ExceptionResponse.StatusCode.value__ | Should -be 400
            }

        }
        Context "Test Case 230302: TC_DM_WS_Create ProductComponent Negative TC --- Invalid Component name" {
            BeforeAll {
                Write-Host "Creating Product Componets with  invalid Component Name "

                $requestParams = @{
                    Method = 'POST'
                    Uri    = "/workspace/api/v1/product/$($productId)/component"
                    Body   = @{
                        "componentName" = "Special&^*(^*^)CharIN NAME"
                        "blueprintKey"  = "empty-resource-group"
                    } | ConvertTo-Json
                }

                $response = @{}
                $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true

                Write-Host "Empty Container for $($productId) is not get Created due to invalid name $($response.ErrorDetails.message)"


            }
            It "should retrun error Msg for Invalid Compoent name " {
                $($response.ErrorDetails.message) | Should -be "Product Component name contains invalid characters. Names can include alphanumeric, underscore, parentheses, hyphen, period (except at end), and Unicode characters that match the allowed characters."
            }

        }
        Context "Test Case 230302: TC_DM_WS_Create ProductComponent Negative TC  -- Invalid Blueprint name" {
            BeforeAll {
                Write-Host "Creating Product Componets where Invalid BluePrint"
                $ProductComponetName = (New-Guid).ToString().Substring(0, 5)
                $requestParams = @{
                    Method = 'POST'
                    Uri    = "/workspace/api/v1/product/$($productId)/component"
                    Body   = @{
                        "componentName" = "emptypc_$($productId)_$($ProductComponetName)"
                        "blueprintKey"  = "Invalid_Blueprint"
                    } | ConvertTo-Json
                }

                $response = @{}
                $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true

                Write-Host "Empty Container for $($productId) is not get created due to invalid blueprint --- $($response.ErrorDetails.message)"


            }
            It "should retrun error Msg for Invalid Compoent name " {
                $($response.ErrorDetails.message) | Should -be "Blueprint with specified Key not found: Invalid_Blueprint"
            }

        }
        Context "Test Case 230304: TC_DM_WS_Fetch the Component by ComponentId and ProductId Negative TC" {
            BeforeAll {
                Write-Host "Fetching the Component by Invalid ComponentId and ProductId"
                #  fetching  Random values for the Ids from max value
                $prodId = Get-Random -Minimum 111111111 -Maximum 999999999
                $Compid = Get-Random -Minimum 111111111 -Maximum 999999999
                $requestParams = @{
                    Method = 'GET'
                    Uri    = "/workspace/api/v1/product/$($prodId)/component/$($Compid)"
                }

                $response = @{}
                $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true

                Write-Host "Product Component with specified ID not found: $($Compid) ---- $($response.ErrorDetails.message)"


            }
            It "should retrun Message for Invalid Component" {
                $($response.ErrorDetails.message) | Should -be "Product Component with specified ID not found: $($Compid)"
            }

        }

    }
    #Storage Logs
    Context "Workspace - SEARCH ALL DMZ STORAGE LOGS" {
        Context "List of all storage logs" {
            BeforeAll {
                $requestParams = @{
                    Method = 'POST'
                    Uri    = "/workspace/api/v1/product/$($productId)/component/$($publicproductcomponent1)/storageaccount/storagebloblogs"
                    Body   = @{
                        "pageSize"      = 100
                        "pageIndex"     = 10
                        "startDate"     = $($currentDate)
                        "endDate"       = $($endDate)
                        "isSuccess"     = $true
                        "statusCode"    = 200
                        "operationName" = "GetBlobServiceProperties"
                        "upn"           = $($userName)
                        "directoryPath" = $($userName)
                    } | ConvertTo-Json
                }
                $ListOfAllStorageLogs = @{}
                $ListOfAllStorageLogs = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true

            }

            It "Should return 200 response for all storage logs" {
                $ListOfAllStorageLogs.count | should -BeGreaterOrEqual 0
            }
        }


        Context "Fetching all logs where startDate is greater than endDate (Negative TC)" {
            BeforeAll {
                $requestParams = @{
                    Method = 'POST'
                    Uri    = "/workspace/api/v1/product/$($productId)/component/$($publicproductcomponent1)/storageaccount/storagebloblogs"
                    Body   = @{
                        "startDate" = "2023-06-01T09:37:11.980Z"
                        "endDate"   = "2023-05-30T09:37:11.980Z"
                    } | ConvertTo-Json
                }
                $response = @{}
                $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true
            }

            It "Should throw 400 bad request where startDate > endDate" {
                $response.ErrorDetails.message | should -eq "End date should be greater than or equal to start date."
            }
        }


        Context "Fetching all logs where pageSize is String type (Negative TC)" {
            BeforeAll {
                $requestParams = @{
                    Method = 'POST'
                    Uri    = "/workspace/api/v1/product/$($productId)/component/$($publicproductcomponent1)/storageaccount/storagebloblogs"
                    Body   = @{
                        "pageSize" = "hdsfh"
                    } | ConvertTo-Json
                }
                $response = @{}
                $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true
            }

            It "Should throw 400 bad request where pageSize is String type" {
                $response.ErrorDetails.title | should -eq "One or more validation errors occurred."
            }
        }


        Context "Fetching  all logs where pageSize is too large (Negative TC)" {
            BeforeAll {
                $requestParams = @{
                    Method = 'POST'
                    Uri    = "/workspace/api/v1/product/$($productId)/component/$($publicproductcomponent1)/storageaccount/storagebloblogs"
                    Body   = @{
                        "pageSize" = 111111111111111
                    } | ConvertTo-Json
                }
                $response = @{}
                $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true
            }

            It "Should throw 400 bad request where pageSize is too large" {
                $response.ErrorDetails.title | should -eq "One or more validation errors occurred."
            }
        }


        Context "Fetching  all logs where pageIndex is String type (Negative TC)" {
            BeforeAll {
                $requestParams = @{
                    Method = 'POST'
                    Uri    = "/workspace/api/v1/product/$($productId)/component/$($publicproductcomponent1)/storageaccount/storagebloblogs"
                    Body   = @{
                        "pageIndex" = "djhs"
                    } | ConvertTo-Json
                }
                $response = @{}
                $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true
            }

            It "Should throw 400 bad request where pageIndex is String type" {
                $response.ErrorDetails.title | should -eq "One or more validation errors occurred."
            }
        }


        Context "Fetching  all logs where pageIndex is too large (Negative TC)" {
            BeforeAll {
                $requestParams = @{
                    Method = 'POST'
                    Uri    = "/workspace/api/v1/product/$($productId)/component/$($publicproductcomponent1)/storageaccount/storagebloblogs"
                    Body   = @{
                        "pageIndex" = 10000000000000
                    } | ConvertTo-Json
                }
                $response = @{}
                $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true
            }

            It "Should throw 400 bad request where pageIndex is too large" {
                $response.ErrorDetails.title | should -eq "One or more validation errors occurred."
            }
        }

        Context "Fetching  all logs for invalid startDate format (Negative TC)" {
            BeforeAll {
                $requestParams = @{
                    Method = 'POST'
                    Uri    = "/workspace/api/v1/product/$($productId)/component/$($publicproductcomponent1)/storageaccount/storagebloblogs"
                    Body   = @{
                        "startDate" = "2023-13"
                    } | ConvertTo-Json
                }
                $response = @{}
                $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true
            }

            It "Should throw 400 bad request for invalid startDate format" {
                $response.ErrorDetails.title | should -eq "One or more validation errors occurred."
            }
        }

        Context "Fetching  all logs for invalid endDate format (Negative TC)" {
            BeforeAll {
                $requestParams = @{
                    Method = 'POST'
                    Uri    = "/workspace/api/v1/product/$($productId)/component/$($publicproductcomponent1)/storageaccount/storagebloblogs"
                    Body   = @{
                        "endDate" = "202-15"
                    } | ConvertTo-Json
                }
                $response = @{}
                $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true
            }

            It "Should throw 400 bad request for invalid endDate format" {
                $response.ErrorDetails.title | should -eq "One or more validation errors occurred."
            }
        }


        Context "Fetching  all logs where isSuccess is String type (Negative TC)" {
            BeforeAll {
                $requestParams = @{
                    Method = 'POST'
                    Uri    = "/workspace/api/v1/product/$($productId)/component/$($publicproductcomponent1)/storageaccount/storagebloblogs"
                    Body   = @{
                        "isSuccess" = "dfsdfsfsd"
                    } | ConvertTo-Json
                }
                $response = @{}
                $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true
            }

            It "Should throw 400 bad request where isSuccess is String type" {
                $response.ErrorDetails.title | should -eq "One or more validation errors occurred."
            }
        }

        Context "Fetching  all logs where statusCode is String type (Negative TC)" {
            BeforeAll {
                $requestParams = @{
                    Method = 'POST'
                    Uri    = "/workspace/api/v1/product/$($productId)/component/$($publicproductcomponent1)/storageaccount/storagebloblogs"
                    Body   = @{
                        "statusCode" = "sdrtrt"
                    } | ConvertTo-Json
                }
                $response = @{}
                $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true
            }

            It "Should throw 400 bad request where statusCode is String type" {
                $response.ErrorDetails.title | should -eq "One or more validation errors occurred."
            }
        }

        Context "Fetching  all logs where operationName is integer type (Negative TC)" {
            BeforeAll {
                $requestParams = @{
                    Method = 'POST'
                    Uri    = "/workspace/api/v1/product/$($productId)/component/$($publicproductcomponent1)/storageaccount/storagebloblogs"
                    Body   = @{
                        "operationName" = 123456
                    } | ConvertTo-Json
                }
                $response = @{}
                $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true
            }

            It "Should throw 400 bad request where operationName is integer type" {
                $response.ErrorDetails.title | should -eq "One or more validation errors occurred."
            }
        }

        Context "Fetching   all logs where upn is integer type (Negative TC)" {
            BeforeAll {
                $requestParams = @{
                    Method = 'POST'
                    Uri    = "/workspace/api/v1/product/$($productId)/component/$($publicproductcomponent1)/storageaccount/storagebloblogs"
                    Body   = @{
                        "upn" = 123456
                    } | ConvertTo-Json
                }
                $response = @{}
                $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true
            }

            It "Should throw 400 bad request where upn is integer type" {
                $response.ErrorDetails.title | should -eq "One or more validation errors occurred."
            }
        }


        Context "Fetching all logs where directoryPath is integer type (Negative TC)" {
            BeforeAll {
                $requestParams = @{
                    Method = 'POST'
                    Uri    = "/workspace/api/v1/product/$($productId)/component/$($publicproductcomponent1)/storageaccount/storagebloblogs"
                    Body   = @{
                        "directoryPath" = 123456
                    } | ConvertTo-Json
                }
                $response = @{}
                $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true
            }

            It "Should throw 400 bad request where directoryPath is integer type" {
                $response.ErrorDetails.title | should -eq "One or more validation errors occurred."
            }
        }


        Context "Fetching all logs where statusCode is 0 (Negative TC)" {
            BeforeAll {
                $requestParams = @{
                    Method = 'POST'
                    Uri    = "/workspace/api/v1/product/$($productId)/component/$($publicproductcomponent1)/storageaccount/storagebloblogs"
                    Body   = @{
                        "statusCode" = 0
                    } | ConvertTo-Json
                }
                $response = @{}
                $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true
            }

            It "Should throw 400 bad request where statusCode is 0" {
                $response.ErrorDetails.message | should -eq "Status Code must be a positive integer."
            }
        }
    }

    #All testcases related to SFTP DMZ File Transfer
    Context "Feature 227947: ATOP 7028 - SFTP Login for DMZ" {
        Context "Test Case 247687: ST_TC_DM SFTP_#243262_To verify creation of Local User for  SFTP Login " {
            BeforeAll {

                Write-Host "Using Same product and product Component for creating Local user"
                $script:LocalUserproductId = $productId
                $script:LocalUserproductComponentId = $publicproductcomponent1

                Write-Host "Creating Single SFTP Local user Account"

                $script:localusername = "test1$($CurrentEnvironmentData.Environment)$($contextId)"
                Write-Host "This is the user name $localusername"
                $requestParams = @{
                    Method = 'POST'
                    Uri    = "/workspace/api/v1/product/$($LocalUserproductId)/component/$($LocalUserproductComponentId)/storageaccount/sftplocaluser"
                    Body   = @{
                        "userName" = $localusername.ToLower()

                    } | ConvertTo-Json
                }

                $response = @{}
                $response = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true
                $localUsertaskid = $response.taskid
                Write-Host "Local User Creation Task ID is ---- $localUsertaskid"

                $localuserTaskResult = @{}
                $localuserTaskResult = Get-BackgroundStatus $CurrentEnvironmentData $localUsertaskid "workspace"

                FailEarly 'Validate product creation' {
                    $localuserTaskResult.status | Should -Be "Completed"
                }

                $script:localuserresponsename = $localuserTaskResult.taskOutput.userName
                Write-Host "Local user created and its name as ... $($localuserresponsename)"

            }
            It "should return activity Type for local user creation" {
                $localuserTaskResult.taskOutput.activityType | Should -Be "CreateSftpLocalUserAccount"
            }
            It "should return " {
                $localuserTaskResult.status | Should -Be "Completed"
            }
        }
        Context "Test Case 247717: ST_TC_DM SFTP_#243262_To verify Multiple Local user creation for SFTP Login" {
            BeforeAll {

                Write-Host "Creating Multiple SFTP Local user Account"
                $localusername2 = "test2$($CurrentEnvironmentData.Environment)$($contextId)"
                Write-Host "This is the user name $localusername2"
                $requestParams = @{
                    Method = 'POST'
                    Uri    = "/workspace/api/v1/product/$($LocalUserproductId)/component/$($LocalUserproductComponentId)/storageaccount/sftplocaluser"
                    Body   = @{
                        "userName" = $localusername2.ToLower()

                    } | ConvertTo-Json
                }

                $response = @{}
                $response = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true
                $localUsertaskid = $response.taskid
                Write-Host "Local User Creation Task ID is ---- $localUsertaskid"

                $localuserTaskResult = @{}
                $localuserTaskResult = Get-BackgroundStatus $CurrentEnvironmentData $localUsertaskid "workspace"

                FailEarly 'Validate product creation' {
                    $localuserTaskResult.status | Should -Be "Completed"
                }

                $localuserresponsename2 = $localuserTaskResult.taskOutput.userName
                Write-Host "Local user created and its name as ... $($localuserresponsename2)"

            }
            It "should return activity Type for local user creation" {
                $localuserTaskResult.taskOutput.activityType | Should -Be "CreateSftpLocalUserAccount"
            }
            It "should return " {
                $localuserTaskResult.status | Should -Be "Completed"
            }
        }
        Context "Test Case 247718: ST_TC_DM SFTP_#243262_To verify List of Local Users for Product and Product components" {
            BeforeAll {

                $requestParams = @{
                    Method = 'GET'
                    Uri    = "/workspace/api/v1/product/$($LocalUserproductId)/component/$($LocalUserproductComponentId)/storageaccount/sftplocaluser"
                }

                $ListUserResponse = @{}
                $ListUserResponse = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true
                $listofname = $ListUserResponse.name

                $countofusers = $ListUserResponse.count
                Write-Host "Number of Local User available for dmz product is ..... $($countofusers)"

            }
            It "Should get List of Local User Created for DMZ container" {
                $countofusers | Should -eq 2
            }
        }
        Context "Test Case 247721: ST_TC_DM SFTP_#243262_To verify Manual Rotation of Password via mail" {
            BeforeAll {

                Write-Host "Manual Rotate Sftp LocalUser AccountCredentials "

                $requestParams = @{
                    Method = 'POST'
                    Uri    = "/workspace/api/v1/product/$($LocalUserproductId)/component/$($LocalUserproductComponentId)/storageaccount/sftplocaluser/$($localuserresponsename)"
                    Body   = @{} | ConvertTo-Json
                }

                $response = @{}
                $response = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true
                $rotationtaskid = $response.taskid
                Write-Host "Local User Creation Task ID is ---- $rotationtaskid"

                $localuserTaskResult = @{}
                $localuserTaskResult = Get-BackgroundStatus $CurrentEnvironmentData $rotationtaskid "workspace"

                FailEarly 'Validate product creation' {
                    $localuserTaskResult.status | Should -Be "Completed"
                }

            }
            It "Should have actity Type as ManualRotateSftpLocalUserAccountCredentials " {
                $localuserTaskResult.taskOutput.activityType | Should -Be "ManualRotateSftpLocalUserAccountCredentials"
            }
            It "should return Status as complete " {
                $localuserTaskResult.status | Should -Be "Completed"
            }
        }
        Context "Test Case 248014: ST_TC_DM SFTP_#243262_Negative Scenario - To verify Duplicate Local user creation for SFTP Login" {
            BeforeAll {

                Write-Host "Creating Multiple SFTP Local user Account with same name"
                Write-Host "User name $localusername using to test 409 Status code"
                $requestParams = @{
                    Method = 'POST'
                    Uri    = "/workspace/api/v1/product/$($LocalUserproductId)/component/$($LocalUserproductComponentId)/storageaccount/sftplocaluser"
                    Body   = @{
                        "userName" = $localusername.ToLower()

                    } | ConvertTo-Json
                }

                $response = @{}
                $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true


            }
            It "Should throw message for invalid Engagement code" {
                $response.ErrorDetails.message | Should -be "There is already a local user account with this name"
            }
            #commenting assertion until defect fix to change 400 to 409
            It "should have Status code 409" {
                $response.ExceptionResponse.StatusCode.value__ | Should -be 409
            }
        }
        Context "Test Case 247719: ST_TC_DM SFTP_#243262_Negative Scenario-To verify List of Local Users for Product and  different Product components" {

            It "Should throw Error message for nonexisting Product ID" {
                Write-Host "Fetch list of Local user created where Product ID is Invalid"
                #assuming 999999999 Max Value as a invalid or Non Existing Product id
                $requestParams = @{
                    Method = 'GET'
                    Uri    = "/workspace/api/v1/product/999999999/component/$($LocalUserproductComponentId)/storageaccount/sftplocaluser"
                }

                $response = @{}
                $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true
                Write-Host "Error is >>>>>>>>>>>>  $($response.ErrorDetails.message)"
                #$response.ErrorDetails.message | Should -Contain "Product with specified ID not found: 999999999"

                $response.ExceptionResponse.StatusCode.value__ | Should -be 404

            }
            It "Should throw Error message for Nonexisting Product Component ID" {
                Write-Host "Fetch list of Local user created where ProductComponent ID is Invalid"
                #assuming 999999999 Max Value as a invalid or Non Existing Product Component id
                $requestParams = @{
                    Method = 'GET'
                    Uri    = "/workspace/api/v1/product/$($LocalUserproductId)/component/999999999/storageaccount/sftplocaluser"
                }

                $response = @{}
                $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true
                Write-Host "Error is >>>>>>>>>>>>  $($response)"
                #$response.ErrorDetails.Message | Should -Contain "Product Component with specified ID not found: 999999999"
                $response.ExceptionResponse.StatusCode.value__ | Should -be 404

            }
        }
        Context "Test Case 247720: ST_TC_DM SFTP_#243262_Negative Scenario - To Verify Local user creation for other Components except Public Component" {
            BeforeAll {

                Write-Host "Creating Local User for Empty Resource group"
                $script:LocalUserproductId = $productId
                $Script:Emptyresource_productComponentId = $emptyproductcomponent1

                $script:localusername = "testLocalUser$($CurrentEnvironmentData.Environment)"
                Write-Host "This is the user name $localusername"
                $requestParams = @{
                    Method = 'POST'
                    Uri    = "/workspace/api/v1/product/$($LocalUserproductId)/component/$($Emptyresource_productComponentId)/storageaccount/sftplocaluser"
                    Body   = @{
                        "userName" = $localusername.ToLower()

                    } | ConvertTo-Json
                }

                $response = @{}
                $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true

            }
            It "should return activity Type for local user creation" {
                $($response.ErrorDetails.message) | Should -Be "Could not automatically determine storage account for this component, please specified the storage account name"
            }
        }
        Context "Test Case 248470: ST_TC_DM SFTP_#243262_Negative Scenario To verify deletion of Local user where Parameter values are Invalid" {

            It "Delete localuser Endopoint Should throw Error message for nonexisting Product ID" {
                Write-Host "Fetch list of Local user created where Product ID is Invalid"
                #assuming 999999999 Max Value as a invalid or Non Existing Product id
                $requestParams = @{
                    Method = 'DELETE'
                    Uri    = "/workspace/api/v1/product/999999999/component/$($LocalUserproductComponentId)/storageaccount/sftplocaluser/$localuserresponsename"
                }
                $response = @{}
                $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true
                Write-Host "Error is >>>>>>>>>>>>  $($response.ErrorDetails.message)"
                $response.ErrorDetails.message | Should -Contain "Product with specified ID not found: 999999999"

                $response.ExceptionResponse.StatusCode.value__ | Should -be 404

            }
            It "Delete localuser Endopoint Should throw Error message for invalid Product Component ID" {
                Write-Host "Fetch list of Local user created where ProductComponent ID is Invalid"
                #assuming 999999999 Max Value as a invalid or Non Existing Product Component id
                $requestParams = @{
                    Method = 'DELETE'
                    Uri    = "/workspace/api/v1/product/$($LocalUserproductId)/component/999999999/storageaccount/sftplocaluser/$localuserresponsename"
                }

                $response = @{}
                $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true
                Write-Host "Error is >>>>>>>>>>>>  $($response.ErrorDetails.message)"
                $response.ErrorDetails.message | Should -Contain "Product Component with specified ID not found: 999999999"

                $response.ExceptionResponse.StatusCode.value__ | Should -be 404

            }
            It "Delete localuser Endopoint Should throw Error message for invalid Local User name " {
                Write-Host "Delete Local User with Invalid formate of LocalUsername"
                #assuming 999999999 Max Value as a invalid or Non Existing Product Component id
                $invalidname = "Invalidlocalusername"
                $requestParams = @{
                    Method = 'DELETE'
                    Uri    = "/workspace/api/v1/product/$($LocalUserproductId)/component/$($LocalUserproductComponentId)/storageaccount/sftplocaluser/$($invalidname)"
                }

                $response = @{}
                $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true
                Write-Host "Error is >>>>>>>>>>>>  $($response.ErrorDetails.message)"
                $response.ErrorDetails.message | Should -Contain "Could not find an SFTP local account for username '$($invalidname)'"
                $response.ExceptionResponse.StatusCode.value__ | Should -be 404

            }
        }
        Context "Test Case 247722: ST_TC_DM SFTP_#243262_To verify deletion of Local user from the product " {
            BeforeAll {
                Write-Host "List of local user Available for deletion"
                #Delete all related Local Users for the Product before Deleting the product and component
                $requestParams = @{
                    Method = 'GET'
                    Uri    = "/workspace/api/v1/product/$($LocalUserproductId)/component/$($LocalUserproductComponentId)/storageaccount/sftplocaluser"
                }

                $ListUserResponse = @{}
                $ListUserResponse = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true
                $countofusers = $ListUserResponse.count
                $script:nameofusers = $ListUserResponse.name
                Write-Host "Number of Local User available for dmz product is ..... $($countofusers)"
            }
            It "Delete Active Users for $($LocalUserproductId ) and $($LocalUserproductComponentId) " {
                foreach ($item in $nameofusers) {
                    Write-Host "Local User to be Deleted - $item "

                    $requestParams = @{
                        Method = 'DELETE'
                        Uri    = "/workspace/api/v1/product/$($LocalUserproductId)/component/$($LocalUserproductComponentId)/storageaccount/sftplocaluser/$item"
                    }

                    $response = @{}
                    $response = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true
                    $deleteusertaskid = $response.taskid

                    $deleteTaskResult = @{}
                    $deleteTaskResult = Get-BackgroundStatus $CurrentEnvironmentData $deleteusertaskid "workspace"

                    $deleteTaskResult.status | Should -Be "Completed"
                }
            }
            It "ST_TC_DM SFTP_#243262_Negative Scenario - To verify deletion of already deleted Local user for $($LocalUserproductId ) and $($LocalUserproductComponentId) should throw Error 404 " {
                foreach ($item in $nameofusers) {
                    Write-Host "Local User to be redeleted - $item "

                    $requestParams = @{
                        Method = 'DELETE'
                        Uri    = "/workspace/api/v1/product/$($LocalUserproductId)/component/$($LocalUserproductComponentId)/storageaccount/sftplocaluser/$item"
                    }

                    $response = @{}
                    $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true

                    $response.ExceptionResponse.StatusCode.value__ | Should -be 404

                }
            }

        }

    }

    #All testcases related to Activty Logs
    Context "Activity Logs wrt Type - Feature 93975: Activity Log Subscription Enhancements " {
        BeforeAll {
            Write-Host "Fetching activity Logs for diffrent Activity Types"
            $service = "workspace"
            $ActivitytypeList = @('CreateProduct', 'CreateProductComponent', 'AddGroupOwner', 'ProductDataTransfer' , 'CreateSftpLocalUserAccount' , 'ManualRotateSftpLocalUserAccountCredentials')
            $response = @{}
            $response = ActivityLogs $service $ActivitytypeList

            $logsArrayType = $response.entries.logs.GetType().Name
            Write-host " DataType of 'Logs' in Response is-- $logsArrayType "
            Write-Host "Create a list activity Type from Response"
            $responseActivityType = @()
            foreach ($item in $($response.entries)) {
                $responseActivityType += $item.type
            }
            Write-Host "Respons list ---- $responseActivityType "
        }
        It "should return atleast one response" {
            $response | Should -Not -BeNullOrEmpty
        }
        It "Should have all ActivityTypes present in the response" {
            foreach ($Item in $responseActivityType) {
                $Item | Should -BeIn $ActivitytypeList
            }
        }
        It "should return Logs Type as Array" {
            $($logsArrayType) | should -Be  "Object[]"
        }
    }

    Context "User Story 306260: Add search text parameter in Product search endpoint - Like Search" {
        It "Test Case 319943: ST_TC_DM_306260: (Positive TC) Verify Filters in GET Product where Search is on 'Product Name' " {
            Write-Host "Get Product Details When Search with ProductName"
            $partailproductname = "TestProduct$($CurrentEnvironmentData.Environment)"
            $requestParams = @{
                Method = 'GET'
                Uri    = "/workspace/api/v1/product?search=$partailproductname"
            }
            $getresponse = @{}
            $getresponse = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true
            $getresponse | Should -Not -BeNullOrEmpty
        }
        It "Test Case 319944: ST_TC_DM_306260: (Positive TC) Verify Filters in GET Product where Search is on 'Email Address' " {
            Write-Host "Get Product Details When Search with Email Address "

            $requestParams = @{
                Method = 'GET'
                Uri    = "/workspace/api/v1/product?search=sunidhinema@kpmg.com"
            }
            $getresponse = @{}
            $getresponse = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true
            $getresponse | Should -Not -BeNullOrEmpty
        }
        It "Test Case 319944: ST_TC_DM_306260: (Positive TC) Verify Filters in GET Product where Search is on Guest Email Address' " {
            Write-Host "Get Product Details When Search with Guest Email Address has # in its email Address"

            $requestParams = @{
                Method = 'GET'
                Uri    = "/workspace/api/v1/product?search=#EXT#"
            }
            $getresponse = @{}
            $getresponse = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true
            $getresponse | Should -Not -BeNullOrEmpty
        }
        It "Test Case 319945: ST_TC_DM_306260: (Positive TC) Verify Filters in GET Product where Search is on 'Engagement Code' " {
            Write-Host "Get Product Details When Search with Guest Email Address has # in its email Address"

            $requestParams = @{
                Method = 'GET'
                Uri    = "/workspace/api/v1/product?search=$enagagmentcode"
            }
            $getresponse = @{}
            $getresponse = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true
            $getresponse | Should -Not -BeNullOrEmpty
        }
    }

    AfterAll {
        Write-Host "Test Case 217839: TC_DM_WS_Product Deletion"
        Write-Host "response Array count --- $($totalcomponent)"
        if ($($totalcomponent) -ge 0) {
            Write-Host "Deleting product Components associated with Product $($productId)..."
            foreach ($item in $componentarray) {
                # Delete 1st Product Component
                $requestParams = @{
                    Method = 'DELETE'
                    Uri    = "/workspace/api/v1/product/$($productId)/component/$($item)"
                }

                $deleteResponse = @{}
                $deleteResponse = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true

                $deleteTaskResult = @{}
                $deleteTaskResult = Get-BackgroundStatus $CurrentEnvironmentData $($deleteResponse.taskId) "workspace"
                Write-Host "Product component deleted $($item)..."
            }
        }
        if ($productId) {
            Write-Host "Deleting product $($productId)..."

            # Delete Product

            $requestParams = @{
                Method = 'DELETE'
                Uri    = "/workspace/api/v1/product/$($productId)"
            }

            $deleteProduct = @{}
            $deleteProduct = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true
            Write-Host "Task Id for deletion is -- $($deleteProduct.taskId)"
            $deleteTaskResult = @{}
            $deleteTaskResult = Get-BackgroundStatus $CurrentEnvironmentData $($deleteProduct.taskId) "workspace"
            Write-Host "Product has been deleted $($item)..."
        }
    }
}

Describe "Workspace API - Testcases related to Product Post deletion of Product ID" -Tag "long-running" {

    Context "Test Case 219388: TC_DM_WS_Update Product Negative  - Updating Active status for deleted product" {

        It "should throw an Error 400 - Deleted Product cannot be reactivate" {
            Write-Host "Trying to Update Deleted Product = $productId  to Active State again"

            Write-Host "State to update is  ---- Active "
            $requestParams = @{
                Method = 'PUT'
                Uri    = "/workspace/api/v1/product/$($productId)"
                Body   = @{
                    "status" = "Active"

                } | ConvertTo-Json
            }

            $response = @{}
            $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true
            Write-Host "Response after Updating result as Active ProductId is --  $response"

            $response.ExceptionResponse.StatusCode.value__ | Should -be 400
            $response.ErrorDetails.message | Should -be "Cannot set to non-deleted state because AD group does not exist"
        }
        It "should return Status = 'Deleted' for Product" {
            Write-Host "Get Product status details should not be Active"

            $requestParams = @{
                Method = 'GET'
                Uri    = "/workspace/api/v1/product/$($productId)"
            }
            $getresponse = @{}
            $getresponse = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true
            $getresponse.status | Should -be "Deleted"
        }
    }
    Context "Test Case 219388: TC_DM_WS_Update Product Negative  - Deleted Product getting 'Active' from PUT Method" {

        It "should throw an Error 400    - Deleted Product cannot be reactivate" {
            Write-Host "Trying to Update Deleted Product = $productId  to Active State again"

            $requestParams = @{
                Method = 'DELETE'
                Uri    = "/workspace/api/v1/product/$($productId)"
            }

            $response = @{}
            $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true
            Write-Host "Response after re deleting ProductId is --  $response"
            $response.ExceptionResponse.StatusCode.value__ | Should -be 400
        }
        It "should return Status = 'Deleted' for Product" {
            Write-Host "Get Product status details should not be Active"

            $requestParams = @{
                Method = 'GET'
                Uri    = "/workspace/api/v1/product/$($productId)"
            }
            $getresponse = @{}
            $getresponse = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true
            $getresponse.status | Should -be "Deleted"
        }
    }
}


