param(
    [Parameter(Mandatory)]
    [ValidateNotNullOrEmpty()]
    $CurrentEnvironmentData
)
Describe "Testcases Related to ActivityLogs" {
    <#Context "User Story 280185: Activity Log Endpoint that aggregates by Task ID" {
        BeforeAll {
            $MandateKeys = @('taskId', 'type', 'startDate', 'duration', 'createdBy', 'logs')
            $service = "Workspace"
            Write-Host ""
            # Create a new Role

            Write-Host "Assuming that atleast one Activity has been preformed within 24 hours... Checking Logs with pagesize = 1 "

            $requestParams = @{
                Method = 'POST'
                Uri    = "/$service/api/v1/activitylog/tasks"
                Body   = @{
                    "pageSize" = "1"

                } | ConvertTo-Json
            }
            $LogResponse = @{}
            $LogResponse = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true

            $logsArrayType = $LogResponse.entries.logs.GetType().Name
            Write-host " DataType of 'Logs' in Response is-- $logsArrayType "
        }
        It "should return atleast one response" {
            $LogResponse | Should -Not -BeNullOrEmpty
        }
        It "should return Logs Type as Array" {
            $($logsArrayType) | should -Be  "Object[]"
        }
        It "Should have all the required keys in the response" {
            foreach ($item in $LogResponse) {
                $item | Should -Contain $key
            }
        }
    } #>

    Context "Activity Logs wrt Type - Feature 93975: Activity Log Subscription Enhancements " {
        BeforeAll {
            Write-Host "Fetching activity Logs for diffrent Activity Types"
            $service = "workspace"
            $ActivitytypeList = @('CreateProduct', 'CreateProductComponent', 'AddGroupOwner', 'ProductDataTransfer' , 'CreateSftpLocalUserAccount' , 'ManualRotateSftpLocalUserAccountCredentials')
            $response = @{}
            $response = ActivityLogs $service $ActivitytypeList

            Write-Host "Create a list activity Type in Response"
            $responseActivityType = @()
            foreach ($item in $($response.entries)) {
                $responseActivityType += $item.type
            }
            Write-Host "Respons list ---- $responseActivityType "
        }
        It "should return atleast one response" {
            $response | Should -Not -BeNullOrEmpty
        }
        It "Should have all ActivityTypes present in the response" {
            foreach ($Item in $responseActivityType) {
                $Item | Should -BeIn $ActivitytypeList
            }
        }
    }
    Context "Activity Logs wrt Type - Feature 93975: Activity Log Subscription Enhancements " {
        BeforeAll {
            Write-Host "Fetching activity Logs for diffrent Activity Types"
            $service = "workspace"
            $ActivitytypeList = @('CreateProduct', 'CreateProductComponent', 'AddGroupOwner', 'ProductDataTransfer' , 'CreateSftpLocalUserAccount' , 'ManualRotateSftpLocalUserAccountCredentials')
            $response = @{}
            $response = ActivityLogs $service $ActivitytypeList

            $logsArrayType = ($response).entries.logs.GetType().Name
            Write-host " DataType of 'Logs' in Response is-- $logsArrayType "
            Write-Host "Create a list activity Type from Response"
            $responseActivityType = @()
            foreach ($item in $($response.entries)) {
                $responseActivityType += $item.type
            }
            Write-Host "Respons list ---- $responseActivityType "
        }
        It "should return atleast one response" {
            $response | Should -Not -BeNullOrEmpty
        }
        It "Should have all ActivityTypes present in the response" {
            foreach ($Item in $responseActivityType) {
                $Item | Should -BeIn $ActivitytypeList
            }
        }
        It "should return Logs Type as Array" {
            $($logsArrayType) | should -Be  "Object[]"
        }
    }

}
