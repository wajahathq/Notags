param(

    [Parameter(Mandatory)]
    [ValidateNotNullOrEmpty()]
    $CurrentEnvironmentData

)
$Script:blueprintList = @()
$Script:ContactMailContextId = (New-Guid).Guid
$Script:NewmailId = "NewMail$($ContactMailContextId)"
Describe "Workspace API - Product Component Blueprint" {

    BeforeAll {
        $requestParams = @{
            Method = 'GET'
            Uri    = "/workspace/api/v1/productcomponentblueprint"
        }
        $Script:ListOfBlueprintResponse = @{}
        $Script:ListOfBlueprintResponse = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true

        for ($i = 0; $i -lt $ListOfBlueprintResponse.length; $i++) {
            if ($($ListOfBlueprintResponse[$i].status) -eq "Active") {
                $blueprintList += $($ListOfBlueprintResponse[$i].key)
            }
        }
        FailEarly 'Validate the list of response of the blueprints' {
            $ListOfBlueprintResponse.count | Should -Not -BeNullOrEmpty
        }

        Write-Host "List values are = $($blueprintList)"

    }

    It "Should return response body having some values" {
        $ListOfBlueprintResponse | Should -not -BeNullOrEmpty
    }


    Context "Updating and fetching the bluerpints" {
 
        It "Should return response body having correct blueprint values" {
            foreach ($item in $blueprintList) {
                $testEmail = "$($NewmailId)@test.com"

                #Fetching the original value of ContactEmail for blueprint
                $requestParams = @{
                    Method = 'GET'
                    Uri    = "/workspace/api/v1/productcomponentblueprint/$($item)"
                }

                $blueprintResponse = @{}
                $blueprintResponse = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true

                $OriginalContactEmail = $($blueprintResponse.contactEmail)

                # Ensure contactEmail is always an array
                if (-not ($OriginalContactEmail -is [System.Array])) {
                    $OriginalContactEmail = @($OriginalContactEmail)
                }
                
                # Now safely add the new email
                $UpdatedContactEmailList = $OriginalContactEmail + $testEmail
                Write-Host "ORIGINAL CONTACT EMAIL --- $($OriginalContactEmail)"

                #Updating the contact email for the blueprints
                $requestParams = @{
                    Method = 'PUT'
                    Uri    = "/workspace/api/v1/productcomponentblueprint/$($item)"
                    Body   = @{
                        "contactEmail" = $UpdatedContactEmailList
                    } | ConvertTo-Json
                }

                $UpdateEmailResponse = @{}
                $UpdateEmailResponse = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true

                $UpdatedContactMail = $($UpdateEmailResponse.contactEmail)
                Write-Host "UPDATED CONTACT EMAIL ---- $($UpdatedContactMail)"

                #Getting the reponse with updated contact mail
                $requestParams = @{
                    Method = 'GET'
                    Uri    = "/workspace/api/v1/productcomponentblueprint/$($item)"
                }
                $BlueprintByKeyResponse = @{}
                $BlueprintByKeyResponse = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true

                FailEarly 'Validate updated contact email' {
                    $BlueprintByKeyResponse.contactEmail | Should -Contain $testEmail
                }
            
                $OriginalContactEmailToReset = $BlueprintByKeyResponse.contactEmail | Where-Object { $_ -ne $testEmail }
                if (-not ($OriginalContactEmailToReset -is [System.Array])) {
                    $OriginalContactEmailToReset = @($OriginalContactEmailToReset)
                }

                Write-Host "Original Contact Email To Reset $($OriginalContactEmailToReset)"

                #Resetting the contact email value to default value
                $requestParams = @{
                    Method = 'PUT'
                    Uri    = "/workspace/api/v1/productcomponentblueprint/$($item)"
                    Body   = @{
                        "contactEmail" = $OriginalContactEmailToReset
                    } | ConvertTo-Json
                }

                $DefaultMailResponse = @{}
                $DefaultMailResponse = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true

                $defaultContactMail = $DefaultMailResponse.contactEmail
                Write-Host "ORIGINAL CONTACT EMAIL AFTER RESET IS ------ $($defaultContactMail -join ', ')"

                FailEarly 'Validate the contact email after reset' {
                    $DefaultMailResponse.contactEmail | Should -Be $OriginalContactEmailToReset
                }
                
                #Fetching ProductComponentBlueprint by blueprint Key
                $requestParams = @{
                    Method = 'GET'
                    Uri    = "/workspace/api/v1/productcomponentblueprint/$($item)"
                }
            
                $FetchBlueprintResponse = @{}
                $FetchBlueprintResponse = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true

                FailEarly 'Validate responce body containing expected blueprint key' {
                    $FetchBlueprintResponse.key | Should -eq $($item)
                }
                
                #Fetching parameter of ProductComponentBlueprint by blueprint Key
                $requestParams = @{
                    Method = 'GET'
                    Uri    = "/workspace/api/v1/productcomponentblueprint/$($item)/parameters"
                }
            
                $BlueprintParameterResponse = @{}
                $BlueprintParameterResponse = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true

                FailEarly 'Should return 200 status code' {
                    $BlueprintParameterResponse.count | should -BeGreaterOrEqual 0
                }
                
                #Creation of existing Product Component blueprint (Negative TC)
                $requestParams = @{
                    Method = 'POST'
                    Uri    = "/workspace/api/v1/productcomponentblueprint"
                    Body   = @{
                        "blueprintKey"      = $($item)
                        "documentationUrl"  = "https://deliverybackbone.kpmg.com/collaboration/pages/viewpage.action?pageId=883369150"
                        "currentCommitHash" = "a0e26140a5c4068dd5a699812fe3dc468f51db11"
                        "currentBranchName" = "Master"
                        "buildPipelineId"   = "1860"
                        "contactEmail"      = $OriginalContactEmailToReset
                    } | ConvertTo-Json
                }
                $response = @{}
                $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true

                FailEarly 'Should return 409 conflict error' {
                    $response.ErrorDetails.message | should -be "Blueprint with specified Key already exists: $($item)"
                }

            }
         
        }

    }

    Context "Updating the Product Component blueprint with invalid blueprint Key(Negative TC)" {
        BeforeAll {
            $requestParams = @{
                Method = 'PUT'
                Uri    = "/workspace/api/v1/productcomponentblueprint/dmz-storage-container_10"
                Body   = @{
                    "documentationUrl" = "Modified Blueprint for dsc"
                } | ConvertTo-Json
            }
            $response = @{}
            $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true
        }
        It "Should return 404 not fount for invalid blueprintKey to update blueprint" {
            $response.ExceptionResponse.StatusCode.value__ | Should -be 404
        }
        It "Should return user friendly message for invalid blueprintKey to update blueprint" {
            $response.ErrorDetails.message | should -be "Blueprint with specified Key was not found: dmz-storage-container_10"
        }

    }

    Context "Updating the Product Component blueprint with invalid status(Negative TC)" {
        BeforeAll {
            $requestParams = @{
                Method = 'PUT'
                Uri    = "/workspace/api/v1/productcomponentblueprint/dmz-storage-container"
                Body   = @{
                    "status" = "Unknown"
                } | ConvertTo-Json
            }
            $response = @{}
            $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true
        }
        It "Should return 400 bad request for invalid status" {
            $response.ExceptionResponse.StatusCode.value__ | Should -be 400
        }
        It "Should return user friendly message for invalid status" {
            $response.ErrorDetails.message | should -be "Invalid Status Value"
        }

    }

    Context "Fetching Product Component blueprint details by invalid blueprint Key(Negative TC)" {
        BeforeAll {
            $requestParams = @{
                Method = 'GET'
                Uri    = "/workspace/api/v1/productcomponentblueprint/dmz-storage-container_01"
            }
            $response = @{}
            $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true
        }
        It "Should return 404 not found for invalid blueprintKey" {
            $response.ExceptionResponse.StatusCode.value__ | Should -be 404
        }
        It "Should return user friendly message for invalid blueprintKey" {
            $response.ErrorDetails.message | should -be "Blueprint with specified Key not found: dmz-storage-container_01"
        }

    }

    Context "Fetching Product Component blueprint details by numbers(Negative TC)" {
        BeforeAll {
            $requestParams = @{
                Method = 'GET'
                Uri    = "/workspace/api/v1/productcomponentblueprint/637238-363468347"
            }
            $response = @{}
            $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true
        }
        It "Should return 404 not found for numbers" {
            $response.ExceptionResponse.StatusCode.value__ | Should -be 404
        }
        It "Should return user friendly message for numbers" {
            $response.ErrorDetails.message | should -be "Blueprint with specified Key not found: 637238-363468347"
        }

    }

    Context "Fetching Product Component blueprint details by character(Negative TC)" {
        BeforeAll {
            $requestParams = @{
                Method = 'GET'
                Uri    = "/workspace/api/v1/productcomponentblueprint/abvc-hjdf-yriioero"
            }
            $response = @{}
            $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true
        }
        It "Should return 404 not found for characters" {
            $response.ExceptionResponse.StatusCode.value__ | Should -be 404
        }
        It "Should return user friendly message for characters" {
            $response.ErrorDetails.message | should -be "Blueprint with specified Key not found: abvc-hjdf-yriioero"
        }

    }

    Context "Fetching Product Component blueprint details by special character(Negative TC)" {
        BeforeAll {
            $requestParams = @{
                Method = 'GET'
                Uri    = "/workspace/api/v1/productcomponentblueprint/%25%2A%28%29%26%2A%25%5E%25%23"
            }
            $response = @{}
            $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true
        }
        It "Should return 404 not found for special characters" {
            $response.ExceptionResponse.StatusCode.value__ | Should -be 404
        }
        It "Should return user friendly message for special characters" {
            $response.ErrorDetails.message | should -be "Blueprint with specified Key not found: %*()&*%^%#"
        }

    }

    Context "Fetching parameters for Product Component blueprint with invalid blueprint Key(Negative TC)" {
        BeforeAll {
            $requestParams = @{
                Method = 'GET'
                Uri    = "/workspace/api/v1/productcomponentblueprint/empty-resource-group_1/parameters"
            }
            $response = @{}
            $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true
        }
        It "Should return 404 not found for parameter with invalid blueprintKey" {
            $response.ExceptionResponse.StatusCode.value__ | Should -be 404
        }
        It "Should return user friendly message for parameter with invalid blueprintKey" {
            $response.ErrorDetails.message | should -be "Blueprint with specified Key not found: empty-resource-group_1"
        }

    }

    Context "Fetching parameters for Product Component blueprint with numbers(Negative TC)" {
        BeforeAll {
            $requestParams = @{
                Method = 'GET'
                Uri    = "/workspace/api/v1/productcomponentblueprint/12345678/parameters"
            }
            $response = @{}
            $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true
        }
        It "Should return 404 not found for parameters with numbers" {
            $response.ExceptionResponse.StatusCode.value__ | Should -be 404
        }
        It "Should return user friendly message for parameters with numbers" {
            $response.ErrorDetails.message | should -be "Blueprint with specified Key not found: 12345678"
        }

    }

    Context "Fetching parameters for Product Component blueprint with characters(Negative TC)" {
        BeforeAll {
            $requestParams = @{
                Method = 'GET'
                Uri    = "/workspace/api/v1/productcomponentblueprint/gdhgsdjieu/parameters"
            }
            $response = @{}
            $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true
        }
        It "Should return 404 not found for parameters with characters" {
            $response.ExceptionResponse.StatusCode.value__ | Should -be 404
        }
        It "Should return user friendly message for parameters with characters" {
            $response.ErrorDetails.message | should -be "Blueprint with specified Key not found: gdhgsdjieu"
        }

    }

    Context "Fetching parameters for Product Component blueprint with special characters(Negative TC)" {
        BeforeAll {
            $requestParams = @{
                Method = 'GET'
                Uri    = "/workspace/api/v1/productcomponentblueprint/%25%5E%26%2A%28%24%23/parameters"
            }
            $response = @{}
            $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true
        }
        It "Should return 404 not found for parameters with special characters" {
            $response.ExceptionResponse.StatusCode.value__ | Should -be 404
        }
        It "Should return user friendly message for parameters with special characters" {
            $response.ErrorDetails.message | should -be "Blueprint with specified Key not found: %^&*($#"
        }

    } 
    
    Context "User Story 306260: Add search text parameter in Product search endpoint - Like Search" {
        It "Test Case 319943: ST_TC_DM_306260: (Positive TC) Verify Filters in GET Product where Search is on 'Product Name' " {
            Write-Host "Get Product Details When Search with ProductName"
            $partailproductname = "TestProduct$($CurrentEnvironmentData.Environment)"
            $requestParams = @{
                Method = 'GET'
                Uri    = "/workspace/api/v1/product?search=$partailproductname"
            }
            $getresponse = @{}
            $getresponse = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true
            $getresponse | Should -Not -BeNullOrEmpty
        }
        It "Test Case 319944: ST_TC_DM_306260: (Positive TC) Verify Filters in GET Product where Search is on 'Email Address' " {
            Write-Host "Get Product Details When Search with Email Address "

            $requestParams = @{
                Method = 'GET'
                Uri    = "/workspace/api/v1/product?search=sunidhinema@kpmg.com"
            }
            $getresponse = @{}
            $getresponse = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true
            $getresponse | Should -Not -BeNullOrEmpty
        }
        It "Test Case 319944: ST_TC_DM_306260: (Positive TC) Verify Filters in GET Product where Search is on Guest Email Address' " {
            Write-Host "Get Product Details When Search with Guest Email Address has # in its email Address"

            $requestParams = @{
                Method = 'GET'
                Uri    = "/workspace/api/v1/product?search=#EXT#"
            }
            $getresponse = @{}
            $getresponse = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true
            $getresponse | Should -Not -BeNullOrEmpty
        }
        It "Test Case 319945: ST_TC_DM_306260: (Positive TC) Verify Filters in GET Product where Search is on 'Engagement Code' " {
            Write-Host "Get Product Details When Search with Guest Email Address has # in its email Address"

            $requestParams = @{
                Method = 'GET'
                Uri    = "/workspace/api/v1/product?search=$enagagmentcode"
            }
            $getresponse = @{}
            $getresponse = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true
            $getresponse | Should -Not -BeNullOrEmpty
        }
    }
}

    