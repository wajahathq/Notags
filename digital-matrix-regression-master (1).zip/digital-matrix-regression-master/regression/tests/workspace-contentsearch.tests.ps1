param(
    [Parameter(Mandatory)]
    [ValidateNotNullOrEmpty()]
    $CurrentEnvironmentData
)

$SkipEnvironmentList = @('QA', 'CAT', 'UAT', 'Production')
Describe "Content Search -Using Service Account"  -Skip:($SkipEnvironmentList.Contains($CurrentEnvironmentData.Environment)) {
   
    BeforeAll { 

        Write-Host "Started login with Service Account"

        Write-host "Added Validation to check number of ContentSource"
        $SAenvData = GetSAEnvironmentData $CurrentEnvironmentData
        Write-Host "Current Enviroment data is $SAenvData "
        $requestParams = @{
            Method = 'POST'
            Uri    = "/workspace/api/v1/contentsearch/sources"
            Body   = @{
                "queryText" = "*"
            } | ConvertTo-Json
        }

        Write-Host "POST method run"
        $contentsourceResponse = @{}
        $contentsourceResponse = Invoke-RestMethodAuthWrapper $SAenvData $requestParams $true

        Write-Host "Value in response is -- $contentsourceResponse"

        #fetching list and number of contentsources
        $contentsourceArray = @()
        $ContentSourceCount = 0
        foreach ($item in $contentsourceResponse) {
            Write-Host "Taking Sharepoint ContentSourcename as a variable"
            if ($item.contentSource.Contains("Sharepoint")) {
                $sharepointSources += $item.contentSource
            }
            $contentsourceArray += $item.contentSource
            $ContentSourceCount = $ContentSourceCount + 1
        
        }
        Write-Host "sharepoint ContentSource Name is -- $sharepointSources"
        
        Write-Host "There are $ContentSourceCount ContentSources Available for BAI i.e $contentsourceArray"
        
        FailEarly 'if count of ContentSources are less than 1' {
            $ContentSourceCount | Should -ge "1"
            Write-Host "User Do not have access to any BAI Content Source Please reachout to SPOC"
        }
    } 
    
    It "Test Case 266600: ST_TC_DM_259463_Get the Content Sources fetch All Enabled Content Sources--- Should return Response" {
        $contentsourceResponse | Should -not -BeNullOrEmpty
    }
    It "Test Case 266600: ST_TC_DM_259463_Get the Content Sources fetch All Enabled Content Sources  --- Number of ContentSource should be -ge  1" {
        $ContentSourceCount | Should -ge 1
    }
    Context "Test Case 284730: ST_TC_DM_277610: To verify in Content Search that the API returns correct refiner values for a refiner name Searched in Specific ContentSource " {

        BeforeAll { 

            Write-Host "To verify in Content Search that the API returns correct refiner values for a refiner name Searched in Specific ContentSource"

            $SAenvData = GetSAEnvironmentData $CurrentEnvironmentData
            Write-Host "Current Enviroment data is $SAenvData "
            
            $requestParams = @{
                Method = 'POST'
                Uri    = "/workspace/api/v1/contentsearch/refinements"
                Body   = @{
                    "refinerName"   = @("SITENAME")
                    "refinerFilter" = @("ContentSource:equals(`"$sharepointSources`")")
                } | ConvertTo-Json
            }

            Write-Host "RequestBody is ----  $($requestParams | ConvertTo-Json) "
            $RefinerResponse = @{}
            $RefinerResponse = Invoke-RestMethodAuthWrapper $SAenvData $requestParams $true

            Write-Host "Value in response is -- $RefinerResponse"

        } 
    
        It "Should return where Refinername is 'SITENAME'" {
            foreach ($refinement in $RefinerResponse) {
                # Test that the refinementName field exists and has a value
                $refinement.refinerName | Should -be "SITENAME"
            }
        }
        It "Should return refinementCount -ge 1 " {
            foreach ($refinement in $RefinerResponse) {
                # Test that the refinementName field exists and has a value
                $refinement.refinementCount | Should -ge 1
            }
        }
    }
    Context "Test Case 284731: ST_TC_DM_277610: To verify in Content Search that the API returns correct refiner values for a valid refiner name and single refinement filter" {

        BeforeAll { 

            Write-Host "To verify in Content Search that the API returns correct refiner values for a valid ContentSource and single Refiner in refinement filter"

            $SAenvData = GetSAEnvironmentData $CurrentEnvironmentData
            Write-Host "Current Enviroment data is $SAenvData "
            
            $requestParams = @{
                Method = 'POST'
                Uri    = "/workspace/api/v1/contentsearch/refinements"
                Body   = @{
                    "refinerName"   = @("ContentSource")
                    "refinerFilter" = @("SITENAME:equals(`"BAI Proof of Concept`")")
                } | ConvertTo-Json
            }

            Write-Host "RequestBody is ----  $($requestParams | ConvertTo-Json) "
            $RefinerResponse = @{}
            $RefinerResponse = Invoke-RestMethodAuthWrapper $SAenvData $requestParams $true

            Write-Host "Value in response is -- $RefinerResponse"

        } 
    
        It "Should return where Refinername is 'ContentSource'" {
            foreach ($refinement in $RefinerResponse) {
                # Test that the refinementName field exists and has a value
                $refinement.refinerName | Should -be "ContentSource"
            }
            
        }
        It "Should return refinementCount -ge 1 " {
            foreach ($refinement in $RefinerResponse) {
                # user should have access to atleast one refiners
                $refinement.refinementCount | Should -ge 1
            }
        }
        
    }
    Context "Test Case 284732: ST_TC_DM_277610: To verify in Content Search that the API returns correct refiner values for a valid refiner name and multiple refinement filters. " {

        BeforeAll { 

            Write-Host "To verify in Content Search that the API returns correct refiner values for a refiner name Searched in Specific ContentSource"

            $SAenvData = GetSAEnvironmentData $CurrentEnvironmentData
            Write-Host "Current Enviroment data is $SAenvData "
        
            $requestParams = @{
                Method = 'POST'
                Uri    = "/workspace/api/v1/contentsearch/refinements"
                Body   = @{
                    "refinerName"       = @("SITENAME")
                    "refinementFilters" = @(
                        "ContentSource:equals(`"$sharepointSources`")",
                        "SITENAME:or(equals(`"BAI Proof of Concept`"),equals(`"BAI Proof of Concept2`"))"
                    )
                } | ConvertTo-Json
            }

            Write-Host "RequestBody is ----  $($requestParams | ConvertTo-Json) "
            $RefinerResponse = @{}
            $RefinerResponse = Invoke-RestMethodAuthWrapper $SAenvData $requestParams $true

            Write-Host "Value in response is -- $RefinerResponse"

        } 

        It "Should return where Refinername is 'SITENAME'" {
            foreach ($refinement in $RefinerResponse) {
                # Test that the refinementName field exists and has a value
                $refinement.refinerName | Should -be "SITENAME"
            }
   

        }
        It "Should return refinementCount -ge 1 " {
            foreach ($refinement in $RefinerResponse) {
                # user should have access to atleast one refiners
                $refinement.refinementCount | Should -ge 1
            }
        }
    }
    Context "Test Case 284733: ST_TC_DM_277610: To verify in Content Search that API returns correct refiner values when only Multiple valid refiner names and No refinement filters selected. " {

        BeforeAll { 

            Write-Host "To verify in Content Search that API returns correct refiner values when only Multiple valid refiner names and No refinement filters selected. "

            $SAenvData = GetSAEnvironmentData $CurrentEnvironmentData
            Write-Host "Current Enviroment data is $SAenvData "
            
            $requestParams = @{
                Method = 'POST'
                Uri    = "/workspace/api/v1/contentsearch/refinements"
                Body   = @{
                    "refinerName"   = @("ContentSource", "SITENAME", "SITEURL")
                    "refinerFilter" = @() #no Filter on refiner
                } | ConvertTo-Json
            }

            Write-Host "RequestBody is ----  $($requestParams | ConvertTo-Json) "
            $RefinerResponse = @{}
            $RefinerResponse = Invoke-RestMethodAuthWrapper $SAenvData $requestParams $true

            Write-Host "Value in response is -- $RefinerResponse"

        } 
    
        It "Should return refinementCount -ge 1 " {
            foreach ($refinement in $RefinerResponse) {
                # Test that the refinementName field exists and has a value
                $refinement.refinementCount | Should -ge 1
            }
        }
    }
    Context "Test Case 284734: ST_TC_DM_277610: To verify in Content Search that the API returns an empty array for an Empty Payload" {

        BeforeAll { 

            Write-Host "To verify in Content Search that API returns correct refiner values when only Multiple valid refiner names and No refinement filters selected. "

            $SAenvData = GetSAEnvironmentData $CurrentEnvironmentData
            Write-Host "Current Enviroment data is $SAenvData "
            
            $requestParams = @{
                Method = 'POST'
                Uri    = "/workspace/api/v1/contentsearch/refinements"
                Body   = @{
                    "refinerName"   = @() #no Filter on refinername
                    "refinerFilter" = @() #no Filter on refiner
                } | ConvertTo-Json
            }

            Write-Host "RequestBody is ----  $($requestParams | ConvertTo-Json) "
            $RefinerResponse = @{}
            $RefinerResponse = Invoke-RestMethodAuthWrapper $SAenvData $requestParams $true

            Write-Host "Value in response is -- $RefinerResponse"

        } 
    
        It "Should return empty Array " {
            # Test that the refinementName field exists and has a value
            $RefinerResponse | Should -BeNullOrEmpty
            
        }
    }
    Context "Test Case 266601: ST_TC_DM_259463_Get the Content search query result" {
    
        It "Should return Query results for specific refinementFilters should result ContentSource  =  My Sharepoint " {
            Write-Host "To verify in Content Search that the API returns correct Query result for ContentSource"

            $SAenvData = GetSAEnvironmentData $CurrentEnvironmentData
            Write-Host "Current Enviroment data is $SAenvData "
            
            $requestParams = @{
                Method = 'POST'
                Uri    = "/workspace/api/v1/contentsearch/query"
                Body   = @{
                    "queryText"         = "*"
                    "refinementFilters" = @("ContentSource:equals(`"$sharepointSources`")")
                    "excerptLength"     = 100
                    "pageSize"          = 10
                    "pageIndex"         = 5
                } | ConvertTo-Json
            }

            Write-Host "RequestBody is ----  $($requestParams | ConvertTo-Json) "
            $QueryResponse = $null
            $QueryResponse = Invoke-RestMethodAuthWrapper $SAenvData $requestParams $true

            #$resultresponse = ConvertFrom-Json $QueryResponse
            #Write-Host "Value after convert from json  $resultresponse and QueryResponse is - $QueryResponse "

            #Write-Host "Value in response is -- $($resultresponse.result.contentSource) and $($list.contentSource) "
           
            Write-Host "Value in contentSource   is $($QueryResponse.result.contentSource) "
            #$QueryResponse.result.contentSource | Should -Contain "My Sharepoint" 
            foreach ($item in $QueryResponse) {
                $contentsourceinResponse += $item.result.contentSource
                Write-Host "Value in contentsourceinResponse is $contentsourceinResponse" 
            }
            $contentsourceinResponse | Should -Contain $sharepointSources
        }
   
        It "Test Case 266603: ST_TC_DM_259463_Get the Content search query result (Negative TC) Should throw Error 400 for Query results Where exceed limit of excerptLength " {
            Write-Host "To verify in Content Search that the API throw error for exceeding Parameter limits "

            $SAenvData = GetSAEnvironmentData $CurrentEnvironmentData
            Write-Host "Current Enviroment data is $SAenvData "
            
            $requestParams = @{
                Method = 'POST'
                Uri    = "/workspace/api/v1/contentsearch/query"
                Body   = @{
                    "queryText"         = "*"
                    "refinementFilters" = @("ContentSource:equals(`"$sharepointSources`")")
                    "excerptLength"     = 2147483648  #exceeding limit of Int32
                    "pageSize"          = 10
                    "pageIndex"         = 1
                } | ConvertTo-Json
            }

            #Write-Host "RequestBody is ----  $($requestParams | ConvertTo-Json) "
            $response = @{}
            $response = Invoke-RestMethodAuthWrapperExceptionHandler $CurrentEnvironmentData $requestParams $true

            Write-Host "Value in response is -- $response"
            # Test that the refinementName field exists and has a value
        
            $response.ExceptionResponse.StatusCode.value__ | Should -be 400
            
        }
    }    
}

