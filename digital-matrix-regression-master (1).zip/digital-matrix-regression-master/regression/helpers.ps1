function Get-EnvironmentData ([string]$environment) {

    Write-Host "Fetching environment data for $($environment)..."

    $environmentData = @{
        Local       = @{
            TenantId          = "188697ab-840f-44ec-8535-aaaa5680bab0"
            ClientId          = "f1f74c40-29c8-4fe7-b3f3-e6448183efb1"
            PowerBiClientId   = "6648ddc2-fe51-47a6-8788-83e3d70be774"
            APIHostName       = "digitalmatrix-qa"
            Environment       = "QA"
            Domain            = "kpmgusadvspectrum.onmicrosoft.com"
            SAccountName      = "stousedmdmzqa"
            HumanownerId      = "87eaa737-7e39-498c-a281-0fc4c7693f9b" #sunidhinema@kpmg.com
            SAUsername        = "dmdevreg-svc-devops@kpmgusadvspectrum.onmicrosoft.com"
            SAUserId          = "604c8764-eb1e-4f64-ad89-f50646cdf4c3"
            WorkspaceClientId = "2dd5965c-602d-44e9-9c47-e8b4b22dae00"
        }

        Development = @{
            TenantId          = "188697ab-840f-44ec-8535-aaaa5680bab0"
            ClientId          = "8ca28e96-3553-4a69-92e5-0d18e83d9118"
            PowerBiClientId   = "0555faca-e0c7-4c32-a57e-680520c623dd"
            APIHostName       = "digitalmatrix-dev"
            Environment       = "Development"
            Domain            = "kpmgusadvspectrum.onmicrosoft.com"
            SAccountName      = "stousedmdmzdv"
            HumanownerId      = "87eaa737-7e39-498c-a281-0fc4c7693f9b" #sunidhinema@kpmg.com
            SAUsername        = "dmdevreg-svc-devops@kpmgusadvspectrum.onmicrosoft.com"
            SAUserId          = "604c8764-eb1e-4f64-ad89-f50646cdf4c3"
            WorkspaceClientId = "1797ea0f-0d0a-48cb-8bc2-72218cb0b45f"
        }

        QA          = @{
            TenantId          = "188697ab-840f-44ec-8535-aaaa5680bab0"
            ClientId          = "f1f74c40-29c8-4fe7-b3f3-e6448183efb1"
            PowerBiClientId   = "6648ddc2-fe51-47a6-8788-83e3d70be774"
            APIHostName       = "digitalmatrix-qa"
            Environment       = "QA"
            Domain            = "kpmgusadvspectrum.onmicrosoft.com"
            SAccountName      = "stousedmdmzqa"
            HumanownerId      = "87eaa737-7e39-498c-a281-0fc4c7693f9b" #sunidhinema@kpmg.com
            SAUsername        = "dmdevreg-svc-devops@kpmgusadvspectrum.onmicrosoft.com"
            SAUserId          = "604c8764-eb1e-4f64-ad89-f50646cdf4c3"
            WorkspaceClientId = "2dd5965c-602d-44e9-9c47-e8b4b22dae00"
        }

        CAT         = @{
            TenantId          = "188697ab-840f-44ec-8535-aaaa5680bab0"
            ClientId          = "e40fb35b-5e1b-407e-a8e7-17ce4457ac36"
            PowerBiClientId   = "16fb9244-a15d-4726-92e9-2001e3e27ed6"
            APIHostName       = "digitalmatrix-cat"
            Environment       = "CAT"
            Domain            = "kpmgusadvspectrum.onmicrosoft.com"
            SAccountName      = "stousedmdmzcat"
            HumanownerId      = "87eaa737-7e39-498c-a281-0fc4c7693f9b" #sunidhinema@kpmg.com
            SAUsername        = "dmdevreg-svc-devops@kpmgusadvspectrum.onmicrosoft.com"
            SAUserId          = "604c8764-eb1e-4f64-ad89-f50646cdf4c3"
            WorkspaceClientId = "1797ea0f-0d0a-48cb-8bc2-72218cb0b45f"
        }

        UAT         = @{
            TenantId          = "b5031e57-d76f-422e-87c6-02b4cc749974"
            ClientId          = "8950403a-cdc7-48b8-aff2-b73d30b6bd05"
            PowerBiClientId   = "1d21a618-6328-4539-9ea1-b0d3de3aabea"
            APIHostName       = "digitalmatrix-uat"
            Environment       = "UAT"
            Domain            = "kpmgusadvcloudops.onmicrosoft.com"
            SAccountName      = "stousedmdmzuat"
            HumanownerId      = "b6be98a3-cdaf-4892-9687-925b2c3629e6" #sunidhinema@kpmg.com
            SAUsername        = "dmdevreg-svc-devops@kpmgusadvspectrum.onmicrosoft.com"
            SAUserId          = "604c8764-eb1e-4f64-ad89-f50646cdf4c3"
            WorkspaceClientId = "1797ea0f-0d0a-48cb-8bc2-72218cb0b45f"
        }

        Production  = @{
            TenantId          = "b5031e57-d76f-422e-87c6-02b4cc749974"
            ClientId          = "8950403a-cdc7-48b8-aff2-b73d30b6bd05"
            PowerBiClientId   = "2e82bfe6-4d75-4dbd-9663-9ca9f23310a7"
            APIHostName       = "digitalmatrix"
            Environment       = "Production"
            Domain            = "kpmgusadvcloudops.onmicrosoft.com"
            SAccountName      = "stousedmdmzpd"
            HumanownerId      = "b6be98a3-cdaf-4892-9687-925b2c3629e6" #sunidhinema@kpmg.com
            SAUsername        = "dmdevreg-svc-devops@kpmgusadvspectrum.onmicrosoft.com"
            SAUserId          = "604c8764-eb1e-4f64-ad89-f50646cdf4c3"
            WorkspaceClientId = "1797ea0f-0d0a-48cb-8bc2-72218cb0b45f"
        }
    }

    return $environmentData[$environment]
}

function Invoke-RestMethodAuthWrapperExceptionHandler {
    [CmdletBinding()]param($CurrentEnvironmentData, $requestParameters, $retry)

    try {
        $response = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true
    }
    catch [Microsoft.PowerShell.Commands.HttpResponseException] {

        Write-Warning "Handling expected exception..."

        if ($_.Exception) {
            Write-Warning "Response exception is $($_.Exception.GetType().ToString())"
        }

        if ($_.Exception.Response) {
            $response.ExceptionResponse = $_.Exception.Response
        }
        else {

            Write-Warning "`$_.Exception.Response is null"

            $_ | ConvertTo-Json | Write-Host
        }

        if ($_.ErrorDetails) {

            Write-Verbose "Error Details is of type $($_.GetType().ToString())"
            $response.ErrorDetails = $_.ErrorDetails | ConvertFrom-Json

        }
        else {

            Write-Warning "`$_.ErrorDetails is null"
            Write-Warning "Response StatusCode: $($_.Exception.Response.StatusCode.value__)"
            Write-Warning "Response StatusDescription: $($_.Exception.Response.StatusDescription)"
        }

        <#

              # For debugging if needed
              Write-Host ($_.Exception.Response | Format-Table | Out-String)

              Write-Host ($_.Exception | Format-Table | Out-String)

              Write-Host ($_.ErrorDetails | Format-Table | Out-String)

              #>

    }

    return $response
}

function Invoke-RestMethodAuthWrapper {
    [CmdletBinding()]param($CurrentEnvironmentData, $requestParameters, $retry, $retryNotFound, $retryNotFoundCount)
    try {

        $hostNameUrl = "https://$($CurrentEnvironmentData.APIHostName).kpmgcloudops.com"

        # $requestParameters is being passed as reference.  This logic is needed so that retries using the same object work properly
        # Have I already added the hostname to the URI?  If yes, then don't append again.
        # https://stackoverflow.com/questions/60102320/powershell-function-parameters-by-reference-or-by-value
        # https://docs.microsoft.com/en-us/powershell/module/microsoft.powershell.core/about/about_comparison_operators?view=powershell-7.2#long-description
        if ($requestParameters.Uri -notlike "$($hostNameUrl)*") {
            $requestParameters.Uri = "https://$($CurrentEnvironmentData.APIHostName).kpmgcloudops.com" + $requestParameters.Uri
        }

        $requestParameters.Headers = @{
            "Authorization" = "Bearer $($CurrentEnvironmentData.AuthContext.access_token)"
            "Content-Type"  = "application/json"
            "Accept"        = "application/json"
        }

        Write-Host "$($requestParameters.Method) $($requestParameters.Uri)"
        $requestResponse = Invoke-RestMethod @requestParameters
    }
    catch [Microsoft.PowerShell.Commands.HttpResponseException] {
        Write-Host "Web Request Failed - Status: $($_.Exception.Response.StatusCode.value__)"

        $expectedError = $false

        #TODO: This retry logic isn't the cleanest and leaves open the possiblity that
        # there will be an expected 401 and 404 at that same time.  Probably rare, but still possible.
        if ($_.Exception.Response.StatusCode.value__ -eq 401 -and $retry) {

            Write-Host "Received HTTP 401, attempting to refresh token..."

            $expectedError = $true

            $CurrentEnvironmentData.AuthContext = RefreshAuthenticationContext $currentEnvironmentData

            Write-Host "Reattempting 401 response request..."

            $requestParameters.Headers["Authorization"] = "Bearer $($CurrentEnvironmentData.AuthContext.access_token)"

            $requestResponse = Invoke-RestMethod @requestParameters
        }
        elseif ($_.Exception.Response.StatusCode.value__ -eq 404 -and $retry -and $retryNotFound -and $retryNotFoundCount -gt 0) {

            Write-Host "Received HTTP 404.  Sometimes this is an expected, temporary issue.  Retrying after an 11 second delay..."

            #TODO: This should be modified to be smarter about the retry logic (more than one, increasing wait times, etc)
            # Also, we're only aware of one scenario related to AAD groups where a 404 retry makes sense.  It would be better if
            # there was a way to tell if retrying would actually make sense.
            Start-Sleep -Seconds 11

            $expectedError = $true

            Write-Host "Reattempting 404 response request (Attempts Remaining - $($retryNotFoundCount))..."

            $retryNotFoundCount = $retryNotFoundCount - 1
            $requestResponse = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true $true $retryNotFoundCount
        }
        elseif ($_.Exception.Response.StatusCode.value__ -eq 403 -and $retry -and $retryNotFound -and $retryNotFoundCount -gt 0) {

            Write-Host "Received HTTP 403.  Sometimes this is an expected, temporary issue.  Retrying after an 11 second delay..."

            #TODO: This should be modified to be smarter about the retry logic (more than one, increasing wait times, etc)
            # Also, we're only aware of one scenario related to AAD groups where a 404 retry makes sense.  It would be better if
            # there was a way to tell if retrying would actually make sense.
            Start-Sleep -Seconds 11

            $expectedError = $true

            Write-Host "Reattempting 403 response request (Attempts Remaining - $($retryNotFoundCount))..."

            $retryNotFoundCount = $retryNotFoundCount - 1
            $requestResponse = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true $true $retryNotFoundCount
        }
        elseif ($_.Exception.Response.StatusCode.value__ -eq 400 -and $retry -and $retryNotFound -and $retryNotFoundCount -gt 0) {

            Write-Host "Received HTTP 400.  Sometimes this is an expected, temporary issue.  Retrying after an 11 second delay..."

            #TODO: This should be modified to be smarter about the retry logic (more than one, increasing wait times, etc)
            # Also, we're only aware of one scenario related to AAD groups where a 404 retry makes sense.  It would be better if
            # there was a way to tell if retrying would actually make sense.
            Start-Sleep -Seconds 11

            $expectedError = $true

            Write-Host "Reattempting 400 response request (Attempts Remaining - $($retryNotFoundCount))..."

            $retryNotFoundCount = $retryNotFoundCount - 1
            $requestResponse = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true $true $retryNotFoundCount
        }
        elseif ($_.Exception.Response.StatusCode.value__ -eq 503 -and $retry -and $retryNotFound -and $retryNotFoundCount -gt 0) {

            Write-Host "Received HTTP 503.  Sometimes this is an expected, temporary issue.  Retrying after a 1 minute delay..."

            #TODO: This should be modified to be smarter about the retry logic (more than one, increasing wait times, etc)
            Start-Sleep -Seconds 60

            $expectedError = $true

            Write-Host "Reattempting 503 response request (Attempts Remaining - $($retryNotFoundCount))..."

            $retryNotFoundCount = $retryNotFoundCount - 1
            $requestResponse = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true $true $retryNotFoundCount

            if ($retryNotFoundCount -gt 0) {

                Write-Host "Could not execute 503 response request. Ran out of retries."
            }
        }
        elseif ($_.Exception.Response.StatusCode.value__ -eq 502 -and $retry -and $retryNotFound -and $retryNotFoundCount -gt 0) {

            Write-Host "Received HTTP 502.  Sometimes this is an expected, temporary issue.  Retrying after a 1 minute delay..."

            #TODO: This should be modified to be smarter about the retry logic (more than one, increasing wait times, etc)
            Start-Sleep -Seconds 60

            $expectedError = $true

            Write-Host "Reattempting 502 response request (Attempts Remaining - $($retryNotFoundCount))..."

            $retryNotFoundCount = $retryNotFoundCount - 1
            $requestResponse = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true $true $retryNotFoundCount

            if ($retryNotFoundCount -gt 0) {

                Write-Host "Could not execute 502 response request. Ran out of retries."
            }
        }
        elseif ($_.Exception.Response.StatusCode.value__ -eq 501 -and $retry -and $retryNotFound -and $retryNotFoundCount -gt 0) {

            Write-Host "Received HTTP 501.  Sometimes this is an expected, temporary issue.  Retrying after a 1 minute delay..."

            #TODO: This should be modified to be smarter about the retry logic (more than one, increasing wait times, etc)
            Start-Sleep -Seconds 60

            $expectedError = $true

            Write-Host "Reattempting 501 response request (Attempts Remaining - $($retryNotFoundCount))..."

            $retryNotFoundCount = $retryNotFoundCount - 1
            $requestResponse = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true $true $retryNotFoundCount

            if ($retryNotFoundCount -gt 0) {

                Write-Host "Could not execute 501 response request. Ran out of retries."
            }
        }



        if ($expectedError -eq $false) {

            Write-Host "Received unexpected error or ran out of retries."
            # To retrieve X-Correlation-Id from the reponse headers in exception and print in logs
            $responseHeader = $_.Exception.Response.Headers.GetEnumerator() | Where-Object { $_.Key -in ('X-Correlation-Id') }
            Write-Host "X-Correlation-Id: " $responseHeader.Value

            Write-Host $_.ErrorDetails

            throw
        }
    }
    catch [System.Net.Http.HttpRequestException] {

        Write-Host "Web Request Failed - Status: $($_)"

        if ($retry -and $retryNotFound -and $retryNotFoundCount -gt 0) {

            Write-Host "Socket Exception.  Sometimes this is an expected, temporary issue.  Retrying after a 1 minute delay..."

            #TODO: This should be modified to be smarter about the retry logic (more than one, increasing wait times, etc)
            Start-Sleep -Seconds 60

            Write-Host "Reattempting Socket Exception response request (Attempts Remaining - $($retryNotFoundCount))..."

            $retryNotFoundCount = $retryNotFoundCount - 1

            if ($retryNotFoundCount -le 0) {
                Write-Host "Could not execute Socket Exception response request. Ran out of retries."
                $retryExhausted = $true
            }

            $requestResponse = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true $true $retryNotFoundCount
        }

        elseif ($retry) {
            if (!$retryExhausted -eq $true) {
                Write-Host "Socket Exception.  Sometimes this is an expected, temporary issue.  Retrying 5 times after a 1 minute delay..."
                $requestResponse = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true $true 5
            }
        }
    }

    # In powersehell 5 a bare numeric response is returned as Int32 and in powershell 7 an Int64 (long)
    # The likely cause is the different behavior of (5 | ConvertFrom-Json).GetType() that Invoke-Restmethod likely calls internally.
    # We "round up" here to 64 bite.
    if ($requestResponse -is [int]) {
        $requestResponse = [long] $requestResponse
    }
    return $requestResponse
}

function GetAuthenticationContext ($currentEnvironmentData) {

    $authenticationContext = $null

    if ($currentEnvironmentData.AuthPattern -eq "DeviceCodeFlow") {

        $authenticationContext = GetAccessTokenViaDeviceCodeFlow $currentEnvironmentData

        # powershell functions are weird and return all output, not just what is desired
        # using the index normalizes the response
        # https://stackoverflow.com/questions/10286164/function-return-value-in-powershell
        $authenticationContext = $authenticationContext[0]

    }
    else {

        $authenticationContext = GetToken $currentEnvironmentData

    }

    return $authenticationContext
}

function GetToken ($currentEnvironmentData, $scope) {
    if ([string]::IsNullOrEmpty($scope)) {
        $scope = "api://$($currentEnvironmentData.ClientId)/.default"
    }

    $TokenRequestParams = @{
        Method = 'POST'
        Uri    = "https://login.microsoftonline.com/$($currentEnvironmentData.TenantId)/oauth2/v2.0/token"
        Body   = @{
            grant_type    = "client_credentials"
            client_id     = $currentEnvironmentData.ClientId
            client_secret = $currentEnvironmentData.ClientSecret
            scope         = "$($scope)"
        }
    }

    $TokenResponse = Invoke-RestMethod @TokenRequestParams

    return $TokenResponse
}

function GetOBOEnvironmentData ($currentEnvironmentData, $scope) {
    $oboTokenResponse = GetOBOToken $currentEnvironmentData $scope

    # Clone original environment data
    $currentJson = $currentEnvironmentData | ConvertTo-Json -Depth 5
    $copy = $currentJson | ConvertFrom-Json

    #overwrite with new OBO access token
    $copy.AuthContext.access_token = $oboTokenResponse.access_token

    return $copy
}

function GetAccessTokenViaDeviceCodeFlow ($currentEnvironmentData) {
    $requestParameters = @{
        Method = 'POST'
        Uri    = "https://login.microsoftonline.com/$($currentEnvironmentData.TenantId)/oauth2/v2.0/devicecode"
        Body   = @{
            client_id = $currentEnvironmentData.ClientId
            scope     = "$($currentEnvironmentData.ClientId)/.default"
        }
    }

    $response = Invoke-RestMethod @requestParameters
    Write-Host $response.Message -ForegroundColor Yellow

    $pollingResult = GetDeviceCodeFlowResponse $response
    return $pollingResult
}

function GetOBOToken ($currentEnvironmentData, [string ]$scope) {
    if ($currentEnvironmentData.AuthPattern -eq "DeviceCodeFlow") {
        Write-Verbose "Requesting an OBO token for scope $scope"
        $requestParameters = @{
            Method = 'POST'
            Uri    = "https://login.microsoftonline.com/$($currentEnvironmentData.TenantId)/oauth2/v2.0/token"
            Body   = @{
                grant_type          = "urn:ietf:params:oauth:grant-type:jwt-bearer"
                client_id           = "$($currentEnvironmentData.ClientId)"
                client_secret       = "$($currentEnvironmentData.ClientSecret)"
                assertion           = "$($currentEnvironmentData.AuthContext.access_token)"
                scope               = "$($scope)"
                requested_token_use = "on_behalf_of"
            }
        }

        $response = Invoke-RestMethod @requestParameters
    }
    else {
        $response = GetToken $currentEnvironmentData "$($scope)"
    }

    return $response
}

function GetDeviceCodeFlowResponse ($deviceCodeRequest) {

    # Execute this after logging in with the provided device code
    $requestParameters = @{
        Method = 'POST'
        Uri    = "https://login.microsoftonline.com/$($currentEnvironmentData.TenantId)/oauth2/v2.0/token"
        Body   = @{
            grant_type = "urn:ietf:params:oauth:grant-type:device_code"
            code       = $deviceCodeRequest.device_code
            client_id  = $($currentEnvironmentData.ClientId)
        }
    }

    try {
        Write-Host "Polling oauth endpoint ..."
        $response = Invoke-RestMethod @requestParameters
    }
    catch {
        Write-Verbose "Error polling OAuth endpoint. Have you attempted device flow login?"
        Write-Debug "Error Details: $($_.ErrorDetails.Message)"

        # The HTTP request will fail if the user has not authenticated.  We are catching any exceptions to handle this expected failure
        $expectedError = $false

        if ($_.Exception.Response.StatusCode.value__ -eq 400 -and $_.ErrorDetails.Message) {

            # Let's double check that this is for polling an not something else
            # we are looking for something like
            # error":"authorization_pending","error_description":"AADSTS70016: OAuth 2.0 device flow error. Authorization is pending. Continue polling.

            $aadError = $_.ErrorDetails.Message | ConvertFrom-Json

            if ($aadError.error_codes -contains 70016) {

                # this is an expected error, keep polling
                $expectedError = $true
                Start-Sleep -Seconds 7
                GetDeviceCodeFlowResponse $deviceCodeRequest
            }
        }

        # If it's not the expected error, then something else has happened
        if ($expectedError -eq $false) {
            throw
        }
    }

    return $response
}

function RefreshAuthenticationContext ($currentEnvironmentData) {

    Write-Host "Refreshing token context..."

    $authenticationContext = $null

    if ($currentEnvironmentData.AuthPattern -eq "DeviceCodeFlow") {
        Write-Host "Regenerating with refresh token..."

        $TokenRequestParams = @{
            Method = 'POST'
            Uri    = "https://login.microsoftonline.com/188697ab-840f-44ec-8535-aaaa5680bab0/oauth2/v2.0/token"
            Body   = @{
                grant_type    = "refresh_token"
                client_id     = "$($currentEnvironmentData.ClientId)"
                refresh_token = $currentEnvironmentData.AuthContext.refresh_token
            }
        }

        $authenticationContext = Invoke-RestMethod @TokenRequestParams
    }
    else {
        Write-Host "Regenerating with client secret..."

        $authenticationContext = GetToken $currentEnvironmentData
    }

    return $authenticationContext
}

function Get-BackgroundStatus ($CurrentEnvironmentData, $taskId, $service, [switch] $SupressPendingStatus) {

    Write-Host "Polling background task $($taskId)..."

    # This original request returns a token.  To see current status and eventually results, we'll need to poll
    $requestParams = @{
        Method = 'GET'
        Uri    = "/$($service)/api/v1/backgroundtask/$($taskId)"
    }

    $response = $null
    $inprogressStates = @("Running", "Pending", "ContinuedAsNew")
    $finishedStates = @("Completed", "Failed")
    $status = "Running"
    $steps = -1;
    $500ExceptionDetail = $null;

    while ($finishedStates -notcontains $status) {
        $response = $null
        try {
            $response = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true 6> $null
            $status = $response.status
            $complete = -not ($inprogressStates -contains $status)

            # Always write it for the completed status.
            if ($complete) {
                Write-Host "`nFinal status: $status `n`t $($response | ConvertTo-Json -Depth 10 -Compress)"
                if ($null -ne $500ExceptionDetail) {
                    Write-Host "Received 500 error when running BackgroundTask."
                    # To retrieve X-Correlation-Id from the reponse headers in exception and print in logs
                    $responseHeader = $500ExceptionDetail.Exception.Response.Headers.GetEnumerator() | Where-Object { $_.Key -in ('X-Correlation-Id') }
                    Write-Host "X-Correlation-Id: " $responseHeader.Value

                    Write-Host $500ExceptionDetail.ErrorDetails
                    $response.status = "Failed"
                }
                return $response
            }

            # Only output the job status on a new step, reduces verbosity.
            if (-not $SupressPendingStatus -and $response.taskOutput.steps.Count -gt $steps) {
                $steps = $response.taskOutput.steps.Count
                Write-Host
                Write-Host ($($response) | ConvertTo-Json -Depth 10 -Compress)
            }
            Write-Host '. ' -NoNewline
            Start-Sleep -Seconds 15
        }
        catch [Microsoft.PowerShell.Commands.HttpResponseException] {
            # BackgroundStatus check will run until the task is complete to clean resources in AfterAll block
            if ($_.Exception.Response.StatusCode.value__ -eq 500) {
                Write-Host "Web Request Failed - Status: $($_.Exception.Response.StatusCode.value__)"
                Write-Host "Received HTTP 500, attempting to retry BackgroundStatus..."
                $500ExceptionDetail = $_;
            }

            Write-Host "Web Request Failed - Status: $($_.Exception.Response.StatusCode.value__)"
            Write-Host $_;
        }
    }
}

function Create-Group ($CurrentEnvironmentData, $contextId, [switch] $IgnoreBackgroundStatus) {
    Write-Host "Creating group..."

    $service = "ad"
    $groupName = "Pester$($contextId)"
    $description = "This group was created as part of a test run with context id $($contextId).  If you're reading this - it's okay to delete."

    $requestParams = @{
        Method = 'POST'
        Uri    = "/$($service)/api/v1/group"
        Body   = @{
            "displayName"  = "$($groupName)"
            "description"  = "$($description)"
            "mailNickname" = "$($groupName)"
        } | ConvertTo-Json
    }

    $createResponse = $null
    $createResponse = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true

    if ($IgnoreBackgroundStatus) {
        Write-Host "Not waiting for create group to complete. Status can be monitored with taskid $($createResponse.taskId)."
        return $createResponse
    }

    $createTaskResult = $null
    $createTaskResult = Get-BackgroundStatus $CurrentEnvironmentData $createResponse.taskId "$($service)"

    return $createTaskResult
}

function Create-User ($CurrentEnvironmentData, $contextId, [switch] $IgnoreBackgroundStatus) {

    Write-Host "Creating user..."

    $service = "ad"

    #$contextId = $contextId.ToString().Substring(0, 8)



    # Create user
    $userName = "test-pester-$($contextId)"
    $userPrincipalName = "$($userName)@$($CurrentEnvironmentData.Domain)"
    $alternateEmailAddress = "$($userName)@$($CurrentEnvironmentData.Domain)"
    $mailNickname = "$($userName)"
    $displayName = "$($userName) display"
    $firstName = "$($userName)"
    $lastname = "lastname"
    $emailAddress = "$($userName)@$($CurrentEnvironmentData.Domain)"
    $password = ""  #Removed Get-RandomPassword as this will autogenerate password for user

    $requestParams = @{
        Method = 'POST'
        Uri    = "/$($service)/api/v1/user"
        Body   = @{
            "userPrincipalName"     = "$($userPrincipalName)"
            "password"              = "$($password)"
            "alternateEmailAddress" = "$($alternateEmailAddress)"
            "mailNickname"          = "$($mailNickname)"
            "mobilePhone"           = "+15621234567"
            "displayName"           = "$($displayName)"
            "firstName"             = "$($firstName)"
            "lastname"              = "$($lastname)"
            "emailAddress"          = "$($emailAddress)"

        } | ConvertTo-Json
    }

    $createResponse = $null
    $createResponse = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true

    if ($IgnoreBackgroundStatus) {
        Write-Host "Not waiting for create user to complete. Status can be monitored with taskid $($createResponse.taskId)."
        return $createResponse
    }

    $createTaskResult = $null
    $createTaskResult = Get-BackgroundStatus $CurrentEnvironmentData $createResponse.taskId "$($service)"

    return $createTaskResult
}

function Create-InternalUser ($CurrentEnvironmentData, $contextId) {

    Write-Host "Creating internal cloud native account - AD user"

    $contextId = (New-Guid).Guid.ToString().Substring(0, 8)
    $Script:userName = "test-pester-$($contextId)"
    $userPrincipalName = "$($userName)@$($CurrentEnvironmentData.Domain)"
    $alternateEmailAddress = "$($userName)@kpmg.com"
    $mailNickname = "$($userName)"
    $displayName = "$($userName) display"
    $firstName = "$($userName)"
    $lastname = "lastname"
    $emailAddress = "$($userName)@$($CurrentEnvironmentData.Domain)"
    $password = Get-RandomPassword

    $requestParams = @{
        Method = 'POST'
        Uri    = "/ad/api/v1/user"
        Body   = @{
            "userPrincipalName"     = "$($userPrincipalName)"
            "password"              = "$($password)"
            "alternateEmailAddress" = "$($alternateEmailAddress)"
            "mailNickname"          = "$($mailNickname)"
            "mobilePhone"           = "+15621234567"
            "displayName"           = "$($displayName)"
            "firstName"             = "$($firstName)"
            "lastname"              = "$($lastname)"
            "emailAddress"          = "$($emailAddress)"

        } | ConvertTo-Json
    }

    $createUserResponse = @{}
    $createUserResponse = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true

    $createTaskResult = @{}
    $createTaskResult = Get-BackgroundStatus $CurrentEnvironmentData $createUserResponse.taskId "ad"

    return $createTaskResult

}
function Delete-Group ($CurrentEnvironmentData, $groupId, [switch] $FireAndForget) {

    Write-Host "Deleting group $($groupId)..."

    $service = "ad"

    $requestParams = @{
        Method = 'DELETE'
        Uri    = "/$($service)/api/v1/group/$($groupId)"
    }

    $response = $null
    $response = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true $true 5

    # For test cleanup we don't need to wait for the user to delete unless its a depdedency on other tasks
    if ($FireAndForget) {
        Write-Host "Not waiting for delete group to complete. Status can be monitored with taskid $($response.taskId)."
        return $response.taskId
    }
    else {
        $taskResult = $null
        $taskResult = Get-BackgroundStatus $CurrentEnvironmentData $response.taskId "$($service)"

        return $taskResult
    }
}

function Delete-User {
    param (
        [Parameter(Mandatory)]
        [ValidateNotNullOrEmpty()][HashTable]$CurrentEnvironmentData,
        [Parameter(Mandatory)]
        [ValidateNotNullOrEmpty()][Guid]$userId,
        [switch] $FireAndForget)

    Write-Host "Deleting user $($userId)..."

    $service = "ad"

    #delete user
    $requestParams = @{
        Method = 'DELETE'
        Uri    = "/$($service)/api/v1/user/$($userId)"
    }

    $response = $null
    $response = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true $true 5

    # For test cleanup we don't need to wait for the user to delete unless its a depdedency on other tasks
    if ($FireAndForget) {
        Write-Host "Not waiting for delete user to complete. Status can be monitored with taskid $($response.taskId)."
        return $response.taskId
    }
    else {
        $taskResult = $null
        $taskResult = Get-BackgroundStatus $CurrentEnvironmentData $response.taskId "$($service)"

        return $taskResult
    }


}

function Retry-Request($CurrentEnvironmentData, $requestParams, $maxRetryCount, $expectedId) {

    $response = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true

    while ($maxRetryCount -gt 0) {

        if (!$response) {
            Write-Host "No response received OR response was an empty array.  Sometimes this is an expected, temporary issue.  Retrying after an 11 second delay..."

            Start-Sleep -Seconds 11

            $response = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true

        }
        elseif ($expectedId -and ($response.Id -notcontains $expectedId)) {

            Write-Host "A response was received, but did not contain the desired value.  Sometimes this is an expected, temporary issue.  Retrying after an 11 second delay..."

            Start-Sleep -Seconds 11

            $response = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true

        }
        else {

            $maxRetryCount = 0

        }

        $maxRetryCount = $maxRetryCount - 1
    }

    return $response

}
#Created RiskQuestion for Workspace
function Create-RiskQuestion {
    [OutputType([long])]
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [ValidateNotNullOrEmpty()]
        [hashtable]$CurrentEnvironmentData,
        [Parameter(Mandatory)]
        [ValidateNotNullOrEmpty()]
        [string] $riskQuestionCategory)
    $service = "workspace"
    $questionCode = (New-Guid).ToString().Substring(0, 9)
    $questionText = "AutomationTest_question Do not Use $($questionCode).Do you know the answer?"
    Write-Host "Creating the question for RiskQuestion Category - $riskQuestionCategory."
    # Creating the question
    $requestParams = @{
        Method = 'POST'
        Uri    = "/$($service)/api/v1/riskquestion"
        Body   = @{
            "questionCode"         = "$($questionCode)"
            "questionText"         = "$($questionText)"
            "isMultiSelect"        = "true"
            "riskQuestionCategory" = "$($riskQuestionCategory)"
        } | ConvertTo-Json
    }

    $questionIdResponse = $null
    $questionIdResponse = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true

    return $questionIdResponse

}


#Created RiskQuestion Answer for Workspace
function Create-RiskQuestionAnswer ($CurrentEnvironmentData, $riskQuestionId) {

    $service = "workspace"

    Write-Host "Creating the answer.for Question Id... $riskQuestionId."

    $requestParams = @{
        Method = 'POST'
        Uri    = "/$($service)/api/v1/riskquestion/$($riskQuestionId)/answer"
        Body   = @{
            "answerText"          = "I know the answer of $($riskQuestionId)"
            "appliedBadges"       = @('Internal')
            "appliedEPEPolicyIds" = @('PR_TPC_001')
        } | ConvertTo-Json
    }

    $answerIdResponse = $null
    $answerIdResponse = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true

    return $answerIdResponse

}
function MetadataMethod ($WorkspaceStatus, $EngagementCode) {
    #$script:workspaceStatus = @("Provisioning","Hibernating", "Deleting", "ProvisioningFailed", "Active")
    #$global:WorkspaceStatus = @("Provisioning", "Active")
    #$global:item

    Write-Host "Running for $($WorkspaceStatus) Status"
    Write-Host "Running for $($EngagementCode) code"
    #$service = "workspace"
    #$workspaceId = 2454

    $requestParams = @{
        Method = 'PUT'
        Uri    = "/workspace/api/v1/workspace/$($workspaceId)/metadata"
        Body   = @{
            "status"         = "$($WorkspaceStatus)"
            "engagementCode" = "$($EngagementCode)"

        } | ConvertTo-Json

    }

    $MetadataResponse = @{}
    $MetadataResponse = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true $true 5
    #Get The Status of the Workspace is changed or not
    $requestParams = @{
        Method = 'GET'
        Uri    = "/workspace/api/v1/workspace/$($workspaceId)"
    }

    $response = @{}
    $response = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true
    return $response , $MetadataResponse

}
function Delete-PBIGroup ($CurrentEnvironmentData, $groupId) {

    Write-Host "Deleting PBI group $($groupId)..."

    $service = "powerbi"

    $requestParams = @{
        Method = 'DELETE'
        Uri    = "/$($service)/api/v1/group/$($groupId)"
    }

    $response = $null
    $response = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true $true 5

    $taskResult = $null
    $taskResult = Get-BackgroundStatus $CurrentEnvironmentData $response.taskId "$($service)"

    return $taskResult

}

function New-DevopsUser {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [ValidateNotNullOrEmpty()]
        [HashTable] $CurrentEnvironmentData,
        [Parameter(Mandatory)]
        [ValidateNotNullOrEmpty()]
        [string] $GuestUserMailid,
        [Parameter(Mandatory)]
        [ValidateNotNullOrEmpty()]
        [string] $portfolio,
        [Parameter(Mandatory)]
        [ValidateNotNullOrEmpty()]
        [string] $devopsAccessLvl,
        [Parameter(Mandatory)]
        [ValidateNotNullOrEmpty()]
        [string] $projectAccessLvl)
    Write-Host "Adding user with userName <$GuestUserMailid> as a devops user portfolio: $portfolio Devops level $devopsAccessLvl project accesss: $projectAccessLvl"
    $requestParams = @{
        Method = 'POST'
        Uri    = "/devops/api/v1/user"
        Body   = @{

            "emailAddress"       = "$($GuestUserMailid)"
            "portfolio"          = "$($portfolio)"
            "devOpsAccessLevel"  = "$($devopsAccessLvl)"
            "projectAccessLevel" = "$($projectAccessLvl)"

        } | ConvertTo-Json
    }

    $response = @{}
    $response = Invoke-RestMethodAuthWrapperExceptionHandler `
        $CurrentEnvironmentData `
        $requestParams `
        $true
    return $response
}

function FailEarly {
    param(
        [string] $Message,
        [ScriptBlock] $Conditions
    )
    Write-Host "Performing Fail early asserts. $Message"
    try {
        & $Conditions
    }
    catch {
        Write-Error "Stopping all tests in this Describe because of an error"
        throw
    }
}

function Get-RandomPassword {
    [CmdletBinding()]
    param (
        [ValidateRange(8, 256)]
        [int] $length = 10,
        [int] $upper = 1,
        [int] $lower = 1,
        [int] $numeric = 1,
        [int] $special = 1
    )
    if ($upper + $lower + $numeric + $special -gt $length) {
        throw "Number of upper/lower/numeric/special char(s) must be lower or equal to length"
    }
    $uCharSet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    $lCharSet = "abcdefghijklmnopqrstuvwxyz"
    $nCharSet = "0123456789"
    $sCharSet = "!@#%^&*()"
    $charSet = ""
    if ($upper -gt 0) { $charSet += $uCharSet }
    if ($lower -gt 0) { $charSet += $lCharSet }
    if ($numeric -gt 0) { $charSet += $nCharSet }
    if ($special -gt 0) { $charSet += $sCharSet }

    $charSet = $charSet.ToCharArray()
    $rng = New-Object System.Security.Cryptography.RNGCryptoServiceProvider
    $bytes = New-Object byte[]($length)
    $rng.GetBytes($bytes)

    $result = New-Object char[]($length)
    for ($i = 0 ; $i -lt $length ; $i++) {
        $result[$i] = $charSet[$bytes[$i] % $charSet.Length]
    }
    $password = (-join $result)
    $valid = $true
    if ($upper -gt ($password.ToCharArray() | Where-Object { $_ -cin $uCharSet.ToCharArray() }).Count) { $valid = $false }
    if ($lower -gt ($password.ToCharArray() | Where-Object { $_ -cin $lCharSet.ToCharArray() }).Count) { $valid = $false }
    if ($numeric -gt ($password.ToCharArray() | Where-Object { $_ -cin $nCharSet.ToCharArray() }).Count) { $valid = $false }
    if ($special -gt ($password.ToCharArray() | Where-Object { $_ -cin $sCharSet.ToCharArray() }).Count) { $valid = $false }

    if (!$valid) {
        $password = Get-RandomPassword $length $upper $lower $numeric $special
    }
    return $password
}

function Run-Health-check2 {
    [CmdletBinding()]
    param (
        $CurrentEnvironmentData,
        $service,
        $MaxRetries = 3,
        $RetryDelay = 10
    )

    $healthcheckurl = "https://$($CurrentEnvironmentData.APIHostName).kpmgcloudops.com/$service/health-check"
    Write-Host "Healthcheck URL is ---- $healthcheckurl "

    for ($i = 1; $i -le $MaxRetries; $i++) {
        try {
            $request = Invoke-WebRequest -Uri $healthcheckurl -UseBasicParsing -TimeoutSec 30
            $obj = ConvertFrom-Json $request


            if ($($obj.status) -eq "Healthy") {
                Write-Host "$service Service is up and running - go ahead - Status is = $($obj.status)"
                return $true
            }
            else {
                Write-Output "Website status for $service is : $($obj.status)"
            }
        }
        catch {
            Write-Error "Website is down or inaccessible. Retry attempts remaining: $($MaxRetries - $i)"
        }

        # Wait for $RetryDelay seconds before making the next retry attempt
        Start-Sleep -Seconds $RetryDelay
    }

    # If the max retries are unsuccessful, return false
    return $false
}
function Run-Health-check($CurrentEnvironmentData, $service, $maxRetryCount, $expectedstatus, $retrySecond) {
    $healthcheckurl = "https://$($CurrentEnvironmentData.APIHostName).kpmgcloudops.com/$service/health-check"
    Write-Host "Healthcheck URL is ---- $healthcheckurl "
    $request = Invoke-WebRequest -Uri $healthcheckurl -UseBasicParsing -TimeoutSec 30
    $response = ConvertFrom-Json $request

    while ($maxRetryCount -gt 0) {

        if (!$response) {
            Write-Host "Response is empty. Retrying after an $($retrySecond) second delay..."

            Start-Sleep -Seconds $retrySecond

            $request = Invoke-WebRequest -Uri $healthcheckurl -UseBasicParsing -TimeoutSec 30
            $response = ConvertFrom-Json $request

        }
        elseif ($expectedstatus -and ($response.status -notcontains $expectedstatus)) {

            Write-Host "A response was received, but did not contain the desired value.  Sometimes this is an expected, temporary issue.  Retrying after an $($retrySecond) second delay..."

            Start-Sleep -Seconds $retrySecond
            Write-Host "Re running Healthcheck"
            $request = Invoke-WebRequest -Uri $healthcheckurl -UseBasicParsing -TimeoutSec 30
            $response = ConvertFrom-Json $request

        }
        else {
            $maxRetryCount = 0
        }
        $maxRetryCount = $maxRetryCount - 1
    }
    return $response

}

function New-DynamicFile {
    param(
        [Parameter(Mandatory = $true, HelpMessage = 'Specify the file name')]
        [ValidateNotNullOrEmpty()]
        [string]$FileName,
        [Parameter(Mandatory = $true, HelpMessage = 'Specify the file content')]
        [ValidateNotNullOrEmpty()]
        [string]$FileContent
    )


    Set-Content -Path $FileName -Value $FileContent


}

function Create-GenAI-ChatResponse($modelName) {
    
    $tokenParameter = "max_tokens"
    if($modelName -match "o3-mini" -or $modelName -match "o1") {
        $tokenParameter = "max_completion_tokens"
    }
    
    Write-Host " Verifying Response for $modelName in Chat Capability"
    $engagementCode = "803000012512"
    $requestParams = @{
        Method = 'POST'
        Uri    = "/workspace/api/v1/generativeai/chat"
        Body   = @{
            "modelName"      = $modelName
            "engagementCode" = $engagementCode
            "messages"       = @( @{
                    "role"    = "System"
                    "content" = "Jokes"
                }, @{
                    "role"    = "User"
                    "content" = "Tell me a Joke?"
                })
            "parameters"     = @{
                $tokenParameter = 1
            }
        } | ConvertTo-Json
    }
    $ChatGenAIResponse = $null
    $ChatGenAIResponse = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true
    return $ChatGenAIResponse
}

function Create-GenAI-GoogleVertexChatResponse($modelName) {

    Write-Host " Verifying Response for $modelName in Chat Capability"
    $engagementCode = "803000012512"
    $requestParams = @{
        Method = 'POST'
        Uri    = "/workspace/api/v1/generativeai/chat"
        Body   = @{
            "modelName"      = $modelName
            "engagementCode" = $engagementCode
            "messages"       = @( @{
                    "role"    = "User"
                    "content" = "Who won the Cricket World Cup in 1983"
                }, @{
                    "role"    = "Assistant"
                    "content" = "India won WC 1983 by defeating defending champions (team I performed asked for originally) West Indies."
                }, @{
                    "role"    = "User"
                    "content" = "Who won was the MAN of the MATCH"
                })
            "parameters"     = @{
                "maxOutputTokens" = 1
            }
        } | ConvertTo-Json
    }
    $ChatGenAIResponse = $null
    $ChatGenAIResponse = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true
    Write-Host "Response from POST method for $modelName ---  $ChatGenAIResponse"
    return $ChatGenAIResponse
}
function Create-GenAI-TextResponse ($modelName) {
    Write-Host "Verifying Text Response for $modelName in Text Capability"
    $engagementCode = "803000012512"
    $requestParams = @{
        Method = 'POST'
        Uri    = "/workspace/api/v1/generativeai/text"
        Body   = @{
            "modelName"      = $modelName
            "engagementCode" = $engagementCode
            "prompt"         = "Can you tell me a joke?"
            "parameters"     = @{
                "max_tokens" = 1
            }
        } | ConvertTo-Json
    }
    $TextGenAIResponse = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true
    Write-Host "Response from POST method for $modelName is : $TextGenAIResponse"
    return $TextGenAIResponse
}
function Create-GenAI-TextStreamResponse ($modelName) {
    Write-Host "Verifying TextStream Response for $modelName in TextStreaming Capability"
    $engagementCode = "803000012512"
    $requestParams = @{
        Method = 'POST'
        Uri    = "/workspace/api/v1/generativeai/text/stream"
        Body   = @{
            "modelName"      = $modelName
            "engagementCode" = $engagementCode
            "prompt"         = "Can you tell me a joke?"
            "parameters"     = @{
                "max_tokens" = 1
            }
        } | ConvertTo-Json

    }
    $TextStreamGenAIResponse = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true
    Write-Host "Response from POST method for $modelName is : $TextStreamGenAIResponse"
    return $TextStreamGenAIResponse
}
function Create-GenAI-EmbeddingsResponse($modelName) {
    Write-Host "Verifying TextStream Response for $modelName in Embeddings Capability"
    $engagementCode = "803000012512"
    $requestParams = @{
        Method = 'POST'
        Uri    = "/workspace/api/v1/generativeai/embedding"
        Body   = @{
            "modelName"      = $modelName
            "engagementCode" = $engagementCode
            "input"          = "Can you tell me a story?"

        } | ConvertTo-Json

    }
    $EmbeddingsGenAIResponse = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true
    Write-Host "Response from POST method for $modelName is : $EmbeddingsGenAIResponse"
    return $EmbeddingsGenAIResponse
}
function Create-GenAI-ChatStreamResponse($modelName) {
    Write-Host " Verifying Response for $modelName in ChatStreaming Capability"
    $engagementCode = "803000012512"
    #$stop = Get-Random -Minimum 0 -Maximum 4
    $requestParams = @{
        Method = 'POST'
        Uri    = "/workspace/api/v1/generativeai/chat/stream"
        Body   = @{
            "modelName"      = $modelName
            "engagementCode" = $engagementCode
            "messages"       = @( @{
                    "role"    = "System"
                    "content" = "can you tell me a joke"
                }, @{
                    "role"    = "User"
                    "content" = "Tell me a joke?"
                })
        } | ConvertTo-Json
    }
    $ChatStreamingGenAIResponse = $null
    $ChatStreamingGenAIResponse = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true
    Write-Host "Response from POST method for $modelName is :   $ChatStreamingGenAIResponse"
    return $ChatStreamingGenAIResponse
}


function Create-GenAI-GoogleVertexTextResponse($modelName) {

    #Generated the most relatable promts on the basis of catagory mentioned in https://cloud.google.com/vertex-ai/docs/generative-ai/model-reference/code-generation
    Write-Host " Verifying Response for $modelName in Google Vertex Text Capability"
    $engagementCode = "803000012512"
    $requestParams = @{
        Method = 'POST'
        Uri    = "/workspace/api/v1/generativeai/text"
        Body   = @{
            "modelName"      = $modelName
            "engagementCode" = $engagementCode
            "prompt"         = "Write a function in Python that checks if a given string is a palindrome. The function should take a single argument (a string) and return True if the input string is a palindrome, and False otherwise."
            "parameters"     = @{
                "maxOutputTokens" = 1
            }
        } | ConvertTo-Json

    }
    Write-host "Request body is --- $requestParams "
    $GoogleTextGenAIResponse = @{}
    $GoogleTextGenAIResponse = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true
    Write-Host "Response from POST method for $modelName ---  $GoogleTextGenAIResponse"
    return $GoogleTextGenAIResponse
}

function Create-GenAI-CohereEmbeddingsResponse($modelName) {

    Write-Host " Verifying Response for $modelName in Text Capability"
    $engagementCode = "803000012512"
    $requestParams = @{
        Method = 'POST'
        Uri    = "/workspace/api/v1/generativeai/embedding"
        Body   = @{
            "modelName"      = $modelName
            "engagementCode" = $engagementCode
            "input"          = "Who is Bill Gates?"
        } | ConvertTo-Json
    }
    $CohereEmbeddingsGenAIResponse = $null
    $CohereEmbeddingsGenAIResponse = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true
    Write-Host "Response from POST method for $modelName ---  $CohereEmbeddingsGenAIResponse"
    return $CohereEmbeddingsGenAIResponse
}

function Create-GenAI-TokencountOfTextResponse($modelName) {

    Write-Host " Verifying Response for $modelName in TokenCount Capability of Text"
    $engagementCode = "803000012512"
    $requestParams = @{
        Method = 'POST'
        Uri    = "/workspace/api/v1/generativeai/text/tokencount"
        Body   = @{
            "modelName" = $modelName
            "prompt"    = "Who is Bill Gates"

        } | ConvertTo-Json
    }
    $CohereTokenCountOfTextGenAIResponse = $null
    $CohereTokenCountOfTextGenAIResponse = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true
    Write-Host "Response from POST method for $modelName ---  $CohereTokenCountOfTextGenAIResponse"
    return $CohereTokenCountOfTextGenAIResponse
}

function Create-GenAI-TokencountOfEmbeddingsResponse($modelName) {

    Write-Host " Verifying Response for $modelName in TokenCount Capability of Embeddings"
    $engagementCode = "803000012512"
    $requestParams = @{
        Method = 'POST'
        Uri    = "/workspace/api/v1/generativeai/embedding/tokencount"
        Body   = @{
            "modelName" = $modelName
            "input"     = "Who is Bill Gates?"

        } | ConvertTo-Json
    }
    $CohereTokenCountOfEmbeddingsGenAIResponse = $null
    $CohereTokenCountOfEmbeddingsGenAIResponse = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true
    Write-Host "Response from POST method for $modelName ---  $CohereTokenCountOfEmbeddingsGenAIResponse"
    return $CohereTokenCountOfEmbeddingsGenAIResponse
}

function Create-GenAI-TokencountOfChatResponse($modelName) {

    Write-Host " Verifying Response for $modelName in TokenCount Capability of Chat"
    $engagementCode = "803000012512"
    $requestParams = @{
        Method = 'POST'
        Uri    = "/workspace/api/v1/generativeai/chat/tokencount"
        Body   = @{
            "modelName" = $modelName
            "messages"  = @(
                @{
                    "role"    = "User"
                    "content" = "Who won the Cricket World Cup in 2023"
                })
        } | ConvertTo-Json
    }
    $CohereTokenCountOfChatGenAIResponse = $null
    $CohereTokenCountOfChatGenAIResponse = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true
    Write-Host "Response from POST method for $modelName ---  $CohereTokenCountOfChatGenAIResponse"
    return $CohereTokenCountOfChatGenAIResponse
}

function Content-Extraction ($fileName) {
    #Generating uri for given product and component for specified file
    Write-Host "Inside function for $fileName"
    $requestParams = @{
        Method = 'POST'
        Uri    = "/workspace/api/v1/product/$($productId)/component/$($componentId)/sastoken"
        Body   = @{
            "directoryOrBlobPath" = "$($fileName)"
        } | ConvertTo-Json
    }

    $uriResponse = @{}
    $uriResponse = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true
    $sasUri = $uriResponse.sasUri

    Write-Host "Uri for $($fileName) is - $sasUri"

    #Content extraction from the specified file
    $requestParams = @{
        Method = 'POST'
        Uri    = "/workspace/api/v1/contentextraction/extractplaintext"
        Body   = @{
            "fileSasUri" = "$($sasUri)"
        } | ConvertTo-Json
    }

    $contentExtractionResponse = @{}
    $contentExtractionResponse = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true

    return $contentExtractionResponse

}

function GetSAEnvironmentData ($currentEnvironmentData) {
    Write-host "Inside GetSAEnvironmentData "
    $SATokenResponse = GetSAToken $currentEnvironmentData
    Write-Host "Value in Gen token is $SATokenResponse "
    # Clone original environment data
    $currentJson = $currentEnvironmentData | ConvertTo-Json -Depth 5
    $copy = $currentJson | ConvertFrom-Json

    #overwrite with new Service Account access token
    $copy.AuthContext.access_token = $SATokenResponse.access_token

    return $copy
}

function GetSAToken ($currentEnvironmentData) {
    $requestParameters = @{
        Method = 'POST'
        Uri    = "https://login.microsoftonline.com/$($currentEnvironmentData.TenantId)/oauth2/v2.0/token"
        Body   = @{
            username      = "$($currentEnvironmentData.SAUsername)"
            password      = "$($currentEnvironmentData.SAPassword)"
            client_id     = "$($currentEnvironmentData.ClientId)"
            client_secret = "$($currentEnvironmentData.ClientSecret)"
            scope         = "$($currentEnvironmentData.WorkspaceClientId)/.default"
            grant_type    = "password"

        }
    }
    Write-Host "Payload for berear token --- $($requestParameters| ConvertTo-Json) "
    # Send request
    $response = Invoke-RestMethod @requestParameters

    return $response
}


function  ActivityLogs ($service , $type) {
    try {
        $requestParams = @{
            Method = 'POST'
            Uri    = "/$service/api/v1/activitylog/tasks"
            Body   = @{
                "types" = @($type)
            } | ConvertTo-Json
        }
        $LogResponse = @{}
        $LogResponse = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true

        $logsArrayType = $LogResponse.entries.logs.GetType().Name
        Write-host " DataType of 'Logs' in Response is-- $logsArrayType "
        if (-not $LogResponse) {
            Write-Host "No Activity Logs got displayed for $type Operation Wait for 5 min and Try again... "
            Start-Sleep -Seconds 200
            $LogResponse = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true
        }
        Return $LogResponse
    }
    catch {
        Write-Error "Error in generating Logs"
        throw
    }

}

function FileUploadUsingAzConnect () {
    param(
        [Parameter(Mandatory)]
        [ValidateNotNullOrEmpty()][String]$Filepath,
        [Parameter(Mandatory)]
        [ValidateNotNullOrEmpty()][String]$ContainerName,
        [Parameter(Mandatory)]
        [ValidateNotNullOrEmpty()][String]$Root,
        [Parameter()]
        [int]$MaxRetries = 5
    )

    #$FileUploadTestCases = New-Object System.Collections.Generic.List[Hashtable]
    $isUpload = $true
    for ($i = 1; $i -le $MaxRetries; $i++) {
        try {
            Write-Host "Connecting to Azure Portal...."
            $clientId = $($CurrentEnvironmentData.ClientId)
            Write-Host "---------CLIENT ID IS -- $($clientId)----------------"
            $clientSecret = $($CurrentEnvironmentData.ClientSecret)
            Write-Host "--------- CLIENT SECRETS IS -- $($clientSecret)----------------"
            $tenantId = $($CurrentEnvironmentData.TenantId)
            Write-Host "---------TENANT ID IS -- $($tenantId)----------------"
            $tempPassword = ConvertTo-SecureString "$clientSecret" -AsPlainText -Force
            $psCred = New-Object System.Management.Automation.PSCredential($clientId , $tempPassword)
            Connect-AzAccount -Credential $psCred -Tenant $tenantId  -ServicePrincipal
            Write-Host  "AzurePortal is connected"

            $Context = New-AzStorageContext -StorageAccountName $($CurrentEnvironmentData.SAccountName)

            Write-Host "Start uploading $Filepath "
            $fileName = $Filepath
            $UploadFile = @{
                File             = "$Root\$($fileName)"
                Container        = $($ContainerName)
                Blob             = $($fileName)
                Context          = $Context
                StandardBlobTier = 'Hot'
            }

            Set-AzStorageBlobContent @UploadFile -Force
            Write-Host  "File Upload done in azure stroage container for $($fileName)"

            $i = $MaxRetries
            $isUpload = $true
            break

        }

        catch {
            $errorMsg = $_.Exception.Message
            Write-Host "Error uploading files: $errorMsg"
            if ($i -eq $MaxRetries) {
                throw "Maximum upload retries exceeded. Please Check Manually"
                $isUpload = $false
                break
            }
            else {
                $RetryDelaySeconds = 30
                Write-Warning "Retrying in $RetryDelaySeconds seconds..."
                Start-Sleep -Seconds $RetryDelaySeconds
            }
        }

    }
    return $isUpload
}

function GetStateProviderInstances($providerInstanceName , $expectedState) {
    $MaxRetry = 5
    $RetryDelay = 70

    $requestParams = @{
        Method = 'GET'
        Uri    = "/workspace/api/v1/generativeai/providerinstance?pageIndex=0&pageSize=100"
    }

    Write-Host "Checking if provider instance $providerInstanceName is disabled..."

    for ($i = 0; $i -lt $MaxRetry; $i++) {
        $response = Invoke-RestMethodAuthWrapper $CurrentEnvironmentData $requestParams $true
        $responseProviderInstance = $response | Where-Object { $_.providerInstanceName -eq $providerInstanceName }
        Write-Host "Response in ProviderInstance Response is $responseProviderInstance "
        if ($responseProviderInstance) {
            if ($responseProviderInstance.isEnabled -eq $expectedState) {
                Write-Host "Current State of Provider Instance is ---- $($responseProviderInstance.isEnabled) and Expected $expectedState "
                Write-Host "Provider instance $providerInstanceName is in desire State"
                return $true
            }
            else {
                Write-Host "Current State of Provider Instance is ---- $($responseProviderInstance.isEnabled) and Expected $expectedState "
                Write-Host "Provider instance $providerInstanceName is enabled.Wait for 30 Sec to make it disable......"
                Start-Sleep -Seconds $RetryDelay

            }

        }
        else {
            Write-Host "Provider instance $providerInstanceName is not Found. Wait for 30 Sec......"
            Start-Sleep -Seconds $RetryDelay
        }
    }

    Write-Host "Provider instance $providerInstanceName could not be disabled/found after $MaxRetry retries."
    throw "Provider instance $providerInstanceName could not be disabled/Found after $MaxRetry retries."
}

