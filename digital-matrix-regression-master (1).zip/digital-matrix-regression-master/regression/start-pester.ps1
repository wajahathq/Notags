﻿<#
  .SYNOPSIS
  Run the regression suite.

  .DESCRIPTION
  Sets up the environment and runs INvoke-Pester

  .PARAMETER Environment
  The environment to run the tests against.

  .PARAMETER ClientSecret
  The client secret to used to get an App Registration OAuth token.
  Optional for local.

  .PARAMETER $TestResultOutputPath
  The client secret to used to get an App Registration OAuth token.

  .PARAMETER IncludeLongRunning
  Set this to also run the longer tests

  .PARAMETER WriteOutputImmediately
  Set this and instead of looping through the jobs dumpss the output one at a time.
  The jobs still run in parallel, and less output is produced.

  .EXAMPLE

  Typical local running scenario

  PS> .\start-pester.ps1 -TestResultOutputPath '.' -WriteOutputImmediately

  .EXAMPLE

  Run locally with long tests

  PS> .\start-pester.ps1 -IncludeLongRunning -WriteOutputImmediately

  .EXAMPLE

  Run one file locally

  PS> .\start-pester.ps1 -IncludeLongRunning -WriteOutputImmediately -TestFilter auth-user.tests.ps1

#>
[CmdletBinding()]
param(
  [ValidateNotNullOrEmpty()]
  [ValidateSet('Local', 'Development', 'UAT', 'QA', 'CAT', 'Production')]
  [string] $Environment = "Local",

  [ValidateScript({
      if ($PSBoundParameters['Environment'] -ne 'Local' -And [string]::IsNullOrWhiteSpace($_)) {
        throw 'Client Secret must be set unless environment is "Local"'
      }
      else {
        $true
      }
    })]
  [string] $ClientSecret,

  [string] $SAPassword,

  [ValidateNotNullOrEmpty()]
  [string] $TestResultOutputPath = ".",

  [switch] $IncludeLongRunning,

  [switch] $WriteOutputImmediately,

  [string] $TestFilter = "*.tests.ps1"
)

#Requires -Version 7
#Requires -PSEdition Core
#Requires -Modules @{ ModuleName="Pester"; ModuleVersion="5.0.0" }

Import-Module Pester -MinimumVersion 5.0.0 -PassThru
. ".\Helpers.ps1"

If (-not (Test-Path $TestResultOutputPath)) {
  mkdir $TestResultOutputPath
}

Remove-Item  (Join-Path $TestResultOutputPath '*.test-results.xml')

# Change this value based on the execution context.  See Helpers.ps1.
# For example, setting to Local will use DeviceCodeFlow

if (!$myEnvironmentData.AuthContext -or $Environment -ne $myEnvironmentData.Environment) {
  $myEnvironmentData = Get-EnvironmentData $Environment

  $myEnvironmentData.ClientSecret = $ClientSecret
  $myEnvironmentData.SAPassword = $SAPassword
  $myEnvironmentData.AuthContext = GetAuthenticationContext $myEnvironmentData
}

$pesterJobs = New-Object System.Collections.Generic.List[pscustomobject]

$InitScript = [scriptblock]::Create(@"
      . "$PsScriptRoot\Helpers.ps1"
"@)

Write-Verbose "Include Long Running Jobs: $IncludeLongRunning"

$ContiniousIntegration = ($Environment -ne "Local")

# cast from empty hashtable to get default
Get-ChildItem tests -Filter $TestFilter |  ForEach-Object {
  $TestSuiteName = $_.BaseName

  $ResultFile = Join-Path $TestResultOutputPath  "$($TestSuiteName).testresult.xml"


  $job = Start-Job  -Name "$($_.BaseName)"  `
    -InitializationScript $InitScript `
    -FilePath "$PsScriptRoot\Invoke-DigitalMatrixPesterFile.ps1" `
    -ArgumentList `
    $myEnvironmentData, `
    $_.FullName, `
    $_.BaseName, `
    $ResultFile, `
    $ContiniousIntegration, `
    $IncludeLongRunning
  $job `
  | Add-Member  -PassThru -MemberType NoteProperty -Name 'ResultFile' -Value $ResultFile `
  | Add-Member -MemberType ScriptProperty -Name 'JobRunTime' `
    -Value { (Get-Date) - $job.PSBeginTime } `
    -SecondValue { (($job.PSEndTime ?? (Get-Date)) - $job.PSBeginTime) }
  $pesterJobs.Add($job)

  Start-Sleep -Seconds 10

  Write-Verbose "Invoked test runner for $($TestSuiteName). Writing results to `"$ResultFile`"."
}

if ($WriteOutputImmediately) {
  $PesterJobs | ForEach-Object {
    $_ | Receive-Job -Wait
  }
}
else {
  Write-Verbose '======== Waiting for pester jobs to finish ======'
  $FailedJobs = New-Object System.Collections.Generic.List[pscustomobject]
  ./Wait-PesterJobs $PesterJobs $FailedJobs -ErrorIfJobsFailed
  if ($FailedJobs.Count -gt 0) {
    Write-Warning "$($FailedJobs.Count) failed to complete."
    $FailedJobs | Format-Table Id, Name, State, JobRunTime
  }
}